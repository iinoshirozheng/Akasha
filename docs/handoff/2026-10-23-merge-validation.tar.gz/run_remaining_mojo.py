from pathlib import Path
import subprocess, time, json, hashlib
root = Path(".build/merge-validation")
known = {}
for report in ["targeted.json", "recheck.json"]:
    for entry in json.loads((root / report).read_text()):
        known[entry["test"]] = entry
passed = {name for name, entry in known.items() if entry["exit_code"] == 0}
source_hashes = json.loads((root / "source-sha256.json").read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in source_hashes.items())
# Broaden only through changed query/storage call paths. Unchanged suites retain
# their prior validation; this consolidation does not rerun performance gates.
related = {
    "test_default_point_alignment", "test_field_metrics", "test_field_rerank",
    "test_field_ivf", "test_generation_close", "test_generation_delta",
    "test_generation_fields", "test_snapshot", "test_point_snapshot",
    "test_point_read_view", "test_query_control", "test_query_executor",
    "test_query_planner", "test_segmented_hnsw", "test_hnsw_delta_admission",
    "test_hnsw_quantized", "test_hnsw_base_ordinals", "test_hnsw_filtered",
    "test_hnsw_mutation", "test_hnsw_overlay_cache", "test_hnsw_scratch",
    "test_hnsw_widening", "test_hnsw_live_radius", "test_hnsw_group_order",
    "test_hnsw_four_distance", "test_hnsw_payload", "test_hnsw_payload_lifecycle",
    "test_index_cache", "test_index_cache_mapped", "test_persisted_index_cache",
    "test_index_cache_publication", "test_maintenance", "test_compaction_capture",
    "test_compaction_reclaim_boundary", "test_compaction_reclaim_close",
    "test_hnsw_query_boundaries",
}
selected = related | set(known)
results = []
for test in sorted(Path("tests/mojo").glob("test_*.mojo")):
    if test.stem not in selected:
        continue
    name = test.stem
    digest = hashlib.sha256(test.read_bytes()).hexdigest()
    if name in passed:
        entry = {"test": name, "exit_code": 0, "test_sha256": digest, "reused_current_merge_result": True}
    else:
        command = ["pixi", "run", "mojo", "run", "-I", "src", str(test)]
        start = time.time()
        log = root / (name + "-suite.log")
        with log.open("w") as output:
            run = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
        entry = {"test": name, "command": command, "exit_code": run.returncode, "test_sha256": digest, "seconds": round(time.time()-start,2)}
        print(json.dumps(entry), flush=True)
        if run.returncode:
            print(log.read_text()[-6000:], flush=True)
    results.append(entry)
    (root / "mojo-suite.json").write_text(json.dumps(results, indent=2))
print("MOJO_COMPLETE", sum(entry["exit_code"] == 0 for entry in results), "/", len(results), flush=True)
