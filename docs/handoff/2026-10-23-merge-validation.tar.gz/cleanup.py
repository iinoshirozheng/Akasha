from pathlib import Path
import os, subprocess, json, shutil, tempfile
root = Path.cwd().resolve()
assert root == Path("/Users/ray/Projects/Akasha")
def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()
assert git("branch", "--show-current") == "main"
assert not git("status", "--porcelain"), "Commit validated merge before cleanup"
assert not (root / ".git/MERGE_HEAD").exists()
branches = ["feat/qdrant-alignment", "feat/48-bounded-generation-head"]
for branch in branches:
    subprocess.run(["git", "merge-base", "--is-ancestor", branch, "main"], check=True)
assert git("ls-files", "docs/handoff/2026-10-23-merge-validation.tar.gz")
inventory = json.loads((root / ".build/merge-validation/docker-cleanup-inventory.json").read_text())
summary = {"main_before_cleanup": git("rev-parse", "HEAD"), "local_branches_removed": [], "worktrees_removed": [], "generated_paths_removed": [], "temporary_entries_removed": 0, "docker_containers_removed": 0, "docker_volumes_removed": [], "remote_mutations": False}
wt = root / ".worktrees/qdrant-alignment"
status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=wt, text=True).splitlines()
assert set(status) <= {"?? .pixi", "?? reference"}, status
for name in [".pixi", "reference"]:
    p = wt / name
    assert p.is_symlink() and p.resolve() == (root / name).resolve()
    p.unlink()
subprocess.run(["git", "worktree", "remove", "--force", str(wt)], check=True)
summary["worktrees_removed"].append(str(wt))
subprocess.run(["git", "worktree", "prune"], check=True)
for branch in branches:
    subprocess.run(["git", "branch", "-d", branch], check=True)
    summary["local_branches_removed"].append(branch)
if not any((root / ".worktrees").iterdir()):
    (root / ".worktrees").rmdir()
# Exact stopped test containers only; Docker rejects a concurrent restart.
ids = []
for item in inventory:
    data = json.loads(subprocess.check_output(["docker", "inspect", item["id"]], text=True))[0]
    assert data["Name"] == item["name"] and data["Name"].startswith("/akasha-")
    assert not data["State"]["Running"]
    ids.append(item["id"])
for start in range(0, len(ids), 25):
    subprocess.run(["docker", "rm", *ids[start:start+25]], check=True, stdout=subprocess.DEVNULL)
    summary["docker_containers_removed"] += len(ids[start:start+25])
volumes = sorted({m["Name"] for item in inventory for m in item["mounts"] if m["Type"] == "volume"})
for volume in volumes:
    assert volume.startswith("akasha-")
    users = subprocess.check_output(["docker", "ps", "-aq", "--filter", "volume="+volume], text=True).strip()
    assert not users, (volume, users)
    subprocess.run(["docker", "volume", "rm", volume], check=True, stdout=subprocess.DEVNULL)
    summary["docker_volumes_removed"].append(volume)
# Preserve installed dependencies, reference source checkouts and Git history.
def remove(p):
    if p.is_symlink() or p.is_file(): p.unlink()
    elif p.is_dir(): shutil.rmtree(p)
for base in [Path("/tmp"), Path(tempfile.gettempdir())]:
    for p in list(base.glob("akasha-*")):
        assert p.lstat().st_uid == os.getuid(), str(p)
        remove(p)
        summary["temporary_entries_removed"] += 1
pytest_root = Path(tempfile.gettempdir()) / "pytest-of-ray"
for name in ["pytest-1862", "pytest-1863", "pytest-1864"]:
    p = pytest_root / name
    if p.exists():
        remove(p)
        summary["temporary_entries_removed"] += 1
current = pytest_root / "pytest-current"
if current.is_symlink() and not current.exists(): current.unlink()
if pytest_root.exists() and not any(pytest_root.iterdir()): pytest_root.rmdir()
cache_names = {"__pycache__", "__mojocache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
for parent, dirs, files in os.walk(root, followlinks=False):
    if Path(parent) == root:
        dirs[:] = [d for d in dirs if d not in {".git", ".pixi", "reference", ".build"}]
    for name in list(dirs):
        if name in cache_names:
            p = Path(parent) / name
            remove(p)
            summary["generated_paths_removed"].append(str(p.relative_to(root)))
            dirs.remove(name)
    for name in files:
        if name == ".DS_Store": remove(Path(parent) / name)
for rel in ["python/akashadb/_kernel.so", ".pixi/task-cache-v0", ".build"]:
    p = root / rel
    remove(p)
    summary["generated_paths_removed"].append(rel)
summary["remaining_local_branches"] = git("for-each-ref", "--format=%(refname:short)", "refs/heads").splitlines()
summary["remaining_worktrees"] = git("worktree", "list", "--porcelain")
assert summary["remaining_local_branches"] == ["main"]
assert len(git("worktree", "list").splitlines()) == 1
(root / "docs/handoff/2026-10-23-cleanup.json").write_text(json.dumps(summary, indent=2)+"\n")
print(json.dumps(summary, indent=2), flush=True)
