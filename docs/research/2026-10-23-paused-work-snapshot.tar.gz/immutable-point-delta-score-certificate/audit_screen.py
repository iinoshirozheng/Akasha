"""Independently recompute reported ratios from every raw timed latency."""
import hashlib
import json
import math
import statistics
from pathlib import Path

root=Path(__file__).resolve().parent
out=root/'screen-pairs'
identity=json.loads((out/'identity.json').read_text())
runs=json.loads((out/'execution.json').read_text())
assert len(runs)==12 and all(r['returncode']==0 for r in runs)
observed={}
for run in runs:
    corpus,trial,label=(run[k] for k in ('corpus','trial','label'))
    report=json.loads((out/f'{corpus}-{trial}-{label}.json').read_text())
    assert report['native_binary_sha256']==identity['binaries'][label]
    assert len(report['queries'])==288
    modes={}
    for cell in report['modes']:
        values=sorted(q['latency_ns'] for q in report['queries'] if q['mode']==cell['mode'])
        assert len(values)==72 and min(values)>0
        qps=len(values)*1e9/sum(values)
        p95=values[math.ceil(.95*len(values))-1]
        assert cell['qps']==qps and cell['p95_ns']==p95
        modes[cell['mode']]=dict(qps=qps,p95=p95)
    observed[corpus,trial,label]=modes
pairs=[]
for pair in json.loads((out/'pairs.json').read_text()):
    corpus,trial=pair['corpus'],pair['trial']
    a,b=observed[corpus,trial,'prior'],observed[corpus,trial,'candidate']
    assert pair['order']==(['prior','candidate'] if trial==0 else ['candidate','prior'])
    for cell in pair['modes']:
        mode=cell['mode']
        assert cell['qps_ratio']==b[mode]['qps']/a[mode]['qps']
        assert cell['p95_ratio']==b[mode]['p95']/a[mode]['p95']
    pairs.append(pair)
assert len(pairs)==6
summary=json.loads((out/'summary.json').read_text())
for row in summary:
    for cell in row['modes']:
        for field in ('qps_ratio','p95_ratio'):
            expected=statistics.median(c[field] for p in pairs if p['corpus']==row['corpus']
                                       for c in p['modes'] if c['mode']==cell['mode'])
            assert cell[field]==expected
audit=dict(workers=12,raw_latencies=3456,per_mode_latencies=72,
    matched_exact_qps_and_nearest_rank_p95=True,pair_ratios_and_medians_recomputed=True,
    all_raw_report_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(out.glob('*.json')) if p.name not in ('latency-audit.json',)},
    scope='Implementation screen, not a new Qdrant acceptance comparison. All samples retained.')
(out/'latency-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k!='all_raw_report_sha256'}))
