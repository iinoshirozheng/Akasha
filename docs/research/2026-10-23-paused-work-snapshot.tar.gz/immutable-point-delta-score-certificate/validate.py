"""Serial admission, mutable-source, ordinal, traversal and mapped checks."""
import json
import hashlib
import re
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
modules=[root / "tests" / name for name in ['test_neighbor_gather.mojo', 'test_hnsw_neighbor_ranges.mojo', 'test_hnsw_search_layer.mojo', 'test_hnsw_view.mojo', 'test_hnsw_control.mojo', 'test_hnsw_filtered.mojo', 'test_hnsw_store.mojo', 'test_hnsw_mapped_vectors.mojo', 'test_segmented_hnsw.mojo', 'test_hnsw_base_ordinals.mojo', 'test_deferred_id.mojo', 'test_filtered_delta_id.mojo']]
modules.extend(root / "tests" / name for name in ['test_hnsw_four_distance.mojo', 'test_hnsw_store_v1_compat.mojo'])
modules.extend(root / "tests" / name for name in ['test_score_certificate.mojo', 'test_delta_score_certificate.mojo', 'test_hnsw_rerank_batch.mojo', 'test_paired_exact.mojo', 'test_simd_distance.mojo', 'test_hnsw_overlay_cache.mojo'])
snapshot=lambda: {str(p.relative_to(root/'src')): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'src').rglob('*.mojo'))}
source=snapshot()
(root/'validation-source.json').write_text(json.dumps(source,indent=2)+'\n')
runs=[]
for path in modules:
    command=['rtk','proxy','pixi','run','mojo','run','--target-accelerator=metal:4','--target-cpu=apple-m4',
        '-I',str(root/'src'),'-I','benchmarks/mojo',str(path)]
    assert source == snapshot(), "source changed before validation"
    log=root/'logs'/(path.stem+'.log')
    print('Testing',path.name,flush=True)
    with log.open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
    assert source == snapshot(), "source changed during validation"
    text=log.read_text();counts=re.findall(r'(\d+) tests run: (\d+) passed , (\d+) failed , (\d+) skipped',text)
    runs.append(dict(file=str(path),command=command,exit_code=r.returncode,summary=counts[-1] if counts else None))
    (root/'validation.json').write_text(json.dumps(runs,indent=2)+'\n')
    assert r.returncode==0,(path,text[-5000:])
    assert counts and counts[-1][0]==counts[-1][1] and counts[-1][2:]==('0','0')
    print('Passed',path.name,counts[-1][0],flush=True)
print('Passed',sum(int(row['summary'][0]) for row in runs),'cases in',len(runs),'modules',flush=True)
