"""Build once, then screen the frozen mixed workload in both serial orders."""
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys
from pathlib import Path

from benchmarks.qdrant_workload import load_workload
from mixed_measure import validate_mixed_report

root = Path(__file__).resolve().parent
parent = root.parent / 'immutable-point-score-certificate'
frozen = root.parent / 'delta-admission-first/known-count'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {str(p.relative_to(root / 'src')): sha(p) for p in sorted((root / 'src').rglob('*.mojo'))}
(root / 'candidate-source.json').write_text(json.dumps(sources, indent=2) + '\n')
command = ['rtk', 'proxy', 'pixi', 'run', 'mojo', 'build', '--emit', 'shared-lib',
           '-I', str(root / 'src'), str(root / 'src/bindings/python_module.mojo'),
           '-o', str(root / 'python/akashadb/_kernel.so')]
print('building candidate', flush=True)
with (root / 'logs/native-build.log').open('w') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, (root / 'logs/native-build.log').read_text()
binaries = {'prior': parent / 'python/akashadb/_kernel.so',
            'candidate': root / 'python/akashadb/_kernel.so'}
hashes = {key: sha(path) for key, path in binaries.items()}
assert hashes['prior'] == '5ae85379b8948276ac2aba0e0fa1fd86447989c499562cc57fa1411b50c936fc'
(root / 'native-build.json').write_text(json.dumps(dict(command=command, exit_code=0,
    source_sha256=sources, kernel_sha256=hashes['candidate']), indent=2) + '\n')
assert not json.loads(subprocess.check_output(['rtk', 'proxy', 'docker', 'inspect',
                                              'akasha-linux-20261012']))[0]['State']['Running']
out = root / 'screen-pairs'
out.mkdir()
(out / 'identity.json').write_text(json.dumps(dict(binaries=hashes,
    scope='Serial implementation screen only. No new Qdrant comparison or acceptance claim.'), indent=2) + '\n')
env = dict(os.environ, PYTHONPATH=str(root / 'python') + ':.:' + str(root.parent / 'qdrant-runtime/deps'),
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
runs, pairs = [], []
for corpus in ('uniform-128', 'uniform-1536', 'real-1536'):
    plan = root / 'formal-plans' / (corpus + '-plan.json')
    plan_data = json.loads(plan.read_text())
    work = load_workload(frozen / 'warm-matrix' / corpus / 'workload.npz')
    expected = json.loads((parent / 'mixed-quartets' / (corpus + '-0-candidate.json')).read_text())
    for trial, order in enumerate((('prior', 'candidate'), ('candidate', 'prior'))):
        reports = {}
        for label in order:
            stem = f'{corpus}-{trial}-{label}'
            database = out / (stem + '-database')
            shutil.copytree(frozen / 'warm-matrix' / corpus / 'trial-0-akasha/database', database)
            job = dict(engine='akasha', kernel=str(binaries[label]), plan=str(plan),
                       database=str(database), output=str(out / (stem + '.json')))
            job_file = out / (stem + '-job.json')
            job_file.write_text(json.dumps(job, indent=2) + '\n')
            cmd = ['rtk', 'proxy', sys.executable, str(root / 'mixed_worker.py'), str(job_file)]
            print('starting', stem, flush=True)
            with (out / (stem + '.log')).open('w') as log:
                worker_env = dict(env, PYTHONPATH=str(binaries[label].parent.parent) + ':.:' + str(root.parent / 'qdrant-runtime/deps'))
                result = subprocess.run(cmd, env=worker_env, stdout=log, stderr=subprocess.STDOUT)
            runs.append(dict(corpus=corpus, trial=trial, label=label, command=cmd, returncode=result.returncode))
            (out / 'execution.json').write_text(json.dumps(runs, indent=2) + '\n')
            assert result.returncode == 0, (stem, (out / (stem + '.log')).read_text())
            report = json.loads(Path(job['output']).read_text())
            assert report['native_binary_sha256'] == hashes[label]
            assert report['plan_sha256'] == sha(plan)
            assert report['reopen_exact_oracle_match'] and report['lease_survived_close']
            assert validate_mixed_report(work, plan_data, report) == 288
            for actual, frozen_query in zip(report['queries'], expected['queries'], strict=True):
                assert all(actual[k] == frozen_query[k] for k in
                           ('block', 'mode', 'ids', 'score_bits', 'stats', 'execution', 'recall', 'oracle')), stem
            reports[label] = report
            print('verified', stem, flush=True)
        a, b = reports['prior'], reports['candidate']
        row = dict(corpus=corpus, trial=trial, order=order,
            modes=[dict(mode=x['mode'], qps_ratio=y['qps']/x['qps'], p95_ratio=y['p95_ns']/x['p95_ns'])
                   for x, y in zip(a['modes'], b['modes'], strict=True)],
            write_flush_ratio=(sum(b['writes'])+sum(b['flushes']))/(sum(a['writes'])+sum(a['flushes'])))
        pairs.append(row)
        (out / 'pairs.json').write_text(json.dumps(pairs, indent=2) + '\n')
        print(json.dumps(row), flush=True)
summary = [dict(corpus=corpus, modes=[dict(mode=mode,
    qps_ratio=statistics.median(cell['qps_ratio'] for row in pairs if row['corpus'] == corpus for cell in row['modes'] if cell['mode'] == mode),
    p95_ratio=statistics.median(cell['p95_ratio'] for row in pairs if row['corpus'] == corpus for cell in row['modes'] if cell['mode'] == mode))
    for mode in ('all', 'correlated', 'independent', 'selective')])
    for corpus in ('uniform-128', 'uniform-1536', 'real-1536')]
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
assert sources == {str(p.relative_to(root / 'src')): sha(p) for p in sorted((root / 'src').rglob('*.mojo'))}
print(json.dumps(summary), flush=True)
