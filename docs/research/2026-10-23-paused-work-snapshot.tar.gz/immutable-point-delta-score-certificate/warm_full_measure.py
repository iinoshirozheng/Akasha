"""Replay the existing full ef-grid query loop on each frozen trial's database.

No ingestion, graph rebuilding or ef selection is performed. All timing scopes,
query order, exact preflight and three initial warmups match qdrant_compare.
"""
import json,statistics,struct
from pathlib import Path
from benchmarks.qdrant_compare import (Akasha,Qdrant,MODES,_timed_query,
 execution_kind,latency_summary,load_workload,validate_result,file_sha256)

def result_payload(hits):
 return dict(ids=[int(h.id) for h in hits],scores_f32_hex=[struct.pack('<f',float(h.score)).hex() for h in hits])

def measure(job):
 corpus=Path(job['corpus']);spec=json.loads((corpus/'spec.json').read_text())
 data=load_workload(corpus/'workload.npz');oracle=json.loads((corpus/'oracle.json').read_text())
 assert data.checksum()==oracle['checksum']
 engine=job['engine'];factory=Akasha if engine=='akasha' else Qdrant
 if engine=='akasha':from akashadb import _kernel as native
 else:from qdrant_edge import qdrant_edge as native
 assert file_sha256(Path(native.__file__))==job['native_binary_sha256']
 report=dict(engine=engine,status='running',spec=spec,native_binary_sha256=job['native_binary_sha256'],workload_sha256=data.checksum(),measurements=[],exact_preflight=[],warmups=[],scope='Full unchanged ef-grid query loop on frozen trial-specific database clones. No fresh-build acceptance or ef retuning. Stats/validation outside timing. Three initial queries per mode/ef excluded from measured timing exactly as the existing warm protocol.')
 output=Path(job['output']);database=factory(Path(job['database']),spec,reopen=True)
 try:
  report['info']=database.info()
  elapsed,hits=_timed_query(database,data.queries[0,0].tolist(),'all',0,max(spec['efs']))
  first=result_payload(hits)
  report['first_query']=dict(latency_ns=elapsed,**first,recall=validate_result(data,first['ids'],oracle['ids'][0][0],'all',0),stats=database.stats())
  for mi,mode in enumerate(MODES):
   queries=[v.tolist() for v in data.queries[mi]]
   for ordinal,query in enumerate(queries):
    hits=database.search(database.request(query,mode,ordinal,128,exact=True))
    value=result_payload(hits)
    assert validate_result(data,value['ids'],oracle['ids'][mi][ordinal],mode,ordinal)==1.0
    report['exact_preflight'].append(dict(mode=mode,ordinal=ordinal,**value))
   for ef in spec['efs']:
    cell=dict(mode=mode,ef=ef,latency_ns=[],queries=[],execution_valid=True,execution_counts={})
    for ordinal,query in enumerate(queries):
     elapsed,hits=_timed_query(database,query,mode,ordinal,ef)
     value=result_payload(hits);stats=database.stats()
     recall=validate_result(data,value['ids'],oracle['ids'][mi][ordinal],mode,ordinal)
     execution=execution_kind(engine,mode,stats,recall,spec)
     row=dict(ordinal=ordinal,latency_ns=elapsed,**value,recall=recall,stats=stats,execution=execution)
     if ordinal<3:
      report['warmups'].append(dict(mode=mode,ef=ef,**row));continue
     cell['latency_ns'].append(elapsed);cell['queries'].append(row)
     cell['execution_valid'] &= execution!='invalid_fallback'
     cell['execution_counts'][execution]=cell['execution_counts'].get(execution,0)+1
    cell['recall']=statistics.mean(q['recall'] for q in cell['queries'])
    cell['quality_status']='PASSED' if cell['execution_valid'] and cell['recall']>=spec['target_recall'] else 'FAILED'
    cell.update(latency_summary(cell['latency_ns']));report['measurements'].append(cell)
    output.write_text(json.dumps(report,indent=2)+'\n')
  report['status']='ok'
 finally:
  database.close();output.write_text(json.dumps(report,indent=2)+'\n')
 # Reopen with an independent engine handle after all query/cache work.
 database=factory(Path(job['database']),spec,reopen=True)
 try:
  hits=database.search(database.request(data.queries[0,0].tolist(),'all',0,128,exact=True))
  assert [int(h.id) for h in hits]==oracle['ids'][0][0]
  report['reopen_exact_oracle_match']=True
 finally:database.close();output.write_text(json.dumps(report,indent=2)+'\n')
 return report
