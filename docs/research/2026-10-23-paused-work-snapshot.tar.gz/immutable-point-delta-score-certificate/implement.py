"""Extend query-local score transport and weak value proofs to scored delta rows."""
import difflib,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'src/akasha/index/segmented_hnsw.mojo'
before=path.read_text();source=before
def replace(old,new,count=1):
    global source
    assert source.count(old)==count,(old[:100],source.count(old),count)
    source=source.replace(old,new)
source=source.replace('_last_reused_base_scores','_last_reused_graph_scores').replace('base_scores','scores').replace('_BaseScoreProof','_GraphScoreProof').replace('_reusable_base_pair','_reusable_graph_pair').replace('_base_value_matches','_graph_value_matches')
replace('''    # Only the leading base candidates carry scores. Delta admission can avoid
    # scoring entirely, and cosine/compact graph scores are not authoritative.
''','''    # Leading F32 Dot/L2 candidates carry scores from this query. A delta
    # admission tail that skipped scoring has no scores to reuse.
''')
replace('    var score_proofs: List[_GraphScoreProof]\n','    var score_proofs: List[_GraphScoreProof]\n    var delta_score_proofs: List[_GraphScoreProof]\n')
replace('    self.score_proofs = List[_GraphScoreProof]()\n','    self.score_proofs = List[_GraphScoreProof]()\n        self.delta_score_proofs = List[_GraphScoreProof]()\n')
replace('''        allowed: AdmissionType,
    ) raises -> List[Int]:''','''        allowed: AdmissionType,
    ) raises -> _CollectedCandidates:''')
replace('''            var ids = List[Int](capacity=len(hits))
            for hit in hits:
                ids.append(hit.id)
            return ids^
''','''            var ids = List[Int](capacity=len(hits))
            var scores = List[Float32]()
            for hit in hits:
                ids.append(hit.id)
                comptime if backend_tag == DISTANCE_DOT_F32 or backend_tag == DISTANCE_L2_F32:
                    scores.append(hit.score)
            return _CollectedCandidates(ids^, scores^)
''')
replace('''        var results = List[Int]()
        if scoring:
''','''        var results = List[Int]()
        var scores = List[Float32]()
        if scoring:
''')
replace('''            for candidate in exact:
                results.append(candidate.id)
''','''            for candidate in exact:
                results.append(candidate.id)
                comptime if backend_tag == DISTANCE_DOT_F32 or backend_tag == DISTANCE_L2_F32:
                    scores.append(self._delta.metric.public_score(candidate.distance))
''')
replace('''        self._delta._last_search_upper_descents = 0
        return results^
''','''        self._delta._last_search_upper_descents = 0
        return _CollectedCandidates(results^, scores^)
''')
old='''            for id in delta_results:
                stats.delta_candidates += 1
                if single_source:
                    merged.append(id)
                elif id not in seen:
                    seen[id] = True
                    merged.append(id)
                    self._last_candidate_merge_insertions += 1
'''
new='''            for result_index in range(len(delta_results.ids)):
                var id = delta_results.ids[result_index]
                stats.delta_candidates += 1
                if single_source:
                    merged.append(id)
                    comptime if backend_tag == DISTANCE_DOT_F32 or backend_tag == DISTANCE_L2_F32:
                        if result_index < len(delta_results.scores):
                            scores.append(delta_results.scores[result_index])
                elif id not in seen:
                    seen[id] = True
                    merged.append(id)
                    comptime if backend_tag == DISTANCE_DOT_F32 or backend_tag == DISTANCE_L2_F32:
                        if result_index < len(delta_results.scores):
                            scores.append(delta_results.scores[result_index])
                    self._last_candidate_merge_insertions += 1
'''
replace(old,new,2)
replace('''        var slot: Int
        try:
            slot = self._sources.source_for(entry.id) - 1
        except:
            return False
        var dimension = self.config.dimension
''','''        var source: Int
        try:
            source = self._sources.source_for(entry.id)
        except:
            return False
        if source == _DELTA_SOURCE:
            return self._delta_value_matches(entry, row)
        var slot = source - 1
        var dimension = self.config.dimension
''')
needle='    def _finish_topk(mut self, var topk: BoundedTopK[]) -> List[SearchResult]:\n'
new='''    def _delta_value_matches(
        mut self, entry: MemTableEntry, row: _NumericReadView[DType.float32, _],
    ) -> Bool:
        # Delta replacements append a new physical slot. Its values never
        # change after publication; graph promotion replaces the source state,
        # which also discards this slot-addressed weak proof cache.
        var current = self._delta.graph.current_slot(entry.id)
        var dimension = self.config.dimension
        if not current or dimension <= 0 or len(row) != dimension:
            return False
        var slot = Int(current.value())
        var field = entry.field_ordinal(0)
        if field < 0:
            return False
        ref values = self._delta.graph.vector_scalars
        if slot >= len(values) // dimension:
            return False
        while len(self._sources._state[].delta_score_proofs) < self._delta.graph.slot_count():
            self._sources._state[].delta_score_proofs.append(
                _GraphScoreProof(WeakPointer[VectorValue](), False))
        ref proof = self._sources._state[].delta_score_proofs[slot]
        var previous = proof.owner.try_upgrade()
        if previous and previous.value() is entry._vectors[field]._value:
            return proof.equal
        var equal = external_call["memcmp", c_int](
            values.unsafe_ptr().unsafe_offset(slot * dimension).unsafe_bitcast[UInt8](),
            row._bytes.unsafe_ptr(), c_size_t(dimension * 4)) == 0
        if equal:
            try:
                var offset = 0
                while equal and offset + 16 <= len(row):
                    equal = isfinite(row.load[16](offset)).reduce_and()
                    offset += 16
                while equal and offset < len(row):
                    equal = isfinite(row[offset])
                    offset += 1
            except:
                equal = False
        proof.owner = WeakPointer[VectorValue](downgrade=entry._vectors[field]._value)
        proof.equal = equal
        return equal

'''
replace(needle,new+needle)
path.write_text(source)
for name in ['test_score_certificate.mojo','test_delta_score_certificate.mojo','test_hnsw_overlay_cache.mojo']:
    p=root/'tests'/name
    text=p.read_text().replace('_last_reused_base_scores','_last_reused_graph_scores').replace('_base_value_matches','_graph_value_matches').replace('.base_scores','.scores')
    p.write_text(text)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='parent/src/akasha/index/segmented_hnsw.mojo',tofile='candidate/src/akasha/index/segmented_hnsw.mojo')))
print('updated segmented_hnsw only; query-local delta score transport + weak immutable-value checks')
