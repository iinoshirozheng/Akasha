import importlib.util
import json
from pathlib import Path
import sys

job = json.loads(Path(sys.argv[1]).read_text())
if job['engine'] == 'akasha':
    import akashadb
    spec = importlib.util.spec_from_file_location('akashadb._kernel', job['kernel'])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules['akashadb._kernel'] = module
    akashadb._kernel = module
    from akashadb.database import _kernel_module
    assert _kernel_module() is module
    assert Path(module.__file__).resolve() == Path(job["kernel"]).resolve()

from mixed_measure import measure
measure(job['engine'], Path(job['plan']), Path(job['database']), Path(job['output']))
