"""Recompute raw latency/quality gates and diagnostic CPU ratios independently."""
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

root=Path(__file__).resolve().parent
def load(path):return json.loads(path.read_text())
full=root/'mixed-quartets';runs=load(full/'execution.json')
assert len(runs)==36 and all(row['returncode']==0 for row in runs)
reports={};files={}
for row in runs:
    key=tuple(row[k] for k in ('corpus','trial','label'))
    p=full/('-'.join(map(str,key))+'.json');report=load(p)
    files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
    assert len(report['queries'])==288
    for mode in report['modes']:
        queries=[q for q in report['queries'] if q['mode']==mode['mode']]
        values=sorted(q['latency_ns'] for q in queries)
        assert len(values)==72 and min(values)>0
        assert mode['qps']==len(values)*1e9/sum(values)
        assert mode['p95_ns']==values[math.ceil(len(values)*.95)-1]
        assert mode['recall']==statistics.mean(len(set(q['ids'])&set(q['oracle']))/len(q['oracle']) for q in queries)
    reports[key]=report
gates={label:dict(quality=0,speed=0,cells=36,write_flush=0) for label in ('production','prior','candidate')}
failures=[];gains=[];lost=[]
for corpus in ('uniform-128','uniform-1536','real-1536'):
    for trial in range(3):
        qdrant=reports[corpus,trial,'qdrant']
        status={}
        for label in gates:
            report=reports[corpus,trial,label]
            qwrite=sum(qdrant['writes'])+sum(qdrant['flushes'])
            awrite=sum(report['writes'])+sum(report['flushes'])
            gates[label]['write_flush']+=int(awrite<=qwrite)
            for a,q in zip(report['modes'],qdrant['modes'],strict=True):
                assert a['mode']==q['mode']
                quality=min(a['recall'],q['recall'])>=.95 and a['execution_valid'] and q['execution_valid']
                speed=quality and a['qps']>=q['qps'] and a['p95_ns']<=q['p95_ns']
                gates[label]['quality']+=int(quality);gates[label]['speed']+=int(speed)
                status[label,a['mode']]=speed
                if not speed:
                    failures.append(dict(corpus=corpus,trial=trial,label=label,mode=a['mode'],quality=quality,
                        akasha_recall=a['recall'],qdrant_recall=q['recall'],
                        qps_ratio=a['qps']/q['qps'] if quality else None,
                        p95_ratio=a['p95_ns']/q['p95_ns'] if quality else None))
        for mode in ('all','correlated','independent','selective'):
            if not status['prior',mode] and status['candidate',mode]:gains.append(dict(corpus=corpus,trial=trial,mode=mode))
            for label in ('production','prior'):
                if status[label,mode] and not status['candidate',mode]:lost.append(dict(corpus=corpus,trial=trial,mode=mode,baseline=label))
assert gates==load(full/'summary.json')['gates']
rows=load(full/'trials.json');medians=[]
for corpus in ('uniform-128','uniform-1536','real-1536'):
    modes=[]
    for mode in ('all','correlated','independent','selective'):
        values=[]
        for trial in range(3):
            a=next(m for m in reports[corpus,trial,'prior']['modes'] if m['mode']==mode)
            b=next(m for m in reports[corpus,trial,'candidate']['modes'] if m['mode']==mode)
            value=dict(qps_ratio=b['qps']/a['qps'],p95_ratio=b['p95_ns']/a['p95_ns'])
            recorded=next(c for r in rows if r['corpus']==corpus and r['trial']==trial for c in r['prior_ratios'] if c['mode']==mode)
            assert all(recorded[k]==v for k,v in value.items())
            values.append(value)
        modes.append(dict(mode=mode,**{k:statistics.median(v[k] for v in values) for k in ('qps_ratio','p95_ratio')}))
    medians.append(dict(corpus=corpus,modes=modes))

assert sorted((x['corpus'],x['trial'],x['mode']) for x in lost if x['baseline']=='prior') == sorted((x['corpus'],x['trial'],x['mode']) for x in load(full/'summary.json')['prior_pass_to_fail'])
identity=load(full/'identity.json')
for (corpus,trial,label),report in reports.items():
    assert report['native_binary_sha256']==identity['binaries'][label]
    assert report['plan_sha256']==hashlib.sha256((root/'formal-plans'/(corpus+'-plan.json')).read_bytes()).hexdigest()
    assert report['reopen_exact_oracle_match']
    if label!='qdrant': assert report['lease_survived_close']
    for other in ('production','prior') if label=='candidate' else ():
        for a,b in zip(report['queries'],reports[corpus,trial,other]['queries'],strict=True):
            assert all(a[k]==b[k] for k in ('block','mode','ids','score_bits','recall','oracle','stats','execution'))
result=dict(gates=gates,failed_cells=failures,prior_failed_to_passed=gains,pass_to_fail=lost,
    prior_medians=medians,full_raw_report_sha256=files,full_workers=36,full_timed_responses=10368,
    exact_reopens=36,retained_leases=27,warmup_returns_not_compared=108,
    scope='Complete mixed comparison recalculated from all raw latencies. The only plan change is the user-authorized Qdrant real-1536 correlated ef=128. No warm/concurrent or capacity acceptance inferred.')
(root/'results-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('full_raw_report_sha256','failed_cells','prior_medians')}),flush=True)
