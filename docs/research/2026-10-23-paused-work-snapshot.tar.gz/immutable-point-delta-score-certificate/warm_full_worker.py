"""Load the exact retained native package before running one matrix worker."""
import importlib.util,json,sys
from pathlib import Path

def main():
 job=json.loads(Path(sys.argv[1]).read_text())
 if job['engine']=='akasha':
  import akashadb
  spec=importlib.util.spec_from_file_location('akashadb._kernel',job['kernel'])
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  sys.modules['akashadb._kernel']=module;akashadb._kernel=module
 if job['phase']=='warm':
  from warm_full_measure import measure
 else:
  from benchmarks.qdrant_concurrent import measure
 measure(job)

if __name__=='__main__':main()
