"""Freeze exact inputs and source provenance; never rebuild or rerun timers."""
import difflib, hashlib, json, shutil, subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[2]
parent = root.parent / 'immutable-point-score-certificate'
frozen = root.parent / 'delta-admission-first/known-count/warm-matrix'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
source = {str(p.relative_to(parent/'src')): sha(p) for p in sorted((parent/'src').rglob('*.mojo'))}
current = load(root/'candidate-source.json')
changed = [name for name in source if source[name] != current[name]]
assert changed == ['akasha/index/segmented_hnsw.mojo']
patch = []
for name in changed:
    target = root/'prior-source'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(parent/'src'/name, target)
    patch.extend(difflib.unified_diff(target.read_text().splitlines(True), (root/'src'/name).read_text().splitlines(True), fromfile='prior/'+name, tofile='candidate/'+name))
(root/'source.patch').write_text(''.join(patch))
(root/'upstream').mkdir(exist_ok=True)
inputs = {}
for corpus in ('uniform-128', 'uniform-1536', 'real-1536'):
    target = root/'inputs'/corpus
    target.mkdir(exist_ok=True)
    for name in ('spec.json', 'oracle.json'):
        shutil.copy2(frozen/corpus/name, target/name)
    shutil.copy2(parent/'mixed-quartets'/f'{corpus}-0-candidate.json', target/'expected-mixed.json')
    previous = (root.parent/'immutable-point-goal-baseline/qdrant-quality-probes/real-1536-0-qdrant-ef-128.json' if corpus == 'real-1536' else root.parent/'immutable-point-goal-baseline/baseline'/f'{corpus}-0-qdrant.json')
    shutil.copy2(previous, target/'expected-qdrant.json')
    inputs[corpus] = dict(workload_npz_sha256=sha(frozen/corpus/'workload.npz'), plan_sha256=sha(root/'formal-plans'/f'{corpus}-plan.json'), source_databases={engine: {str(p.relative_to(frozen/corpus/f'trial-0-{engine}/database')): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted((frozen/corpus/f'trial-0-{engine}/database').rglob('*')) if p.is_file()} for engine in ('akasha', 'qdrant')})
benchmarks = {}
for name in ('qdrant_compare.py', 'qdrant_workload.py'):
    target = root/'repository/benchmarks'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo/'benchmarks'/name, target)
    benchmarks[name] = sha(target)
upstream = {}
pin = '21db2f3ff95d50de3a2b88a741312c056fd1762d'
for name, path in [('qdrant-LICENSE', 'LICENSE'), ('point_scorer.rs', 'lib/segment/src/index/hnsw_index/point_scorer.rs')]:
    data = subprocess.check_output(['rtk', 'proxy', 'git', '-C', str(repo/'reference/qdrant-edge-0.8.0'), 'show', pin+':'+path])
    (root/'upstream'/name).write_bytes(data)
    upstream[path] = hashlib.sha256(data).hexdigest()
identity = dict(parent_source=source, changed_files=changed, parent_native_sha256=sha(parent/'python/akashadb/_kernel.so'), parent_archive_sha256=sha(repo/'docs/research/2026-10-23-immutable-point-score-certificate.json.gz'), inputs=inputs, benchmarks=benchmarks, qdrant_pin=pin, qdrant_source=upstream, compiler='Mojo 1.0.0 (ed45d567)', python_source={str(p.relative_to(root)):sha(p) for p in sorted((root/'python').rglob('*.py'))}, scope='Same-query F32 Dot/L2 delta scores use weak immutable-value certificates after exact byte/finite proof. Source-state replacement discards all proofs. Full fixed-graph mixed and warm replay; no fresh builds, client, capacity or native Linux acceptance.')
(root/'identity.json').write_text(json.dumps(identity, indent=2)+'\n')
print(json.dumps(dict(sources=len(source), changed_files=changed, inputs=len(inputs))))
