"""Recompute full warm gates and compare every response to frozen controls."""
import hashlib,json,math,statistics
from collections import Counter
from pathlib import Path
root=Path(__file__).resolve().parent;out=root/'warm-quartets'
load=lambda p:json.loads(p.read_text())
identity=load(out/'identity.json');runs=load(out/'execution.json');trials=load(out/'trials.json')
control_identity=load(root/'inputs/full-warm/identity.json')
for name,digest in control_identity['sha256'].items():
 assert hashlib.sha256((root/'inputs/full-warm'/name).read_bytes()).hexdigest()==digest
assert len(runs)==36 and all(r['exit_code']==0 for r in runs)
assert len(trials)==9
selected={};counts=Counter();hashes={};controls={}
for run in runs:
 corpus,trial,label=(run[k] for k in ('corpus','trial','label'));engine='qdrant' if label=='qdrant' else 'akasha'
 path=out/f'{corpus}-{trial}-{label}/report.json';report=load(path)
 hashes[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
 key=corpus,trial,engine
 if key not in controls:controls[key]=load(root/'inputs/full-warm'/f'{corpus}-{trial}-{engine}.json')
 expected=controls[key]
 assert report['status']=='ok' and report['native_binary_sha256']==identity['binaries'][label] and report['reopen_exact_oracle_match']
 counts['exact_reopens']+=1
 assert len(report['measurements'])==48 and len(report['warmups'])==144 and len(report['exact_preflight'])==268
 assert report['exact_preflight']==expected['exact_preflight'];counts['exact_preflight']+=268
 for a,b in zip(report['warmups'],expected['warmups'],strict=True):
  assert all(a[k]==b[k] for k in ('mode','ef','ordinal','ids','scores_f32_hex','recall','stats','execution'))
  counts['warmup_responses']+=1
 for m,prior in zip(report['measurements'],expected['measurements'],strict=True):
  assert m['mode']==prior['mode'] and m['ef']==prior['ef']
  queries=m['queries'];ns=m['latency_ns'];assert len(queries)==len(ns)==64
  assert [q['ordinal'] for q in queries]==list(range(3,67))
  assert ns==[q['latency_ns'] for q in queries] and min(ns)>0
  assert m['qps']==64*1e9/sum(ns)
  for p in (50,95,99):assert m[f'p{p}_ns']==sorted(ns)[math.ceil(p/100*64)-1]
  assert m['recall']==statistics.mean(q['recall'] for q in queries)
  assert m['execution_counts']==dict(Counter(q['execution'] for q in queries))
  assert m['execution_valid']==all(q['execution']!='invalid_fallback' for q in queries)
  assert (m['quality_status']=='PASSED')==(m['recall']>=.95 and m['execution_valid'])
  for a,b in zip(queries,prior['queries'],strict=True):
   assert all(a[k]==b[k] for k in ('ordinal','ids','scores_f32_hex','recall','stats','execution'))
   counts['measured_responses']+=1
  mi=('all','correlated','independent','selective').index(m['mode'])
  if m['ef']==identity['selection'][corpus][trial][engine][mi]:selected[corpus,trial,label,m['mode']]=m
gates={label:dict(cells=36,quality=0,passed=0) for label in ('production','prior','candidate')}
lost=[];gains=[];ratios=[];failures=[]
for row in trials:
 corpus,trial=row['corpus'],row['trial']
 for label,cells in row['cells'].items():
  for cell in cells:
   mode=cell['mode'];a=selected[corpus,trial,label,mode];q=selected[corpus,trial,'qdrant',mode]
   quality=a['quality_status']==q['quality_status']=='PASSED'
   passed=quality and a['qps']>=q['qps'] and a['p95_ns']<=q['p95_ns']
   assert cell['quality']==quality and cell['passed']==passed
   assert cell['qps_ratio']==a['qps']/q['qps'] and cell['p95_ratio']==a['p95_ns']/q['p95_ns']
   gates[label]['quality']+=quality;gates[label]['passed']+=passed
   if not passed:failures.append(dict(corpus=corpus,trial=trial,label=label,**cell))
 for label in ('production','prior'):
  for a,b in zip(row['cells'][label],row['cells']['candidate'],strict=True):
   if a['passed'] and not b['passed']:lost.append(dict(corpus=corpus,trial=trial,mode=a['mode'],baseline=label))
   if label=='prior' and not a['passed'] and b['passed']:gains.append(dict(corpus=corpus,trial=trial,mode=a['mode']))
 for mode in ('all','correlated','independent','selective'):
  a=selected[corpus,trial,'prior',mode];b=selected[corpus,trial,'candidate',mode]
  ratios.append(dict(corpus=corpus,trial=trial,mode=mode,qps_ratio=b['qps']/a['qps'],p95_ratio=b['p95_ns']/a['p95_ns']))
assert dict(gates=gates,pass_to_fail=lost)==load(out/'summary.json')
medians=[dict(corpus=c,mode=m,**{f:statistics.median(r[f] for r in ratios if r['corpus']==c and r['mode']==m) for f in ('qps_ratio','p95_ratio')}) for c in ('uniform-128','uniform-1536','real-1536') for m in ('all','correlated','independent','selective')]
result=dict(gates=gates,pass_to_fail=lost,prior_failed_to_passed=gains,counts=dict(counts),prior_ratios=ratios,prior_medians=medians,failed_cells=failures,raw_sha256=hashes,scope='Full-grid fixed-graph replay, not fresh builds. Raw latencies and all selected gates audited. All measured and warmup IDs/F32 bits/stats/routes match corresponding frozen trial controls.')
(root/'warm-results-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('gates','pass_to_fail','prior_failed_to_passed','counts','scope')}),flush=True)
