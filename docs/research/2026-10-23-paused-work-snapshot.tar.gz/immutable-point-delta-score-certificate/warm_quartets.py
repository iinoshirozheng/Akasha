"""Full ef-grid frozen-graph replay, paired production/prior/candidate/Qdrant."""
import hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
base=root.parent/'delta-admission-first/known-count/warm-matrix'
matrix=root.parent/'immutable-point-local-matrix';runtime=root.parent/'qdrant-runtime'
identity=json.loads((matrix/'identity.json').read_text())
mixed=json.loads((root/'mixed-quartets/identity.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
kernels=dict(production=root.parent/'mapped-cache-decode/mapped-native-kernel.so',prior=root.parent/'immutable-point-score-certificate/python/akashadb/_kernel.so',candidate=root/'python/akashadb/_kernel.so')
assert all(sha(p)==mixed['binaries'][k] for k,p in kernels.items())
assert sha(next((runtime/'deps/qdrant_edge').glob('*.so')))==mixed['binaries']['qdrant']
assert not json.loads(subprocess.check_output(['rtk','proxy','docker','inspect','akasha-linux-20261012']))[0]['State']['Running']
out=root/'warm-quartets';out.mkdir()
(out/'identity.json').write_text(json.dumps(dict(binaries=mixed['binaries'],selection=identity['selection'],source_database_files=identity['source_database_files'],scope='Complete fixed-graph warm replay, full ef grid. Corresponding frozen graphs for each trial, no rebuild. Same warm worker as archived local matrix. Qdrant real correlated ef128 only authorized change.'),indent=2)+'\n')
runs=[];trials=[];labels=('production','prior','candidate','qdrant')
def health():
 result={}
 for name,command in [('vm_stat',['rtk','proxy','vm_stat']),('swap',['rtk','proxy','sysctl','vm.swapusage']),('thermal',['rtk','proxy','pmset','-g','therm'])]:
  p=subprocess.run(command,capture_output=True,text=True);result[name]=dict(exit_code=p.returncode,output=p.stdout+p.stderr)
 return result
for corpus in ('uniform-128','uniform-1536','real-1536'):
 for trial in range(3):
  reports={};order=labels[trial:]+labels[:trial]
  for label in order:
   engine='qdrant' if label=='qdrant' else 'akasha';stem=f'{corpus}-{trial}-{label}'
   directory=out/stem;directory.mkdir()
   source=base/corpus/f'trial-{trial}-{engine}/database'
   assert {str(p.relative_to(source)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(source.rglob('*')) if p.is_file()}==identity['source_database_files'][f'{corpus}/{trial}/{engine}']
   shutil.copytree(source,directory/'database')
   job=dict(phase='warm',engine=engine,corpus=str(base/corpus),database=str(directory/'database'),efs=identity['selection'][corpus][trial][engine],native_binary_sha256=mixed['binaries'][label],output=str(directory/'report.json'))
   if engine=='akasha':job['kernel']=str(kernels[label])
   jobpath=directory/'job.json';jobpath.write_text(json.dumps(job,indent=2)+'\n')
   command=['rtk','proxy',sys.executable,str(root/'warm_full_worker.py'),str(jobpath)]
   package=kernels[label].parent.parent if label in ('prior','candidate') else root/'python'
   env=dict(os.environ,PYTHONPATH=str(package)+':.:'+str(runtime/'deps'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
   print('starting',stem,flush=True);before=health();started=time.monotonic()
   with (directory/'worker.log').open('w') as log:
    p=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=p.wait(timeout=300)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGKILL);p.wait();raise
   runs.append(dict(corpus=corpus,trial=trial,label=label,command=command,exit_code=code,seconds=time.monotonic()-started,before=before,after=health()))
   (out/'execution.json').write_text(json.dumps(runs,indent=2)+'\n')
   assert code==0,(directory/'worker.log').read_text()
   report=json.loads((directory/'report.json').read_text());expected=json.loads((matrix/'warm'/f'{corpus}-c0-t{trial}-{engine}/report.json').read_text())
   assert report['status']=='ok' and report['native_binary_sha256']==mixed['binaries'][label] and report['reopen_exact_oracle_match']
   for cell,old in zip(report['measurements'],expected['measurements'],strict=True):
    assert cell['mode']==old['mode'] and cell['ef']==old['ef']
    for a,b in zip(cell['queries'],old['queries'],strict=True):
     assert all(a[k]==b[k] for k in ('ordinal','ids','scores_f32_hex','recall','stats','execution')),(stem,cell['mode'],cell['ef'],a['ordinal'])
   reports[label]=report
  row=dict(corpus=corpus,trial=trial,order=order,cells={})
  for label in labels[:-1]:
   cells=[]
   for mi,mode in enumerate(('all','correlated','independent','selective')):
    a=next(m for m in reports[label]['measurements'] if m['mode']==mode and m['ef']==identity['selection'][corpus][trial]['akasha'][mi])
    q=next(m for m in reports['qdrant']['measurements'] if m['mode']==mode and m['ef']==identity['selection'][corpus][trial]['qdrant'][mi])
    valid=a['quality_status']==q['quality_status']=='PASSED'
    cells.append(dict(mode=mode,quality=valid,passed=valid and a['qps']>=q['qps'] and a['p95_ns']<=q['p95_ns'],qps_ratio=a['qps']/q['qps'],p95_ratio=a['p95_ns']/q['p95_ns']))
   row['cells'][label]=cells
  trials.append(row);(out/'trials.json').write_text(json.dumps(trials,indent=2)+'\n');print('audited',corpus,trial,{k:sum(c['passed'] for c in v) for k,v in row['cells'].items()},flush=True)
summary={label:dict(cells=36,quality=sum(c['quality'] for row in trials for c in row['cells'][label]),passed=sum(c['passed'] for row in trials for c in row['cells'][label])) for label in labels[:-1]}
lost=[dict(corpus=row['corpus'],trial=row['trial'],mode=a['mode'],baseline=label) for row in trials for label in labels[:2] for a,b in zip(row['cells'][label],row['cells']['candidate'],strict=True) if a['passed'] and not b['passed']]
(out/'summary.json').write_text(json.dumps(dict(gates=summary,pass_to_fail=lost),indent=2)+'\n');print(json.dumps(dict(gates=summary,pass_to_fail=lost)),flush=True)
