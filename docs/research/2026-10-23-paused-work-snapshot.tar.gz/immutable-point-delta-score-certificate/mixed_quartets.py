"""User-authorized recalibrated mixed protocol with complete production/prior/candidate/Qdrant matrix."""
import hashlib, json, os, shutil, statistics, subprocess, sys
from pathlib import Path
from mixed_measure import matched_mixed_summary, validate_mixed_report
from benchmarks.qdrant_workload import load_workload

root = Path(__file__).resolve().parent
out = root/'mixed-quartets'
out.mkdir()
frozen = root.parent/'delta-admission-first/known-count'
runtime = root.parent/'qdrant-runtime'
assert not json.loads(subprocess.check_output(['rtk','proxy','docker','inspect','akasha-linux-20261012']))[0]['State']['Running']
kernels = {'production': root.parent/'mapped-cache-decode/mapped-native-kernel.so',
           'prior': root.parent/'immutable-point-score-certificate/python/akashadb/_kernel.so',
           'candidate': root/'python/akashadb/_kernel.so'}
binary_hashes = {name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in kernels.items()}
assert binary_hashes['production'] == 'f4d7736f453e8e0187860f6dd15eb998b586083bcf9a4ef6dd0a84cf98a55067'
assert binary_hashes['prior'] == '5ae85379b8948276ac2aba0e0fa1fd86447989c499562cc57fa1411b50c936fc'
assert binary_hashes['candidate'] == json.loads((root/'native-build.json').read_text())['kernel_sha256']
qdrant = next((runtime/'deps/qdrant_edge').glob('*.so'))
binary_hashes['qdrant'] = hashlib.sha256(qdrant.read_bytes()).hexdigest()
assert binary_hashes['qdrant'] == '746ce4acdbb56db68aaba805bddf52961a083c5ed5da19f16b5ba500114c788d'
env = dict(os.environ, PYTHONPATH=str(root/'python')+':.:'+str(runtime/'deps'),
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
labels = ('production','prior','candidate','qdrant')
(out/'identity.json').write_text(json.dumps(dict(binaries=binary_hashes,labels=labels,
    plan_authorization=json.loads((root/'formal-plans/authorization.json').read_text()),
    scope='Complete mixed rerun after explicit user-authorized Qdrant real-1536 correlated ef=128. Every other field and strict gate unchanged. No warm/concurrent, sustained-capacity or native Linux claim.'),indent=2)+'\n')
runs, trials = [], []
for corpus in ('uniform-128','uniform-1536','real-1536'):
    plan = root/'formal-plans'/(corpus+'-plan.json')
    plan_data = json.loads(plan.read_text())
    work = load_workload(frozen/'warm-matrix'/corpus/'workload.npz')
    for trial in range(3):
        reports = {}
        order = labels[trial:]+labels[:trial]
        for label in order:
            engine = 'qdrant' if label=='qdrant' else 'akasha'
            stem = f'{corpus}-{trial}-{label}'
            database = out/(stem+'-database')
            shutil.copytree(frozen/'warm-matrix'/corpus/('trial-0-'+engine)/'database',database)
            job = dict(engine=engine,plan=str(plan),database=str(database),output=str(out/(stem+'.json')))
            if engine=='akasha': job['kernel']=str(kernels[label])
            job_file=out/(stem+'-job.json')
            job_file.write_text(json.dumps(job,indent=2)+'\n')
            command=['rtk','proxy',sys.executable,str(root/'mixed_worker.py'),str(job_file)]
            with (out/(stem+'.log')).open('w') as log:
                worker_env = env
                if label in ('prior', 'candidate'):
                    worker_env = dict(env, PYTHONPATH=str(kernels[label].parent.parent)+':.:'+str(runtime/'deps'))
                result=subprocess.run(command,env=worker_env,stdout=log,stderr=subprocess.STDOUT)
            runs.append(dict(corpus=corpus,trial=trial,label=label,command=command,returncode=result.returncode))
            (out/'execution.json').write_text(json.dumps(runs,indent=2)+'\n')
            assert result.returncode==0,(stem,(out/(stem+'.log')).read_text())
            report=json.loads(Path(job['output']).read_text())
            assert report['native_binary_sha256']==binary_hashes[label]
            assert report['plan_sha256']==hashlib.sha256(plan.read_bytes()).hexdigest()
            assert report['reopen_exact_oracle_match']
            if engine=='akasha':
                assert report['lease_survived_close']
                assert all(m['recall']>=.95 and m['execution_valid'] for m in report['modes'])
            assert validate_mixed_report(work,plan_data,report)==288
            if engine=='qdrant':
                previous_path = (root.parent/'immutable-point-goal-baseline/qdrant-quality-probes/real-1536-0-qdrant-ef-128.json' if corpus=='real-1536' else root.parent/'immutable-point-goal-baseline/baseline'/f'{corpus}-0-qdrant.json')
                previous=json.loads(previous_path.read_text())
                for a,b in zip(previous['queries'],report['queries'],strict=True):
                    assert all(a[k]==b[k] for k in ('block','mode','ids','score_bits','recall','oracle','stats','execution')),(corpus,trial,'qdrant exact')
            reports[label]=report
            print('completed',stem,flush=True)
        for left,right in zip(reports['production']['queries'],reports['candidate']['queries'],strict=True):
            assert all(left[k]==right[k] for k in ('block','mode','ids','score_bits','recall','oracle','stats','execution')),(corpus,trial)
        for left,right in zip(reports['prior']['queries'],reports['candidate']['queries'],strict=True):
            assert all(left[k]==right[k] for k in ('block','mode','ids','score_bits','recall','oracle','stats','execution')),(corpus,trial,'prior')
        left,right=reports['production'],reports['candidate']
        row=dict(corpus=corpus,trial=trial,order=order,
            modes=[dict(mode=a['mode'],qps_ratio=z['qps']/a['qps'],p95_ratio=z['p95_ns']/a['p95_ns']) for a,z in zip(left['modes'],right['modes'],strict=True)],
            flush_ratio=sum(right['flushes'])/sum(left['flushes']),qdrant={})
        for label in ('production','prior','candidate'):
            row['qdrant'][label]=matched_mixed_summary(reports[label],reports['qdrant'])
        row['pass_to_fail']=[a['mode'] for a,b in zip(row['qdrant']['production'],row['qdrant']['candidate'],strict=True) if a['status']=='PASSED' and b['status']!='PASSED']
        row['prior_pass_to_fail']=[a['mode'] for a,b in zip(row['qdrant']['prior'],row['qdrant']['candidate'],strict=True) if a['status']=='PASSED' and b['status']!='PASSED']
        row['prior_ratios']=[dict(mode=a['mode'],qps_ratio=b['qps']/a['qps'],p95_ratio=b['p95_ns']/a['p95_ns']) for a,b in zip(reports['prior']['modes'],reports['candidate']['modes'],strict=True)]
        row['write_flush']={}
        qtime=sum(reports['qdrant']['writes'])+sum(reports['qdrant']['flushes'])
        for label in ('production','prior','candidate'):
            atime=sum(reports[label]['writes'])+sum(reports[label]['flushes'])
            row['write_flush'][label]=dict(ns=atime,qdrant_ns=qtime,ratio=atime/qtime,passed=atime<=qtime)
        trials.append(row)
        (out/'trials.json').write_text(json.dumps(trials,indent=2)+'\n')
        print('audited',corpus,trial,flush=True)
gates={label:dict(quality=sum(cell['quality_status']=='PASSED' for row in trials for cell in row['qdrant'][label]),
                 speed=sum(cell['status']=='PASSED' for row in trials for cell in row['qdrant'][label]),cells=36,
                 write_flush=sum(row['write_flush'][label]['passed'] for row in trials)) for label in ('production','prior','candidate')}
summary=[]
for corpus in ('uniform-128','uniform-1536','real-1536'):
    rows=[row for row in trials if row['corpus']==corpus]
    summary.append(dict(corpus=corpus,flush_ratio=statistics.median(row['flush_ratio'] for row in rows),
        modes=[dict(mode=mode,qps_ratio=statistics.median(m['qps_ratio'] for row in rows for m in row['modes'] if m['mode']==mode),
                    p95_ratio=statistics.median(m['p95_ratio'] for row in rows for m in row['modes'] if m['mode']==mode))
               for mode in ('all','correlated','independent','selective')]))
result=dict(gates=gates,summary=summary,pass_to_fail=[dict(corpus=row['corpus'],trial=row['trial'],mode=mode) for row in trials for mode in row['pass_to_fail']])
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
result['prior_pass_to_fail']=[dict(corpus=row['corpus'],trial=row['trial'],mode=mode) for row in trials for mode in row['prior_pass_to_fail']]
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
