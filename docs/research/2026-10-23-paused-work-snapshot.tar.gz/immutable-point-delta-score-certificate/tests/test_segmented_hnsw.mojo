from akasha.common.config import CollectionConfig, MetricKind
from akasha.index.bitmap import Bitmap
from akasha.index.hnsw import HnswIndex
from akasha.index.hnsw_entries import entries_from_legacy
from akasha.index.hnsw_core import HnswEligibility, HnswIdOrdinalLookup
from akasha.index.segmented_hnsw import SegmentedHnsw, _SourceAdmission
from akasha.storage.filesystem import remove_file_if_exists, write_file_sync
from akasha.storage.hnsw_store import (
    encode_hnsw_snapshot,
    open_hnsw_snapshot_view,
)
from akasha.storage.memtable import MemTable
from std.collections import Dict
from std.testing import (
    assert_equal,
    assert_false,
    assert_raises,
    assert_true,
    TestSuite,
)


def _config(*, delta_max_points: Int = 8) -> CollectionConfig:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.l2()
    config.m = 4
    config.m0 = 8
    config.ef_construction = 24
    config.default_ef_search = 16
    config.max_ef_search = 256
    config.max_level = 4
    config.delta_max_points = delta_max_points
    return config^


def _base(config: CollectionConfig, mut table: MemTable) raises -> HnswIndex:
    var base = HnswIndex(config)
    for id in range(1, 5):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id), values.copy())
        base.add(id, values^)
    return base^


def _lookup(table: MemTable) raises -> HnswIdOrdinalLookup:
    var ordinals = Dict[Int, Int]()
    for ordinal in range(table.slot_count()):
        ordinals[table.id_at(ordinal)] = ordinal
    return HnswIdOrdinalLookup(ordinals^, table.slot_count())


def _chain_base(
    config: CollectionConfig, mut table: MemTable
) raises -> HnswIndex:
    var index = HnswIndex(config)
    for ordinal in range(4):
        var id = 10 + ordinal
        var values: List[Float32] = [Float32(ordinal)]
        table.apply_upsert(id, UInt64(id), values.copy())
        var level = 1 if ordinal == 0 else 0
        var slot = index.graph.append(id, values^, level)
        if ordinal == 0:
            index.entry_slot = Optional(slot)
            index.entry_level = 1
    index.graph.set_neighbors(UInt32(0), 0, [UInt32(1)])
    index.graph.set_neighbors(UInt32(1), 0, [UInt32(0), UInt32(2)])
    index.graph.set_neighbors(UInt32(2), 0, [UInt32(1), UInt32(3)])
    index.graph.set_neighbors(UInt32(3), 0, [UInt32(2)])
    index.build_stats.slot_count = 4
    index.build_stats.maximum_level = 1
    index.entries = entries_from_legacy(index.graph, index.entry_slot)
    return index^


def _long_chain_base(
    config: CollectionConfig, mut table: MemTable
) raises -> HnswIndex:
    var index = HnswIndex(config)
    for ordinal in range(6):
        var id = 20 + ordinal
        var values: List[Float32] = [Float32(ordinal)]
        table.apply_upsert(id, UInt64(id), values.copy())
        var slot = index.graph.append(id, values^, 0)
        if ordinal == 0:
            index.entry_slot = Optional(slot)
            index.entry_level = 0
    for ordinal in range(6):
        var neighbors = List[UInt32]()
        if ordinal > 0:
            neighbors.append(UInt32(ordinal - 1))
        if ordinal + 1 < 6:
            neighbors.append(UInt32(ordinal + 1))
        index.graph.set_neighbors(UInt32(ordinal), 0, neighbors^)
    index.build_stats.slot_count = 6
    index.build_stats.maximum_level = 0
    index.build_stats.directed_edges = 10
    index.entries = entries_from_legacy(index.graph, index.entry_slot)
    return index^


def test_base_only_and_delta_only_fast_paths() raises:
    var config = _config()
    var base_table = MemTable(1)
    var base = _base(config.copy(), base_table)
    var base_only = SegmentedHnsw.from_owned(base^)
    var base_lookup = _lookup(base_table)
    var base_result = base_only.search([4.0], 2, 16, base_table, base_lookup)
    assert_equal(base_result[0].id, 4)
    assert_equal(base_only.last_search_stats().base_candidates, 4)
    assert_equal(base_only.last_search_stats().delta_candidates, 0)

    var delta_table = MemTable(1)
    var delta_only = SegmentedHnsw(config)
    for id in range(10, 14):
        var values: List[Float32] = [Float32(id)]
        delta_table.apply_upsert(id, UInt64(id), values.copy())
        delta_only.upsert(id, values^)
    var delta_lookup = _lookup(delta_table)
    var delta_result = delta_only.search(
        [13.0], 2, 16, delta_table, delta_lookup
    )
    assert_equal(delta_result[0].id, 13)
    assert_equal(delta_only.last_search_stats().base_candidates, 0)
    assert_equal(delta_only.last_search_stats().delta_candidates, 4)
    assert_equal(base_only.last_candidate_merge_insertions(), 0)
    assert_equal(delta_only.last_candidate_merge_insertions(), 0)


def test_merged_topk_uses_candidates_from_both_sources() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    table.apply_upsert(10, UInt64(10), [4.25])
    index.upsert(10, [4.25])

    var lookup = _lookup(table)
    var result = index.search([4.1], 3, 16, table, lookup)
    assert_equal(result[0].id, 4)
    assert_equal(result[1].id, 10)
    assert_equal(result[2].id, 3)
    assert_true(index.last_search_stats().base_candidates > 0)
    assert_true(index.last_search_stats().delta_candidates > 0)
    assert_true(index.last_candidate_merge_insertions() > 0)


def test_replaced_and_deleted_base_ids_are_rejected_after_traversal() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)

    table.apply_upsert(1, UInt64(10), [100.0])
    index.upsert(1, [100.0])
    var lookup = _lookup(table)
    var replaced = index.search([1.0], 1, 16, table, lookup)
    assert_equal(replaced[0].id, 2)

    table.apply_delete(2, UInt64(11))
    assert_true(index.delete(2))
    var deleted = index.search([2.0], 1, 16, table, lookup)
    assert_equal(deleted[0].id, 3)


def test_owned_overlay_admits_current_base_nodes_during_search() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _long_chain_base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    for ordinal in range(4):
        var id = 20 + ordinal
        table.apply_upsert(
            id, UInt64(100 + ordinal), [100.0 + Float32(ordinal)]
        )
        index.upsert(id, [100.0 + Float32(ordinal)])

    var lookup = _lookup(table)
    var results = index.search([0.0], 2, 2, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(results[0].id, 24)
    assert_equal(results[1].id, 25)
    assert_equal(index.last_search_stats().fallback_reason, "")
    assert_equal(index.last_rerank_linear_id_scans(), 0)


def test_mapped_overlay_admits_current_base_nodes_during_filtered_search() raises:
    var config = _config()
    config.m0 = config.m
    var table = MemTable(1)
    var base = _long_chain_base(config.copy(), table)
    var path = String("/tmp/akasha-task25-source-admission.bin")
    remove_file_if_exists(path)
    write_file_sync(path, encode_hnsw_snapshot(base, UInt64(19)))
    var view = open_hnsw_snapshot_view(path, config, UInt64(19))
    var index = SegmentedHnsw.from_mapped(view^)
    for ordinal in range(4):
        var id = 20 + ordinal
        table.apply_upsert(
            id, UInt64(100 + ordinal), [100.0 + Float32(ordinal)]
        )
        index.upsert(id, [100.0 + Float32(ordinal)])
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    for ordinal in range(table.slot_count()):
        allowed_bitmap.set(ordinal)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([0.0], 2, 2, 6, allowed, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(results[0].id, 24)
    assert_equal(results[1].id, 25)
    assert_equal(index.last_search_stats().fallback_reason, "")
    assert_true(index.last_search_stats().reranked_candidates < 6)
    assert_equal(index.last_rerank_linear_id_scans(), 0)
    index.close()
    remove_file_if_exists(path)


def test_delta_delete_reinsert_and_candidate_deduplication() raises:
    var config = _config()
    var table = MemTable(1)
    var base = HnswIndex(config.copy())
    table.apply_upsert(7, UInt64(1), [1.0])
    base.add(7, [1.0])
    var index = SegmentedHnsw.from_owned(base^)

    table.apply_upsert(7, UInt64(2), [2.0])
    index.upsert(7, [2.0])
    table.apply_delete(7, UInt64(3))
    assert_true(index.delete(7))
    table.apply_upsert(7, UInt64(4), [3.0])
    index.upsert(7, [3.0])

    var lookup = _lookup(table)
    var result = index.search([3.0], 4, 16, table, lookup)
    assert_equal(len(result), 1)
    assert_equal(result[0].id, 7)
    assert_equal(result[0].score, Float32(0.0))
    assert_equal(index.last_search_stats().reranked_candidates, 1)


def _exercise_shared_source_admission(mapped: Bool) raises:
    var config = _config()
    var base = HnswIndex(config.copy())
    for slot in range(130):
        base.add(-(slot * 17 + 9), [Float32(slot)])
    assert_true(base.delete(-9))
    assert_true(base.delete(-(65 * 17 + 9)))
    # A replacement leaves a stale physical slot and appends slot 130.
    base.upsert(-(2 * 17 + 9), [300.0])
    var index: SegmentedHnsw
    var path = String("/tmp/akasha-shared-source-admission.hnsw")
    if mapped:
        remove_file_if_exists(path)
        write_file_sync(path, encode_hnsw_snapshot(base, UInt64(19)))
        var view = open_hnsw_snapshot_view(path, config, UInt64(19))
        index = SegmentedHnsw.from_mapped(view^)
    else:
        index = SegmentedHnsw.from_owned(base^)
    var admission = _SourceAdmission(index._sources, False)
    var delta_admission = _SourceAdmission(index._sources, True)
    admission.validate(131)
    for slot in range(131):
        var id = -(slot * 17 + 9) if slot != 130 else -(2 * 17 + 9)
        var expected = slot != 0 and slot != 2 and slot != 65
        assert_equal(admission._allows_item(UInt32(slot), id), expected)
    index.upsert(-(64 * 17 + 9), [500.0])
    assert_false(admission._allows_item(UInt32(64), -(64 * 17 + 9)))
    assert_true(delta_admission._allows_item(UInt32(0), -(64 * 17 + 9)))
    assert_true(index.delete(-(129 * 17 + 9)))
    index.upsert(-(129 * 17 + 9), [600.0])
    assert_false(admission._allows_item(UInt32(129), -(129 * 17 + 9)))
    assert_true(delta_admission._allows_item(UInt32(1), -(129 * 17 + 9)))
    assert_true(index.delete(-(64 * 17 + 9)))
    assert_false(delta_admission._allows_item(UInt32(0), -(64 * 17 + 9)))
    assert_equal(index._sources.base_count(), 126)
    assert_equal(index._sources.delta_count(), 1)
    assert_true(admission._allows_item(UInt32(130), -(2 * 17 + 9)))
    index.validate_structure()
    index.close()
    if mapped:
        remove_file_if_exists(path)


def test_shared_owned_source_admission_tracks_mutations_and_slot_history() raises:
    _exercise_shared_source_admission(False)


def test_shared_mapped_source_admission_tracks_mutations_and_slot_history() raises:
    _exercise_shared_source_admission(True)


def test_source_bitmap_validation_checks_membership_beyond_cardinality() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _base(config, table)
    base.upsert(1, [10.0])
    var index = SegmentedHnsw.from_owned(base^)
    index.validate_overlay()
    # Swap one live bit for a stale slot; the cardinality is unchanged.
    index._sources._state[].base_current.clear(4)
    index._sources._state[].base_current.set(0)
    assert_equal(index._sources.base_count(), 4)
    with assert_raises(contains="source bitmap is inconsistent"):
        index.validate_overlay()
    index._sources._state[].base_current.clear(0)
    index._sources._state[].base_current.set(4)
    index.validate_overlay()
    var admission = _SourceAdmission(index._sources, False)
    with assert_raises(contains="bitmap does not match"):
        admission.validate(4)


def test_exact_rerank_reads_authoritative_memtable_vectors() raises:
    var config = _config()
    var table = MemTable(1)
    var base = HnswIndex(config.copy())
    table.apply_upsert(1, UInt64(1), [1.0])
    table.apply_upsert(2, UInt64(2), [2.0])
    base.add(1, [1.0])
    base.add(2, [2.0])
    var index = SegmentedHnsw.from_owned(base^)

    # The graph supplies IDs only; authoritative exact scoring comes from the
    # current MemTable vector.
    table.apply_upsert(1, UInt64(3), [20.0])
    var lookup = _lookup(table)
    var result = index.search([2.0], 2, 16, table, lookup)
    assert_equal(result[0].id, 2)
    assert_equal(result[0].score, Float32(0.0))
    assert_equal(result[1].id, 1)
    assert_equal(result[1].score, Float32(324.0))
    assert_equal(index.last_rerank_ordinal_lookups(), 2)
    assert_equal(index.last_rerank_linear_id_scans(), 0)


def test_delta_threshold_latches_without_query_time_rebuild() raises:
    var config = _config(delta_max_points=2)
    var table = MemTable(1)
    var index = SegmentedHnsw(config)
    table.apply_upsert(1, UInt64(1), [1.0])
    index.upsert(1, [1.0])
    assert_false(index.needs_rebuild())
    table.apply_upsert(2, UInt64(2), [2.0])
    index.upsert(2, [2.0])
    assert_true(index.needs_rebuild())
    var before = index.delta_slot_count()
    var lookup = _lookup(table)
    _ = index.search([2.0], 1, 16, table, lookup)
    assert_equal(index.delta_slot_count(), before)
    assert_true(index.needs_rebuild())


def test_filtered_base_uses_eligible_entry_without_unneeded_widening() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _chain_base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    allowed_bitmap.set(2)
    allowed_bitmap.set(3)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([0.0], 2, 2, 4, allowed, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(results[0].id, 12)
    assert_equal(results[1].id, 13)
    assert_equal(index.last_search_stats().requested_ef, 2)
    assert_equal(index.last_search_stats().effective_ef, 2)
    assert_equal(index.last_search_stats().widening_rounds, 0)
    assert_equal(index.last_search_stats().fallback_reason, "")
    assert_equal(index.last_search_query_preparations(), 1)
    assert_equal(index.last_search_upper_descents(), 0)


def test_filtered_saturation_uses_source_exact_fallback_and_final_stats() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _chain_base(config.copy(), table)
    base.graph.set_neighbors(UInt32(2), 0, [UInt32(1)])
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    allowed_bitmap.set(2)
    allowed_bitmap.set(3)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([0.0], 2, 2, 2, allowed, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(results[0].id, 12)
    assert_equal(results[1].id, 13)
    assert_equal(index.last_search_stats().requested_ef, 2)
    assert_equal(index.last_search_stats().effective_ef, 2)
    assert_equal(index.last_search_stats().widening_rounds, 0)
    assert_equal(
        index.last_search_stats().fallback_reason,
        "filtered_ann_exhausted",
    )
    assert_equal(index.last_search_query_preparations(), 1)
    assert_equal(index.last_search_upper_descents(), 0)
    assert_equal(index.last_rerank_ordinal_lookups(), 2)


def test_filtered_merge_reranks_max_k_or_ef_candidates_from_each_source() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    for id in range(10, 14):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id), values.copy())
        index.upsert(id, values^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    for ordinal in range(table.slot_count()):
        allowed_bitmap.set(ordinal)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([6.0], 2, 4, 4, allowed, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(index.last_search_stats().base_candidates, 4)
    assert_equal(index.last_search_stats().delta_candidates, 4)
    assert_equal(index.last_search_stats().reranked_candidates, 8)
    assert_equal(index.last_rerank_ordinal_lookups(), 8)


def test_filtered_stats_cap_large_initial_ef_to_tiny_source_capacity() raises:
    var config = _config()
    var table = MemTable(1)
    var index = SegmentedHnsw(config)
    for id in range(1, 3):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id), values.copy())
        index.upsert(id, values^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    allowed_bitmap.set(0)
    allowed_bitmap.set(1)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    _ = index.search_allowed([1.0], 1, 64, 128, allowed, table, lookup)

    assert_equal(index.last_search_stats().requested_ef, 2)
    assert_equal(index.last_search_stats().effective_ef, 2)


def test_unfiltered_stats_cap_large_ef_to_tiny_source_capacity() raises:
    var config = _config()
    var table = MemTable(1)
    var index = SegmentedHnsw(config)
    for id in range(1, 3):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id), values.copy())
        index.upsert(id, values^)
    var lookup = _lookup(table)

    _ = index.search([1.0], 1, 64, table, lookup)

    assert_equal(index.last_search_stats().requested_ef, 2)
    assert_equal(index.last_search_stats().effective_ef, 2)


def test_lookup_growth_invalidates_preexisting_eligibility_domain() raises:
    var table = MemTable(1)
    table.apply_upsert(1, UInt64(1), [1.0])
    table.apply_upsert(2, UInt64(2), [2.0])
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(2)
    allowed_bitmap.set(0)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    lookup.append(3, 2)

    with assert_raises():
        allowed.validate(3)


def test_global_exact_completion_rejects_live_id_without_graph_source() raises:
    var config = _config()
    var table = MemTable(1)
    var index = SegmentedHnsw(config)
    for id in range(1, 3):
        table.apply_upsert(id, UInt64(id), [Float32(id)])
        index.upsert(id, [Float32(id)])
    table.apply_upsert(3, UInt64(3), [3.0])
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(3)
    allowed_bitmap.set(0)
    allowed_bitmap.set(1)
    allowed_bitmap.set(2)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    with assert_raises():
        _ = index.search_allowed([1.0], 3, 2, 4, allowed, table, lookup)


def test_filtered_source_exhaustion_does_not_pollute_complete_merge() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    for id in range(10, 12):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id), values.copy())
        index.upsert(id, values^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    allowed_bitmap.set(0)
    allowed_bitmap.set(1)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([1.0], 2, 2, 4, allowed, table, lookup)

    assert_equal(len(results), 2)
    assert_equal(index.last_search_stats().base_candidates, 2)
    assert_equal(index.last_search_stats().delta_candidates, 0)
    assert_equal(index.last_search_stats().fallback_reason, "")


def test_filtered_candidate_pool_retains_requested_ef_from_eligible_component() raises:
    var config = _config()
    var table = MemTable(1)
    var base = _long_chain_base(config.copy(), table)
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)
    var allowed_bitmap = Bitmap(table.slot_count())
    for ordinal in range(2, 6):
        allowed_bitmap.set(ordinal)
    var allowed = HnswEligibility(allowed_bitmap^, lookup)

    var results = index.search_allowed([0.0], 3, 3, 6, allowed, table, lookup)

    assert_equal(len(results), 3)
    assert_equal(index.last_search_stats().effective_ef, 3)
    assert_equal(index.last_search_stats().widening_rounds, 0)
    assert_equal(index.last_search_stats().base_candidates, 3)
    assert_equal(index.last_search_stats().reranked_candidates, 3)
    assert_equal(index.last_rerank_ordinal_lookups(), 3)


def test_large_memtable_small_k_reranks_only_bounded_candidates() raises:
    var config = _config()
    config.m = 2
    config.m0 = 2
    var table = MemTable(1)
    var base = HnswIndex(config.copy())
    var count = 512
    for id in range(count):
        var values: List[Float32] = [Float32(id)]
        table.apply_upsert(id, UInt64(id + 1), values.copy())
        var slot = base.graph.append(id, values^, 0)
        if id == 0:
            base.entry_slot = Optional(slot)
            base.entry_level = 0
    for id in range(count):
        var neighbors = List[UInt32]()
        if id > 0:
            neighbors.append(UInt32(id - 1))
        if id + 1 < count:
            neighbors.append(UInt32(id + 1))
        base.graph.set_neighbors(UInt32(id), 0, neighbors^)
    base.build_stats.slot_count = count
    base.build_stats.maximum_level = 0
    base.build_stats.directed_edges = 2 * (count - 1)
    base.entries = entries_from_legacy(base.graph, base.entry_slot)
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)

    var results = index.search([0.0], 3, 8, table, lookup)

    assert_equal(len(results), 3)
    assert_equal(results[0].id, 0)
    assert_equal(results[1].id, 1)
    assert_equal(results[2].id, 2)
    assert_equal(index.last_search_stats().reranked_candidates, 8)
    assert_equal(index.last_rerank_ordinal_lookups(), 8)
    assert_equal(index.last_rerank_linear_id_scans(), 0)
    assert_equal(index.last_candidate_merge_insertions(), 0)


def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
