"""Count actual public-ID reads while running the real graph and scorer."""
from akasha.common.config import MetricKind, ScalarKind
from akasha.compute.metric import MetricDispatcher
from akasha.index.bitmap import Bitmap
from akasha.index.hnsw_admission import HnswResultAdmission
from akasha.index.hnsw_core import HnswEligibility, HnswIdOrdinalLookup, HnswSearchAdmission
from akasha.index.hnsw_heap import HnswHeapItem
from akasha.index.hnsw_search import score_points
from akasha.index.hnsw_stats import HnswSearchStats
from akasha.index.hnsw_storage import HnswGraphAccess, HnswStorage
from akasha.index.segmented_hnsw import _CurrentSourceLookup, _SourceAdmission, _FilteredSourceAdmission, _BaseOrdinalProjection
from std.collections import Dict
from std.memory import ArcPointer, bitcast
from std.testing import assert_equal, assert_true, TestSuite


struct _Reads:
    var ids: Int

    def __init__(out self):
        self.ids = 0


@fieldwise_init
struct CountingGraph(HnswGraphAccess, Movable):
    var storage: HnswStorage
    var reads: ArcPointer[_Reads]

    def validate_search_ready(self) raises:
        self.storage.validate_search_ready()

    def validate_structure(self) raises:
        self.storage.validate_structure()

    def slot_count(self) -> Int:
        return self.storage.slot_count()

    def graph_dimension(self) -> Int:
        return self.storage.graph_dimension()

    def graph_m(self) -> Int:
        return self.storage.graph_m()

    def graph_m0(self) -> Int:
        return self.storage.graph_m0()

    def id_at(self, slot: UInt32) raises -> Int:
        self.reads[].ids += 1
        return self.storage.id_at(slot)

    def level(self, slot: UInt32) raises -> Int:
        return self.storage.level(slot)

    def is_current(self, slot: UInt32) -> Bool:
        return self.storage.is_current(slot)

    def distance_to_slot(self, metric: MetricDispatcher, query: List[Float32], slot: UInt32) raises -> Float32:
        return self.storage.distance_to_slot(metric, query, slot)

    def _distance_to_slot_backend[tag: Int](self, metric: MetricDispatcher, query: List[Float32], slot: UInt32) raises -> Float32:
        return self.storage._distance_to_slot_backend[tag](metric, query, slot)

    def _distance_to_four_f32[tag: Int](self, metric: MetricDispatcher, query: List[Float32], slots: SIMD[DType.uint32, 4]) raises -> SIMD[DType.float32, 4]:
        return self.storage._distance_to_four_f32[tag](metric, query, slots)

    def neighbor_range(self, slot: UInt32, level: Int) raises -> Tuple[Int, Int]:
        return self.storage.neighbor_range(slot, level)

    def neighbor_at_offset(self, offset: Int) raises -> UInt32:
        return self.storage.neighbor_at_offset(offset)

    def neighbor_count(self, slot: UInt32, level: Int) raises -> Int:
        return self.storage.neighbor_count(slot, level)

    def neighbor_at(self, slot: UInt32, level: Int, index: Int) raises -> UInt32:
        return self.storage.neighbor_at(slot, level, index)


def _id(slot: Int) -> Int:
    return 1000 - slot * 317


def _graph() raises -> CountingGraph:
    var storage = HnswStorage(1, 4, 8)
    for slot in range(8):
        _ = storage.append(_id(slot), [Float32(slot)], 0)
    return CountingGraph(storage^, ArcPointer(_Reads()))


def _sources() raises -> _CurrentSourceLookup:
    var sources = _CurrentSourceLookup(8)
    for slot in range(8):
        sources.set_base(_id(slot), slot + 1)
    sources.set_delta(_id(4))
    return sources^


def _eligibility() raises -> HnswEligibility:
    var ids = Dict[Int, Int]()
    var bitmap = Bitmap(8)
    for slot in range(8):
        ids[_id(slot)] = slot
        if slot % 2 == 0:
            bitmap.set(slot)
    var lookup = HnswIdOrdinalLookup(ids^, 8)
    return HnswEligibility(bitmap^, lookup)


def _check[Admission: HnswResultAdmission](
    graph: CountingGraph, admission: Admission, limit: Int,
    expected: List[UInt32], expected_id_reads: Int, filtered: Int, inactive: Int,
) raises:
    admission.validate(graph.slot_count())
    var metric = MetricDispatcher(MetricKind.l2(), ScalarKind.f32(), 1)
    var query: List[Float32] = [0.0]
    var points: List[UInt32] = [0, 1, 2, 3, 4, 5, 6, 7]
    var result = List[HnswHeapItem]()
    var stats = HnswSearchStats()
    score_points[backend_tag=1](graph, metric, query, points, limit, admission, stats, result)
    assert_equal(graph.reads[].ids, expected_id_reads)
    assert_equal(stats.filtered_rejections, filtered)
    assert_equal(stats.inactive_rejections, inactive)
    assert_equal(stats.distance_evaluations, len(expected))
    assert_equal(len(result), len(expected))
    assert_equal(len(points), len(expected))
    for i in range(len(expected)):
        assert_equal(points[i], expected[i])
        assert_equal(result[i].id, _id(Int(expected[i])))
        var distance = graph.storage._distance_to_slot_backend[1](metric, query, expected[i])
        assert_equal(bitcast[DType.uint32](result[i].distance), bitcast[DType.uint32](distance))


def test_slot_filter_does_not_load_rejected_or_capped_ids() raises:
    var graph = _graph()
    var admission = HnswSearchAdmission([False, False, True, True, False, False, False, False])
    _check(graph, admission, 1, [UInt32(2)], 1, 6, 0)


def test_base_source_filter_keeps_four_row_scoring_without_eager_ids() raises:
    var graph = _graph()
    assert_true(graph.storage.mark_deleted(_id(6)))
    var sources = _sources()
    var admission = _SourceAdmission(sources, False)
    _check(graph, admission, 4, [UInt32(0), UInt32(1), UInt32(2), UInt32(3)], 4, 1, 1)


def test_cached_base_ordinals_do_not_require_public_ids() raises:
    var graph = _graph()
    assert_true(graph.storage.mark_deleted(_id(6)))
    var sources = _sources()
    var eligibility = _eligibility()
    var projection = ArcPointer(_BaseOrdinalProjection(eligibility._state[].lookup, 8))
    for slot in range(8):
        assert_true(projection[].resolve(UInt32(slot), _id(slot)))
    var admission = _FilteredSourceAdmission(sources, False, eligibility, Optional(projection))
    _check(graph, admission, 1, [UInt32(0)], 1, 5, 1)


def test_delta_admission_still_resolves_noncanonical_public_ids() raises:
    var graph = _graph()
    assert_true(graph.storage.mark_deleted(_id(6)))
    var sources = _sources()
    var admission = _SourceAdmission(sources, True)
    _check(graph, admission, 0, [UInt32(4)], 8, 6, 1)


def test_id_based_eligibility_keeps_public_id_resolution() raises:
    var graph = _graph()
    var admission = _eligibility()
    _check(graph, admission, 0, [UInt32(0), UInt32(2), UInt32(4), UInt32(6)], 12, 4, 0)


def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
