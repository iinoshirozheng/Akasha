from test_segmented_hnsw import _lookup
from akasha.common.config import CollectionConfig, MetricKind, ScalarKind
from akasha.compute.topk import BoundedTopK
from akasha.document.point_state import PointField, PointState
from akasha.document.vector_value import VectorValue
from akasha.index.bitmap import Bitmap
from akasha.index.flat import authoritative_f32_score, SearchResult
from akasha.index.hnsw import HnswIndex
from akasha.index.hnsw_core import HnswEligibility
from akasha.index.segmented_hnsw import SegmentedHnsw
from akasha.storage.checksum import BinaryWriter
from akasha.storage.filesystem import ensure_directory, path_exists, remove_file_if_exists, write_file_sync
from akasha.storage.generation_pins import GenerationPinRegistry
from akasha.storage.hnsw_store import encode_hnsw_snapshot, open_hnsw_snapshot_view
from akasha.storage.manifest import Manifest, publish_manifest
from akasha.storage.mapped_vector_file import MappedVectorFile
from akasha.storage.memtable import MemTable, MemTableEntry, NumericOwnerReplacement
from std.ffi import c_int, external_call
from std.math import nan
from std.memory import ArcPointer, bitcast
from std.testing import assert_equal, assert_true, assert_false, assert_raises, TestSuite

def _path(label: String) -> String:
    return String("/tmp/akasha-score-certificate-", Int(external_call["getpid", c_int]()), "-", label)

def _values(dimension: Int, id: Int) -> List[Float32]:
    var values = List[Float32](capacity=dimension)
    for column in range(dimension):
        values.append(Float32((id * 7 + column * 11) % 29 - 14) / 17)
    return values^

def _compare(results: List[SearchResult], table: MemTable, query: List[Float32], metric: Int, filtered: Bool = False) raises:
    var expected = BoundedTopK(8, smaller_is_better=metric == 1)
    for ordinal in range(table.slot_count()):
        if filtered and ordinal % 2:
            continue
        ref entry = table.entry_ref_at(ordinal)
        expected.offer(entry.id, authoritative_f32_score(metric, query, entry._dense_reader()))
    var entries = expected.sorted_entries()
    assert_equal(len(results), len(entries))
    for i in range(len(entries)):
        assert_equal(results[i].id, entries[i].id)
        assert_equal(bitcast[DType.uint32](results[i].score), bitcast[DType.uint32](entries[i].score))

def _exercise(mapped: Bool, metric: MetricKind) raises:
    var filtered_reuse_cases = 0
    for dimension in [1, 3, 17, 64, 65, 128, 1536]:
        var config = CollectionConfig.defaults(dimension)
        config.ann_metric = metric.copy()
        config.m = 4
        config.m0 = 8
        var base = HnswIndex(config)
        var table = MemTable(dimension)
        for id in range(8):
            var values = _values(dimension, id)
            base.add(id, values)
            table.apply_upsert(id, UInt64(id + 1), values^)
        var index = SegmentedHnsw(config)
        var path = _path(String(mapped, "-", metric.tag(), "-", dimension))
        if mapped:
            write_file_sync(path, encode_hnsw_snapshot(base, UInt64(8)))
            index = SegmentedHnsw.from_mapped(open_hnsw_snapshot_view(path, config, UInt64(8)))
        else:
            index = SegmentedHnsw.from_owned(base^)
        var lookup = _lookup(table)
        var bitmap = Bitmap(8)
        for ordinal in range(0, 8, 2):
            bitmap.set(ordinal)
        var allowed = HnswEligibility(bitmap^, lookup)
        for q in range(3):
            var query = _values(dimension, 10 + q)
            var results = index.search(query, 8, 16, table, lookup)
            _compare(results, table, query, Int(metric.tag()))
            assert_equal(index._last_reused_graph_scores, 8)
            assert_equal(index.last_search_stats().reranked_candidates, 8)
            var filtered = index.search_allowed(query, 4, 16, 16, allowed, table, lookup)
            _compare(filtered, table, query, Int(metric.tag()), True)
            if index.last_search_stats().fallback_reason == "":
                assert_equal(index._last_reused_graph_scores, 4)
                filtered_reuse_cases += 1
            else:
                assert_equal(index._last_reused_graph_scores, 0)
        var expired = index._sources._state[].score_proofs[0].owner
        # Same public ID and sequence, different immutable owner and bytes.
        table.put(MemTableEntry(0, 1, False, _values(dimension, 21)))
        assert_false(expired.try_upgrade())
        var query = _values(dimension, 13)
        for _ in range(2):
            var results = index.search(query, 8, 16, table, lookup)
            _compare(results, table, query, Int(metric.tag()))
            assert_true(index._last_reused_graph_scores < 8)
        table.put(MemTableEntry(0, 1, False, _values(dimension, 0)))
        var restored = index.search(query, 8, 16, table, lookup)
        _compare(restored, table, query, Int(metric.tag()))
        assert_equal(index._last_reused_graph_scores, 8)
        # A legacy nonfinite owner must never inherit a finite predecessor's proof.
        var invalid = _values(dimension, 0)
        invalid[0] = nan[DType.float32]()
        table.put(MemTableEntry(0, 1, False, invalid^))
        with assert_raises(contains="finite"):
            _ = index.search(query, 8, 16, table, lookup)
        index.close()
        if mapped:
            remove_file_if_exists(path)
    assert_true(filtered_reuse_cases > 0)

def test_equal_nonfinite_bytes_cannot_create_a_score_certificate() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var base = HnswIndex(config)
    base.add(0, [Float32(1)])
    var index = SegmentedHnsw.from_owned(base^)
    # Corrupted in-memory graph storage is insufficient proof of finiteness.
    index._owned_base.graph.vector_scalars[0] = nan[DType.float32]()
    var table = MemTable(1)
    table.put(MemTableEntry(0, 1, False, [nan[DType.float32]()]))
    ref entry = table.entry_ref_at(0)
    assert_false(index._graph_value_matches(entry, entry._dense_reader()))

def test_reused_prefix_keeps_earlier_finite_error_and_lookup_counts() raises:
    var config = CollectionConfig.defaults(3)
    config.ann_metric = MetricKind.dot()
    var base = HnswIndex(config)
    var table = MemTable(3)
    for id in range(4):
        var values = _values(3, id)
        base.add(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)
    var query = _values(3, 12)
    var graph_scores = List[Float32]()
    for id in range(4):
        graph_scores.append(authoritative_f32_score(0, query, table.entry_ref_at(id)._dense_reader()))
    table.put(MemTableEntry(2, 3, False, [nan[DType.float32](), Float32(1), Float32(2)]))
    var bitmap = Bitmap(4)
    for ordinal in range(4):
        bitmap.set(ordinal)
    var allowed = HnswEligibility(bitmap^, lookup)
    for filtered in [False, True]:
        with assert_raises(contains="finite"):
            if filtered:
                _ = index._rerank_allowed_candidates(query, 4, [0, 1, 2, 3, 999], table, lookup, allowed, graph_scores)
            else:
                _ = index._rerank_candidates(query, 4, [0, 1, 2, 3, 999], table, lookup, graph_scores)
        assert_equal(index.last_rerank_ordinal_lookups(), 4)
        assert_equal(index._last_reused_graph_scores, 2)

def test_owned_dot_certificates_follow_exact_owner_and_query() raises:
    _exercise(False, MetricKind.dot())

def test_mapped_dot_certificates_follow_exact_owner_and_query() raises:
    _exercise(True, MetricKind.dot())

def test_owned_l2_certificates_follow_exact_owner_and_query() raises:
    _exercise(False, MetricKind.l2())

def test_mapped_l2_certificates_follow_exact_owner_and_query() raises:
    _exercise(True, MetricKind.l2())

def test_cosine_and_compact_graph_scores_are_never_reused() raises:
    for metric in [MetricKind.dot(), MetricKind.l2(), MetricKind.cosine()]:
        for scalar in [ScalarKind.f32(), ScalarKind.bf16(), ScalarKind.f16()]:
            if scalar == ScalarKind.f32() and metric != MetricKind.cosine():
                continue
            var config = CollectionConfig.defaults(17)
            config.ann_metric = metric.copy()
            config.scalar_kind = scalar.copy()
            var base = HnswIndex(config)
            var table = MemTable(17)
            for id in range(8):
                var values = _values(17, id)
                base.add(id, values)
                table.apply_upsert(id, UInt64(id + 1), values^)
            var index = SegmentedHnsw.from_owned(base^)
            var lookup = _lookup(table)
            var query = _values(17, 10)
            var results = index.search(query, 8, 16, table, lookup)
            _compare(results, table, query, Int(metric.tag()))
            assert_equal(index._last_reused_graph_scores, 0)
            assert_equal(len(index._sources._state[].score_proofs), 0)

def test_compaction_owner_exchange_reclaims_file_with_certificates_alive() raises:
    var path = _path("retirement")
    ensure_directory(path)
    var writer = BinaryWriter()
    writer.write_u8(0xAA)
    var config = CollectionConfig.defaults(3)
    config.ann_metric = MetricKind.dot()
    var base = HnswIndex(config)
    for id in range(8):
        var values = _values(3, id)
        writer.write_f32s(values)
        base.add(id, values)
    write_file_sync(path + "/vectors.bin", writer.take_bytes())
    publish_manifest(path, Manifest(3, 1, 0, "vectors.bin"))
    var pins = ArcPointer(GenerationPinRegistry(path, 3))
    var file = Optional(ArcPointer(MappedVectorFile(pins, "vectors.bin")))
    var table = MemTable(3)
    for id in range(8):
        var point = PointState.live(id, UInt64(id + 1), UInt64(id + 1),
            [PointField(0, VectorValue._legacy_mapped_dense(file.value(), 1 + id * 12, 3))], [])
        table.put(MemTableEntry.from_point(point))
    file = None
    assert_false(Bool(file))
    var index = SegmentedHnsw.from_owned(base^)
    var lookup = _lookup(table)
    var query = _values(3, 12)
    _compare(index.search(query, 8, 16, table, lookup), table, query, 0)
    assert_equal(index._last_reused_graph_scores, 8)
    var expired = index._sources._state[].score_proofs[0].owner
    write_file_sync(path + "/new.bin", [UInt8(1)])
    publish_manifest(path, Manifest(3, 2, 0, "new.bin"))
    var replacements = Optional(List[NumericOwnerReplacement]())
    for id in range(8):
        replacements.value().append(NumericOwnerReplacement(id, 0,
            PointField(0, VectorValue.dense[DType.float32](_values(3, id))),
            table.entry_ref_at(id)._vectors[0].copy()))
    table._publish_compaction_owners(replacements.value())
    assert_true(path_exists(path + "/vectors.bin"))
    assert_true(Bool(replacements))
    replacements = None
    assert_false(Bool(replacements))
    assert_false(expired.try_upgrade())
    assert_false(path_exists(path + "/vectors.bin"))
    _compare(index.search(query, 8, 16, table, lookup), table, query, 0)
    assert_equal(index._last_reused_graph_scores, 8)


def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
