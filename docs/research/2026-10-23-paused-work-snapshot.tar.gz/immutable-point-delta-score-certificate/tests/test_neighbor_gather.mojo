from akasha.common.config import CollectionConfig
from akasha.index.hnsw import HnswIndex
from akasha.index.hnsw_storage import HnswGraphAccess
from akasha.index.hnsw_view import HnswGraphView
from akasha.storage.filesystem import remove_file_if_exists, write_file_sync
from akasha.storage.hnsw_store import encode_hnsw_snapshot, open_hnsw_snapshot_view
from akasha.storage.mapped_file import MappedFile
from std.ffi import c_int, external_call
from std.testing import assert_equal, assert_true, TestSuite

def _path(suffix: String) -> String:
    return String("/tmp/akasha-gather-", Int(external_call["getpid", c_int]()), "-", suffix)

def _old_collect[Graph: HnswGraphAccess, exclude_visited: Bool](
    graph: Graph, slot: UInt32, level: Int, visited: List[UInt32],
    epoch: UInt32, mut points: List[UInt32],
) raises:
    var edges = graph.neighbor_range(slot, level)
    for i in range(edges[1]):
        var neighbor = graph.neighbor_at_offset(edges[0] + i)
        if graph.level(neighbor) < level:
            raise Error("HNSW edge targets a node below its level")
        comptime if exclude_visited:
            if visited[Int(neighbor)] == epoch:
                continue
        points.append(neighbor)

def _check[Graph: HnswGraphAccess, exclude_visited: Bool](graph: Graph) raises:
    var visits = List[UInt32]()
    for slot in range(graph.slot_count()):
        visits.append(UInt32(7 if slot % 3 == 0 else 0))
    var before = visits.copy()
    for slot in range(graph.slot_count()):
        for level in range(graph.level(UInt32(slot)) + 1):
            var old: List[UInt32] = [99]
            var new: List[UInt32] = [99]
            _old_collect[exclude_visited=exclude_visited](graph, UInt32(slot), level, visits, 7, old)
            graph._collect_neighbors[exclude_visited](UInt32(slot), level, visits, 7, new)
            assert_equal(new, old)
    assert_equal(visits, before)

def test_all_levels_owned_mapped_and_live_visited() raises:
    var config = CollectionConfig.defaults(2)
    config.m = 3
    config.m0 = 6
    config.ef_construction = 24
    config.max_level = 5
    var graph = HnswIndex(config)
    for id in range(32):
        var vector: List[Float32] = [Float32(id + 1), Float32(id % 7)]
        graph.add(id, vector^)
    var path = _path("valid")
    write_file_sync(path, encode_hnsw_snapshot(graph, 7))
    var view = open_hnsw_snapshot_view(path, config, 7)
    _check[exclude_visited=False](graph.graph)
    _check[exclude_visited=True](graph.graph)
    _check[exclude_visited=False](view)
    _check[exclude_visited=True](view)
    view.close()
    remove_file_if_exists(path)

def _put(mut bytes: List[UInt8], offset: Int, value: UInt32):
    for i in range(4):
        bytes[offset + i] = UInt8(value >> UInt32(i * 8))

def _fixture(path: String, bad_second: Bool = False, short: Bool = False, bad_upper: Bool = False) raises -> HnswGraphView:
    # Deliberately synthetic mapping: bypass store validation to exercise each
    # operation's defensive checks without changing an already mapped inode.
    var bytes = List[UInt8]()
    for _ in range(121 if short else 128):
        bytes.append(UInt8(0))
    _put(bytes, 0, 2)
    _put(bytes, 4, 1)
    _put(bytes, 12, 1)
    _put(bytes, 16, UInt32.MAX if bad_second else UInt32(2))
    _put(bytes, 20, UInt32(1 if bad_upper else 2))
    bytes[40] = UInt8(1)
    _put(bytes, 88, 2)
    _put(bytes, 96, 3)
    bytes[120] = UInt8(1)
    write_file_sync(path, bytes)
    return HnswGraphView._from_validated_mapping(
        MappedFile.open_readonly(path), CollectionConfig.defaults(1),
        3, 3, 4, 3, Optional(UInt32(0)), 1,
        32, 0, 4, 0, 0, 0, 12, False,
    )

def _compare_error[exclude_visited: Bool](
    view: HnswGraphView, slot: UInt32, level: Int, expected: String,
) raises:
    var visits: List[UInt32] = [7, 7, 7]
    var old: List[UInt32] = [99]
    var new: List[UInt32] = [99]
    var old_error = String()
    var new_error = String()
    try:
        _old_collect[exclude_visited=exclude_visited](view, slot, level, visits, 7, old)
    except error:
        old_error = String(error)
    try:
        view._collect_neighbors[exclude_visited](slot, level, visits, 7, new)
    except error:
        new_error = String(error)
    assert_true(old_error.byte_length() > 0)
    assert_equal(old_error, expected)
    assert_equal(new_error, old_error)
    assert_equal(new, old)

def test_later_bad_neighbor_preserves_partial_output_and_error() raises:
    var path = _path("bad-neighbor")
    var view = _fixture(path, bad_second=True)
    _compare_error[False](view, 0, 0, "HNSW slot out of bounds")
    _compare_error[True](view, 0, 0, "HNSW slot out of bounds")
    view.close()
    remove_file_if_exists(path)

def test_partial_level_record_preserves_first_error() raises:
    var path = _path("short")
    var view = _fixture(path, short=True)
    _compare_error[False](view, 0, 0, "mapped scalar chunk is out of bounds")
    _compare_error[True](view, 0, 0, "mapped scalar chunk is out of bounds")
    view.close()
    remove_file_if_exists(path)

def test_target_level_rejected_before_visited_filter() raises:
    var path = _path("upper")
    var view = _fixture(path, bad_upper=True)
    _compare_error[False](view, 0, 1, "HNSW edge targets a node below its level")
    _compare_error[True](view, 0, 1, "HNSW edge targets a node below its level")
    view.close()
    remove_file_if_exists(path)

def test_levels_offsets_and_closed_precedence() raises:
    var path = _path("bounds")
    var view = _fixture(path)
    _compare_error[False](view, 0, -1, "HNSW graph level out of bounds")
    _compare_error[True](view, UInt32.MAX, 0, "HNSW slot out of bounds")
    _compare_error[False](view, 0, 2, "HNSW graph level out of bounds")
    view._edge_offset = Int.MAX
    _compare_error[True](view, 0, 0, "HNSW edge section offset is invalid")
    view.close()
    _compare_error[False](view, 0, 0, "cannot search a closed HNSW graph view")
    _compare_error[True](view, 0, -1, "HNSW graph level out of bounds")
    remove_file_if_exists(path)

def test_copied_neighbors_survive_close_and_visit_changes_are_observed() raises:
    var path = _path("copy")
    var view = _fixture(path)
    var visits: List[UInt32] = [0, 7, 0]
    var points = List[UInt32]()
    view._collect_neighbors[True](0, 0, visits, 7, points)
    var expected: List[UInt32] = [2]
    assert_equal(points, expected)
    visits[1] = UInt32(0)
    visits[2] = UInt32(7)
    view._collect_neighbors[True](0, 0, visits, 7, points)
    expected.append(UInt32(1))
    assert_equal(points, expected)
    var no_visits = List[UInt32]()
    view._collect_neighbors[True](1, 0, no_visits, 7, points)
    assert_equal(points, expected)
    view._collect_neighbors[False](0, 1, no_visits, 7, points)
    view.close()
    expected.append(UInt32(2))
    assert_equal(points, expected)
    remove_file_if_exists(path)

def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
