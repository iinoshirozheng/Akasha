from test_deferred_id import _graph, _sources, _eligibility, _id, _check
from akasha.index.segmented_hnsw import _FilteredSourceAdmission
from std.testing import assert_true, TestSuite


def test_filtered_delta_resolves_once_for_both_membership_checks() raises:
    var graph = _graph()
    assert_true(graph.storage.mark_deleted(_id(6)))
    var sources = _sources()
    var eligibility = _eligibility()
    var admission = _FilteredSourceAdmission(sources, True, eligibility, None)
    _check(graph, admission, 0, [UInt32(4)], 8, 6, 1)


def test_filtered_delta_rejection_does_not_read_id_a_second_time() raises:
    var graph = _graph()
    assert_true(graph.storage.mark_deleted(_id(6)))
    var sources = _sources()
    var eligibility = _eligibility()
    eligibility._state[].allowed_ordinals.clear(4)
    var admission = _FilteredSourceAdmission(sources, True, eligibility, None)
    _check(graph, admission, 0, List[UInt32](), 7, 7, 1)


def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
