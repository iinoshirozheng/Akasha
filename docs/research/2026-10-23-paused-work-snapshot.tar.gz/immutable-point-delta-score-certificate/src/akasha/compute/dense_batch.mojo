from akasha.compute.simd import _prepared_f32_pair_score, _prepared_f32_score
from akasha.compute.topk import BoundedTopK
from akasha.document.numeric_read_view import _NumericReadView


@fieldwise_init
struct _DenseScorePair[origin: ImmOrigin](Movable):
    comptime Row = _NumericReadView[DType.float32, Self.origin]
    var first_id: Int
    var first: Self.Row
    var second_id: Int
    var second: Optional[Self.Row]

    @always_inline
    def count(self) -> Int:
        return 2 if self.second else 1

    @always_inline
    def offer(
        self, query: List[Float32], metric: Int, query_norm: Float32,
        mut topk: BoundedTopK[],
    ) raises:
        if self.second:
            var scores = _prepared_f32_pair_score(
                metric, query, self.first, self.second.value(), query_norm
            )
            topk.offer(self.first_id, scores[0])
            topk.offer(self.second_id, scores[1])
        else:
            topk.offer(self.first_id, _prepared_f32_score(
                metric, query, self.first, query_norm
            ))
