from akasha.document.record import (
    clone_fields,
    DocumentField,
    validate_fields,
)
from akasha.document.codec import decode_payload, encode_payload
from akasha.index.bitmap import Bitmap
from akasha.index.keyword import KeywordIndex
from akasha.index.sorted_block import SortedBlockIndex
from akasha.query.filter_ast import FilterCondition
from std.collections import Dict
from std.memory import bitcast
from akasha.storage.checksum import BinaryReader, BinaryReaderSource, BinaryWriter


struct MetadataIndex:
    """Derived typed metadata index addressed by stable point ordinals."""

    var _ids: List[Int]
    var _ordinals: Dict[Int, Int]
    var _fields: List[List[DocumentField]]
    var _live: Bitmap
    var _keywords: KeywordIndex
    var _numbers: SortedBlockIndex
    var _bulk_loading: Bool

    def __init__(out self) raises:
        self._ids = List[Int]()
        self._ordinals = Dict[Int, Int]()
        self._fields = List[List[DocumentField]]()
        self._live = Bitmap()
        self._keywords = KeywordIndex()
        self._numbers = SortedBlockIndex()
        self._bulk_loading = False

    def slot_count(self) -> Int:
        return len(self._ids)

    def live_count(self) -> Int:
        return self._live.count()

    def id_at(self, ordinal: Int) raises -> Int:
        self._validate_ordinal(ordinal)
        return self._ids[ordinal]

    def is_live_at(self, ordinal: Int) raises -> Bool:
        self._validate_ordinal(ordinal)
        return self._live.contains(ordinal)

    def ordinal_for(self, id: Int) raises -> Int:
        if id in self._ordinals:
            return self._ordinals[id]
        return -1

    def live_universe(self) raises -> Bitmap:
        return self._live.clone()

    def begin_bulk(mut self) raises:
        if self._bulk_loading or self.slot_count() != 0:
            raise Error("metadata bulk load requires an empty index")
        self._keywords.begin_bulk()
        self._numbers.begin_bulk()
        self._bulk_loading = True

    def finish_bulk(mut self) raises:
        if not self._bulk_loading:
            raise Error("metadata bulk load is not active")
        self._keywords.finish_bulk()
        self._numbers.finish_bulk()
        self._bulk_loading = False

    def upsert(mut self, id: Int, var fields: List[DocumentField]) raises:
        validate_fields(fields)
        var ordinal = self.ordinal_for(id)
        if self._bulk_loading and ordinal >= 0:
            raise Error("metadata bulk load requires unique point IDs")
        if (
            ordinal >= 0
            and self._live.contains(ordinal)
            and _same_fields(self._fields[ordinal], fields)
        ):
            return
        if ordinal < 0:
            ordinal = self._append_slot(id)
        else:
            self._remove_fields(ordinal)

        for index in range(len(fields)):
            self._add_field(ordinal, fields[index])
        self._fields[ordinal] = fields^
        self._live.set(ordinal)

    def delete(mut self, id: Int) raises:
        var ordinal = self.ordinal_for(id)
        if ordinal < 0:
            _ = self._append_slot(id)
            return
        self._remove_fields(ordinal)
        self._fields[ordinal] = List[DocumentField]()
        self._live.clear(ordinal)

    def evaluate_condition(self, condition: FilterCondition) raises -> Bitmap:
        condition.validate()
        var candidates: Bitmap
        if condition.value.is_string() or condition.value.is_boolean():
            candidates = self._keywords.evaluate(condition)
        elif condition.value.is_integer() or condition.value.is_floating():
            candidates = self._numbers.evaluate(condition)
        else:
            raise Error("unknown metadata index value kind")
        if condition.operator_kind() == FilterCondition.NOT_EQUAL:
            if condition.value.is_string():
                candidates = candidates.union_with(self._numbers.present(condition.name))
            elif condition.value.is_integer():
                candidates = candidates.union_with(self._keywords.present(condition.name))
        return self._live.intersection(candidates)

    def contains_id(self, candidates: Bitmap, id: Int) raises -> Bool:
        if candidates.size() != self.slot_count():
            raise Error("candidate bitmap does not match metadata index")
        var ordinal = self.ordinal_for(id)
        if ordinal < 0:
            return False
        return candidates.contains(ordinal)

    def encode_cache_payload(self) raises -> List[UInt8]:
        """Encode stable metadata slots for a rebuildable cache."""
        if self.slot_count() > Int(UInt32.MAX):
            raise Error("metadata cache slot count exceeds format")
        var writer = BinaryWriter()
        writer.write_u32(UInt32(self.slot_count()))
        for ordinal in range(self.slot_count()):
            writer.write_i64(Int64(self._ids[ordinal]))
            writer.write_u8(
                UInt8(1) if self._live.contains(ordinal) else UInt8(0)
            )
            writer.write_u8(UInt8(0))
            writer.write_u16(UInt16(0))
            var payload = encode_payload(self._fields[ordinal])
            if len(payload) > Int(UInt32.MAX):
                raise Error("metadata cache payload exceeds format")
            writer.write_u32(UInt32(len(payload)))
            writer.write_bytes(payload)
        return writer.take_bytes()

    @staticmethod
    def decode_cache_payload(var payload: List[UInt8]) raises -> MetadataIndex:
        var reader = BinaryReader(payload^)
        return MetadataIndex.decode_cache_reader(reader)

    @staticmethod
    def decode_cache_reader[Reader: BinaryReaderSource](
        mut reader: Reader
    ) raises -> MetadataIndex:
        var slot_count = Int(reader.read_u32())
        if slot_count > 10_000_000:
            raise Error("metadata cache slot count exceeds limit")
        var index = MetadataIndex()
        index.begin_bulk()
        for _ in range(slot_count):
            var id = Int(reader.read_i64())
            var live = reader.read_u8()
            if (
                live > UInt8(1)
                or reader.read_u8() != UInt8(0)
                or reader.read_u16() != UInt16(0)
            ):
                raise Error("metadata cache slot header is invalid")
            var payload_length = Int(reader.read_u32())
            if payload_length > reader.remaining():
                raise Error("metadata cache field payload is truncated")
            var fields = decode_payload(reader.read_bytes(payload_length))
            if live == UInt8(1):
                index.upsert(id, fields^)
            else:
                if len(fields) != 0:
                    raise Error("metadata tombstone cache contains fields")
                index.delete(id)
        if reader.remaining() != 0:
            raise Error("metadata cache has trailing bytes")
        index.finish_bulk()
        return index^

    def _append_slot(mut self, id: Int) raises -> Int:
        var ordinal = len(self._ids)
        self._ids.append(id)
        self._ordinals[id] = ordinal
        var empty = List[DocumentField]()
        self._fields.append(empty^)
        var size = len(self._ids)
        self._live.resize(size)
        self._keywords.resize(size)
        self._numbers.resize(size)
        return ordinal

    def _add_field(mut self, ordinal: Int, field: DocumentField) raises:
        if field.value.is_string() or field.value.is_boolean():
            self._keywords.add(field.name, field.value, ordinal)
        else:
            self._numbers.add(field.name, field.value, ordinal)

    def _remove_fields(mut self, ordinal: Int) raises:
        for index in range(len(self._fields[ordinal])):
            if (
                self._fields[ordinal][index].value.is_string()
                or self._fields[ordinal][index].value.is_boolean()
            ):
                self._keywords.remove(
                    self._fields[ordinal][index].name,
                    self._fields[ordinal][index].value,
                    ordinal,
                )
            else:
                self._numbers.remove(
                    self._fields[ordinal][index].name,
                    self._fields[ordinal][index].value,
                    ordinal,
                )

    def _validate_ordinal(self, ordinal: Int) raises:
        if ordinal < 0 or ordinal >= len(self._ids):
            raise Error("metadata ordinal out of bounds")


def _same_fields(
    left: List[DocumentField], right: List[DocumentField]
) raises -> Bool:
    """Compare payload representation, including type, order and signed zero."""
    if len(left) != len(right):
        return False
    for index in range(len(left)):
        ref a = left[index].value
        ref b = right[index].value
        if left[index].name != right[index].name or a.kind() != b.kind():
            return False
        if a.is_string():
            if a.as_string() != b.as_string():
                return False
        elif a.is_integer():
            if a.as_int() != b.as_int():
                return False
        elif a.is_floating():
            if bitcast[DType.uint64](a.as_float()) != bitcast[DType.uint64](
                b.as_float()
            ):
                return False
        elif a.is_boolean():
            if a.as_bool() != b.as_bool():
                return False
        else:
            return False
    return True


def build_metadata_index(
    ids: List[Int], tombstones: List[Bool], fields: List[List[DocumentField]]
) raises -> MetadataIndex:
    """Build derived metadata state in the supplied stable slot order."""
    if len(ids) != len(tombstones) or len(ids) != len(fields):
        raise Error("metadata recovery columns must have equal lengths")
    var index = MetadataIndex()
    index.begin_bulk()
    for ordinal in range(len(ids)):
        if tombstones[ordinal]:
            index.delete(ids[ordinal])
        else:
            var owned = clone_fields(fields[ordinal])
            index.upsert(ids[ordinal], owned^)
    index.finish_bulk()
    return index^
