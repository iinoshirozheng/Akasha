"""F32 projections for derived dense indexes; authority keeps its native dtype."""

from akasha.document.vector_value import VectorValue


def _convert[dtype: DType](value: VectorValue) raises -> List[Float32]:
    var source = value._dense_reader[dtype]()
    var result = List[Float32](capacity=len(source))
    for index in range(len(source)):
        result.append(Float32(source[index]))
    return result^


def dense_f32_projection(value: VectorValue) raises -> List[Float32]:
    if value.scalar() == 0:
        return value._dense_reader[DType.float32]().to_list()
    if value.scalar() == 1:
        return _convert[DType.bfloat16](value)
    if value.scalar() == 2:
        return _convert[DType.float16](value)
    if value.scalar() == 3:
        return _convert[DType.int8](value)
    return _convert[DType.uint8](value)
