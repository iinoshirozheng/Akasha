"""Eligibility contract shared by graph construction and traversal."""
from akasha.index.hnsw_storage import HnswGraphAccess

trait HnswResultAdmission:
    """Internal result-admission contract shared by graph search paths."""

    def is_allow_all(self) -> Bool:
        ...

    def validate(self, slot_count: Int) raises:
        ...

    def _allows_item(self, slot: UInt32, id: Int) raises -> Bool:
        """Admit a candidate whose public ID has already been resolved."""
        ...

    def _allows_slot[GraphType: HnswGraphAccess](
        self, graph: GraphType, slot: UInt32
    ) raises -> Bool:
        """Admit a current graph slot, resolving its ID only when needed.

        Traversal owns readiness, slot/level and current-node checks. Existing
        ID-based admission still uses the graph's checked public-ID getter.
        """
        ...
