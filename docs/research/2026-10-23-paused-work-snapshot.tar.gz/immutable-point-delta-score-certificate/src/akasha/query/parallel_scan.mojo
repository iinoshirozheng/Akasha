from akasha.query.batch_executor import _score_prevalidated
from akasha.compute.dispatch import (
    DistanceExecutionStats,
    portable_simd_width,
)
from akasha.compute.simd import (
    prevalidated_simd_cosine_similarity,
    prevalidated_simd_dot_product,
    prevalidated_simd_l2_squared_distance,
)
from akasha.compute.topk import BoundedTopK
from akasha.index.flat import SearchResult
from akasha.query.batch_executor import (
    BATCH_COSINE_METRIC,
    BATCH_DOT_METRIC,
    BATCH_L2_METRIC,
    batch_metric_name,
)
from akasha.storage.memtable import MemTable
from max.algorithm import parallelize
from std.math import isfinite


struct ParallelScanExecution(Movable):
    """Parallel scan results plus common distance-execution statistics."""

    var results: List[SearchResult]
    var stats: DistanceExecutionStats

    def __init__(
        out self,
        var results: List[SearchResult],
        var stats: DistanceExecutionStats,
    ):
        self.results = results^
        self.stats = stats^


def execute_parallel_scan_reported(
    memtable: MemTable,
    ordinals: List[Int],
    query: List[Float32],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> ParallelScanExecution:
    """Execute parallel exact scan and report its selected CPU backend."""
    var results = execute_parallel_scan(
        memtable, ordinals, query, k, metric, num_workers
    )
    var evaluations = len(ordinals)
    var stats = DistanceExecutionStats(
        String("portable-simd-", portable_simd_width()),
        batch_metric_name(metric),
        "f32",
        "",
        0,
        0,
        evaluations,
        evaluations,
    )
    return ParallelScanExecution(results^, stats^)


def execute_parallel_scan(
    memtable: MemTable,
    ordinals: List[Int],
    query: List[Float32],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> List[SearchResult]:
    """Scan deterministic ordinal ranges and merge range-local Top-K heaps."""
    var entries = memtable.entry_view()
    var dimension = memtable.dimension
    if len(query) != dimension:
        raise Error("query dimension does not match snapshot")
    if k <= 0:
        raise Error("k must be positive")
    if num_workers < 0:
        raise Error("parallel scan worker count cannot be negative")
    if (
        metric != BATCH_DOT_METRIC
        and metric != BATCH_L2_METRIC
        and metric != BATCH_COSINE_METRIC
    ):
        raise Error("unknown parallel scan metric")
    for value in query:
        if not isfinite(value):
            raise Error("query vector must contain only finite values")
    for entry_index in range(len(ordinals)):
        if not memtable.is_live_at(ordinals[entry_index]):
            raise Error("parallel scan candidate slot is not live")
        if entries[ordinals[entry_index]].dense_bytes() != dimension * 4:
            raise Error("parallel scan candidate dimension mismatch")
    if len(ordinals) == 0:
        return List[SearchResult]()

    var result_count = min(k, len(ordinals))
    var range_count = 8 if num_workers == 0 else num_workers
    range_count = min(max(range_count, 1), len(ordinals))
    var heaps = List[BoundedTopK[]](capacity=range_count)
    for _ in range(range_count):
        heaps.append(
            BoundedTopK(
                result_count,
                smaller_is_better=metric == BATCH_L2_METRIC,
            )
        )

    var errors = List[String](length=range_count, fill="")

    def scan_range(
        range_index: Int,
    ) {
        imm entries, imm ordinals, imm query, imm metric, imm range_count,
        mut heaps, mut errors,
    }:
        try:
            var start = (len(ordinals) * range_index) // range_count
            var end = (len(ordinals) * (range_index + 1)) // range_count
            for entry_index in range(start, end):
                ref entry = entries[ordinals[entry_index]]
                var score = _score_prevalidated(metric, query, entry._dense_reader())
                heaps[range_index].offer(entry.id, score)
        except error:
            errors[range_index] = String(error)

    if range_count == 1:
        scan_range(0)
    elif num_workers == 0:
        parallelize(scan_range, range_count)
    else:
        parallelize(scan_range, range_count, min(num_workers, range_count))

    for error in errors:
        if error.byte_length() > 0:
            raise Error(error)

    var merged = BoundedTopK(
        result_count, smaller_is_better=metric == BATCH_L2_METRIC
    )
    for range_index in range(range_count):
        var local = heaps[range_index].sorted_entries()
        for entry in local:
            merged.offer(entry.id, entry.score)
    var retained = merged.sorted_entries()
    var output = List[SearchResult](capacity=len(retained))
    for entry in retained:
        output.append(SearchResult(entry.id, entry.score))
    return output^
