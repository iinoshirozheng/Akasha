from akasha.document.numeric_read_view import _NumericReadView
from akasha.compute.dispatch import (
    DistanceExecutionStats,
    portable_simd_width,
)
from akasha.compute.distance import (
    cosine_similarity,
    dot_product,
    l2_squared_distance,
)
from akasha.compute.simd import (
    prevalidated_simd_cosine_similarity,
    prevalidated_simd_dot_product,
    prevalidated_simd_l2_squared_distance,
)
from akasha.compute.topk import BoundedTopK
from akasha.index.flat import SearchResult
from akasha.storage.memtable import MemTable
from max.algorithm import parallelize
from std.math import isfinite


comptime BATCH_DOT_METRIC = 0
comptime BATCH_L2_METRIC = 1
comptime BATCH_COSINE_METRIC = 2


struct ExactBatchExecution(Movable):
    """Exact batch results plus common distance-execution statistics."""

    var results: List[List[SearchResult]]
    var stats: DistanceExecutionStats

    def __init__(
        out self,
        var results: List[List[SearchResult]],
        var stats: DistanceExecutionStats,
    ):
        self.results = results^
        self.stats = stats^


def batch_metric_name(metric: Int) raises -> String:
    if metric == BATCH_DOT_METRIC:
        return "dot"
    if metric == BATCH_L2_METRIC:
        return "l2"
    if metric == BATCH_COSINE_METRIC:
        return "cosine"
    raise Error("unknown batch query metric")


def execute_exact_batch_reported(
    memtable: MemTable,
    queries: List[List[Float32]],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> ExactBatchExecution:
    """Execute exact batch search and report its selected CPU backend."""
    var results = execute_exact_batch(memtable, queries, k, metric, num_workers)
    var evaluations = len(queries) * memtable.live_count()
    var stats = DistanceExecutionStats(
        String("portable-simd-", portable_simd_width()),
        batch_metric_name(metric),
        "f32",
        "",
        0,
        0,
        evaluations,
        evaluations,
    )
    return ExactBatchExecution(results^, stats^)


def execute_scalar_exact_reported(
    memtable: MemTable,
    query: List[Float32],
    k: Int,
    metric: Int,
) raises -> ExactBatchExecution:
    """Execute one exact query with scalar reference distance functions."""
    if k <= 0:
        raise Error("k must be positive")
    if len(query) != memtable.dimension:
        raise Error("query dimension does not match snapshot")
    var metric_name = batch_metric_name(metric)
    for value in query:
        if not isfinite(value):
            raise Error("query vector must contain only finite values")
    var entries = memtable.entry_view()
    var topk = BoundedTopK(k, smaller_is_better=metric == BATCH_L2_METRIC)
    for entry_index in range(len(entries)):
        ref entry = entries[entry_index]
        if entry.tombstone:
            continue
        var score: Float32
        if metric == BATCH_DOT_METRIC:
            score = dot_product(query, entry._dense_reader())
        elif metric == BATCH_L2_METRIC:
            score = l2_squared_distance(query, entry._dense_reader())
        else:
            score = cosine_similarity(query, entry._dense_reader())
        topk.offer(entry.id, score)
    var retained = topk.sorted_entries()
    var query_results = List[SearchResult](capacity=len(retained))
    for entry in retained:
        query_results.append(SearchResult(entry.id, entry.score))
    var results = List[List[SearchResult]]()
    results.append(query_results^)
    var stats = DistanceExecutionStats(
        "scalar-f32",
        metric_name^,
        "f32",
        "",
        0,
        0,
        memtable.live_count(),
        memtable.live_count(),
    )
    return ExactBatchExecution(results^, stats^)


def execute_exact_batch(
    memtable: MemTable,
    queries: List[List[Float32]],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> List[List[SearchResult]]:
    """Execute validated queries over every live slot of one table."""
    return execute_exact_ordinal_batch(
        memtable, queries, memtable.live_ordinals(), k, metric, num_workers
    )


def execute_exact_ordinal_batch(
    memtable: MemTable,
    queries: List[List[Float32]],
    ordinals: List[Int],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> List[List[SearchResult]]:
    """Score one shared list of live stable slots with a heap per query."""
    if k <= 0:
        raise Error("k must be positive")
    if num_workers < 0:
        raise Error("batch query worker count cannot be negative")
    if (
        metric != BATCH_DOT_METRIC
        and metric != BATCH_L2_METRIC
        and metric != BATCH_COSINE_METRIC
    ):
        raise Error("unknown batch query metric")
    for query_index in range(len(queries)):
        if len(queries[query_index]) != memtable.dimension:
            raise Error("query dimension does not match snapshot")
        for value in queries[query_index]:
            if not isfinite(value):
                raise Error("query vector must contain only finite values")
    if len(queries) == 0:
        return List[List[SearchResult]]()

    var entries = memtable.entry_view()
    for ordinal in ordinals:
        if not memtable.is_live_at(ordinal):
            raise Error("batch candidate slot is not live")

    var result_count = min(k, len(ordinals))
    var output = List[List[SearchResult]](capacity=len(queries))
    if result_count == 0:
        for _ in range(len(queries)):
            output.append(List[SearchResult]())
        return output^

    var heaps = List[BoundedTopK[]](capacity=len(queries))
    for _ in range(len(queries)):
        heaps.append(
            BoundedTopK(
                result_count,
                smaller_is_better=metric == BATCH_L2_METRIC,
            )
        )

    var errors = List[String](length=len(queries), fill="")

    def score_query(
        query_index: Int,
    ) {imm queries, imm ordinals, imm entries, mut heaps, imm metric, mut errors}:
        try:
            for ordinal in ordinals:
                var score = _score_prevalidated(metric, queries[query_index], entries[ordinal]._dense_reader())
                heaps[query_index].offer(entries[ordinal].id, score)
        except error:
            errors[query_index] = String(error)

    if len(queries) < 4 or num_workers == 1:
        for query_index in range(len(queries)):
            score_query(query_index)
    elif num_workers == 0:
        parallelize(score_query, len(queries))
    else:
        parallelize(score_query, len(queries), min(num_workers, len(queries)))

    for error in errors:
        if error.byte_length() > 0:
            raise Error(error)

    for query_index in range(len(queries)):
        var retained = heaps[query_index].sorted_entries()
        var results = List[SearchResult](capacity=len(retained))
        for entry in retained:
            results.append(SearchResult(entry.id, entry.score))
        output.append(results^)
    return output^


def execute_exact_candidate_batch(
    memtable: MemTable,
    queries: List[List[Float32]],
    candidates: List[List[Int]],
    k: Int,
    metric: Int,
    num_workers: Int,
) raises -> List[List[SearchResult]]:
    """Score one set of borrowed stable slots per query ordinal."""
    var entries = memtable.entry_view()
    if len(queries) != len(candidates):
        raise Error("batch query candidate count mismatch")
    if k <= 0:
        raise Error("k must be positive")
    if num_workers < 0:
        raise Error("batch query worker count cannot be negative")
    if (
        metric != BATCH_DOT_METRIC
        and metric != BATCH_L2_METRIC
        and metric != BATCH_COSINE_METRIC
    ):
        raise Error("unknown batch query metric")
    for query_index in range(len(queries)):
        if len(queries[query_index]) != memtable.dimension:
            raise Error("query dimension does not match snapshot")
        for value in queries[query_index]:
            if not isfinite(value):
                raise Error("query vector must contain only finite values")
        for ordinal in candidates[query_index]:
            if not memtable.is_live_at(ordinal):
                raise Error("batch candidate slot is not live")
    if len(queries) == 0:
        return List[List[SearchResult]]()

    var heaps = List[BoundedTopK[]](capacity=len(queries))
    for _ in range(len(queries)):
        heaps.append(
            BoundedTopK(
                k,
                smaller_is_better=metric == BATCH_L2_METRIC,
            )
        )

    var errors = List[String](length=len(queries), fill="")

    def score_query(
        query_index: Int,
    ) {imm queries, imm candidates, imm entries, mut heaps, imm metric, mut errors}:
        try:
            for entry_index in range(len(candidates[query_index])):
                ref entry = entries[candidates[query_index][entry_index]]
                var score = _score_prevalidated(metric, queries[query_index], entry._dense_reader())
                heaps[query_index].offer(entry.id, score)
        except error:
            errors[query_index] = String(error)

    if len(queries) < 4 or num_workers == 1:
        for query_index in range(len(queries)):
            score_query(query_index)
    elif num_workers == 0:
        parallelize(score_query, len(queries))
    else:
        parallelize(score_query, len(queries), min(num_workers, len(queries)))

    for error in errors:
        if error.byte_length() > 0:
            raise Error(error)

    var output = List[List[SearchResult]](capacity=len(queries))
    for query_index in range(len(queries)):
        var retained = heaps[query_index].sorted_entries()
        var results = List[SearchResult](capacity=len(retained))
        for entry in retained:
            results.append(SearchResult(entry.id, entry.score))
        output.append(results^)
    return output^


def _score_prevalidated(
    metric: Int, lhs: List[Float32], rhs: _NumericReadView[DType.float32, _]
) raises -> Float32:
    if metric == BATCH_DOT_METRIC:
        return prevalidated_simd_dot_product(lhs, rhs)
    if metric == BATCH_L2_METRIC:
        return prevalidated_simd_l2_squared_distance(lhs, rhs)
    return prevalidated_simd_cosine_similarity(lhs, rhs)
