from akasha.compute.dense_batch import _DenseScorePair
from akasha.compute.topk import BoundedTopK
from akasha.storage.memtable import MemTable


def offer_gathered_f32(
    table: MemTable,
    ordinals: List[Int],
    query: List[Float32],
    metric: Int,
    query_norm: Float32,
    mut topk: BoundedTopK[],
) raises:
    """Gather at most 64 borrowed rows, preserving the original score pairs.

    The immutable table borrow keeps every field owner stable. Establish the
    nested reader origin before constructing the batch, so no loop-interior
    borrow escapes and no owner copies or untracked origin casts are needed.
    A failed later acquisition is deferred until earlier pairs have been scored.
    """
    var position = 0
    while position < len(ordinals):
        if table.entry_ref_at(ordinals[position]).has_dense():
            break
        position += 1
    if position == len(ordinals):
        return
    var anchor = table.entry_ref_at(ordinals[position])._dense_reader()
    comptime Row = type_of(anchor)
    var batch = List[_DenseScorePair[Row.origin]](capacity=32)
    while position < len(ordinals):
        batch.clear()
        var pending_error = Optional[Error]()
        try:
            while position < len(ordinals) and len(batch) < 32:
                ref first = table.entry_ref_at(ordinals[position])
                position += 1
                if not first.has_dense():
                    continue
                if position < len(ordinals):
                    ref second = table.entry_ref_at(ordinals[position])
                    position += 1
                    if second.has_dense():
                        var first_row = first._dense_reader()
                        var second_row = second._dense_reader()
                        batch.append(_DenseScorePair[Row.origin](
                            first.id, first_row^, second.id, Optional(second_row^)
                        ))
                        continue
                batch.append(_DenseScorePair[Row.origin](
                    first.id, first._dense_reader(), 0, Optional[Row]()
                ))
        except error:
            pending_error = Optional(error^)
        for index in range(len(batch)):
            ref pair = batch[index]
            pair.offer(query, metric, query_norm, topk)
        if pending_error:
            raise pending_error.take()
