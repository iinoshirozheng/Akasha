from akasha.storage.checksum import crc32_update
from std.memory import unsafe_memcpy
from std.sys import size_of


struct _NumericReadView[dtype: DType, origin: ImmOrigin](Copyable, Movable, Sized):
    """Private bounded borrow of stable, immutable native numeric storage.

    The accepting owner guarantees that bytes remain initialized and immutable
    until this borrow ends. There is deliberately no safe constructor accepting
    an externally mutable List or an explicitly closeable MappedFile. A source
    factory must prove lifetime and range before constructing this view.
    """

    var _bytes: Span[UInt8, Self.origin]

    @always_inline
    def __init__(out self, *, unsafe_bytes: Span[UInt8, Self.origin]):
        self._bytes = unsafe_bytes

    @always_inline
    def __len__(self) -> Int:
        return len(self._bytes) // size_of[Scalar[Self.dtype]]()

    @always_inline
    def load[width: Int](self, index: Int) raises -> SIMD[Self.dtype, width]:
        if index < 0 or width > len(self) or index > len(self) - width:
            raise Error("numeric row load is out of bounds")
        return self._bytes.unsafe_ptr().unsafe_bitcast[Scalar[Self.dtype]]().unsafe_load[
            width=width, alignment=1
        ](index)

    @always_inline
    def __getitem__(self, index: Int) raises -> Scalar[Self.dtype]:
        return self.load[1](index)[0]

    @always_inline
    def slice(self, start: Int, count: Int) raises -> Self:
        if start < 0 or start > len(self) or count < 0 or count > len(self) - start:
            raise Error("numeric row slice is out of bounds")
        comptime width = size_of[Scalar[Self.dtype]]()
        return Self(unsafe_bytes=self._bytes[start * width : (start + count) * width])

    def to_list(self) -> List[Scalar[Self.dtype]]:
        """Explicit independent copy; the source owner stays borrowed."""
        var result = List[Scalar[Self.dtype]](unsafe_uninit_length=len(self))
        if len(self):
            unsafe_memcpy(
                dest=result.unsafe_ptr().unsafe_bitcast[UInt8](),
                src=self._bytes.unsafe_ptr(),
                count=len(self._bytes),
            )
        return result^

    def _update_native_crc32(self, register: UInt32) -> UInt32:
        return crc32_update(register, self._bytes)
