from akasha.document.numeric_read_view import _NumericReadView
from akasha.storage.mapped_vector_file import MappedVectorFile
from std.memory import ArcPointer, unsafe_memcpy
from std.sys import size_of
from std.utils import BlockingScopedLock, BlockingSpinLock


struct _MappedNumericState[dtype: DType](Movable):
    var file: ArcPointer[MappedVectorFile]
    var count: Int
    var lock: BlockingSpinLock
    var cache: List[Scalar[Self.dtype]]
    var materialized: Bool
    var materialization_count: Int

    def __init__(
        out self, file: ArcPointer[MappedVectorFile], byte_offset: Int, count: Int
    ) raises:
        comptime assert Self.dtype in (
            DType.float32, DType.bfloat16, DType.float16, DType.int8, DType.uint8
        )
        file[]._mapping._ensure_open()
        var length = file[]._mapping.byte_length()
        comptime scalar_bytes = size_of[Scalar[Self.dtype]]()
        if (
            byte_offset < 0 or byte_offset > length or count < 0
            or count > (length - byte_offset) // scalar_bytes
        ):
            raise Error("mapped numeric values are out of bounds")
        self.file = file.copy()
        self.count = count
        self.lock = BlockingSpinLock()
        self.cache = List[Scalar[Self.dtype]]()
        self.materialized = False
        self.materialization_count = 0


@fieldwise_init
struct _MappedNumericValues[dtype: DType](Movable):
    """Native typed authority, sharing one immutable leased file owner.

    Offset/count and file bytes remain immutable. Only explicit owned access
    builds the stable List; synchronous internal readers leave it absent.
    Finite and shape validation belongs to the accepting VectorValue factory.
    """

    var _state: ArcPointer[_MappedNumericState[Self.dtype]]
    # Immutable range lives beside the strong owner. Hot reads do not chase the
    # shared lazy-cache state; cloning copies the range and retains that owner.
    var _bytes: Span[UInt8, ImmUntrackedOrigin]

    def __init__(
        out self, file: ArcPointer[MappedVectorFile], byte_offset: Int, count: Int
    ) raises:
        self._state = ArcPointer(_MappedNumericState[Self.dtype](file, byte_offset, count))
        self._bytes = Span[UInt8, ImmUntrackedOrigin]()
        if count:
            # State construction has checked the full range and retained the
            # private, immutable file before this descriptor can be published.
            self._bytes = Span(
                unsafe_ptr=file[]._mapping._base.value().unsafe_offset(byte_offset),
                length=count * size_of[Scalar[Self.dtype]](),
            )

    def clone(self) -> Self:
        return Self(self._state.copy(), self._bytes)

    @always_inline
    def reader(self) -> _NumericReadView[Self.dtype, origin_of(self)]:
        # The Arc-owned private file has no early-close API. Both the immutable
        # range and the mapping remain valid until this owner's final release.
        comptime origin = origin_of(self)
        return _NumericReadView[Self.dtype, origin](unsafe_bytes=Span(
            unsafe_ptr=self._bytes.unsafe_ptr().unsafe_origin_cast[origin](),
            length=len(self._bytes),
        ))

    def values(self) -> ref[
        origin_of(self._state[].cache, self)
    ] List[Scalar[Self.dtype]]:
        var state = Pointer(to=self._state[])
        with BlockingScopedLock(state[].lock):
            if not state[].materialized:
                var ready = List[Scalar[Self.dtype]](unsafe_uninit_length=state[].count)
                if state[].count:
                    # Construction validated this entire immutable range. Its
                    # private file owner cannot close while state retains it.
                    # This copy preserves the non-raising legacy List getter.
                    unsafe_memcpy(
                        dest=ready.unsafe_ptr().unsafe_bitcast[UInt8](),
                        src=self._bytes.unsafe_ptr(),
                        count=state[].count * size_of[Scalar[Self.dtype]](),
                    )
                state[].cache = ready^
                state[].materialization_count += 1
                state[].materialized = True
        return self._state[].cache
