from akasha.storage.checksum import (
    BinaryReader,
    BorrowedBinaryReader,
    BinaryWriter,
    crc32_range,
    crc32_update,
    CRC32_INITIAL,
)
from akasha.document.codec import encode_payload
from akasha.storage.memtable import MemTable
from akasha.storage.filesystem import (
    atomic_replace,
    path_exists,
    sync_directory,
    sync_file,
)
from akasha.storage.mapped_file import MappedFile
from akasha.storage.mapped_reader import MappedBinaryReader
from std.sys.info import is_little_endian


comptime CACHE_HNSW_KIND = UInt8(1)
comptime CACHE_METADATA_KIND = UInt8(2)
comptime CACHE_HNSW_OVERLAY_KIND = UInt8(3)
comptime _VERSION = UInt16(1)
comptime _FIXED_BYTES = 40
comptime _MAX_PAYLOAD_BYTES = 512 * 1024 * 1024


struct CacheArtifact(Movable):
    """One rebuildable derived-index cache envelope."""

    var version: UInt16
    var kind: UInt8
    var dimension: Int
    var generation: UInt64
    var sequence: UInt64
    var source_checksum: UInt32
    var payload: List[UInt8]

    def __init__(
        out self,
        kind: UInt8,
        dimension: Int,
        generation: UInt64,
        sequence: UInt64,
        source_checksum: UInt32,
        var payload: List[UInt8],
    ) raises:
        _validate_header(kind, dimension, len(payload))
        self.version = _VERSION
        self.kind = kind
        self.dimension = dimension
        self.generation = generation
        self.sequence = sequence
        self.source_checksum = source_checksum
        self.payload = payload^

    def take_payload(mut self) -> List[UInt8]:
        var payload = self.payload^
        self.payload = List[UInt8]()
        return payload^


def _encode_cache_header(artifact: CacheArtifact) raises -> List[UInt8]:
    return encode_cache_header(
        artifact.kind, artifact.dimension, artifact.generation,
        artifact.sequence, artifact.source_checksum, len(artifact.payload),
    )


def encode_cache_header(
    kind: UInt8,
    dimension: Int,
    generation: UInt64,
    sequence: UInt64,
    source_checksum: UInt32,
    payload_bytes: Int,
) raises -> List[UInt8]:
    """Validate a sized payload before either owned or streamed publication."""
    _validate_header(kind, dimension, payload_bytes)
    var writer = BinaryWriter()
    writer.write_u8(UInt8(0x41))  # A
    writer.write_u8(UInt8(0x4B))  # K
    writer.write_u8(UInt8(0x49))  # I
    writer.write_u8(UInt8(0x43))  # C
    writer.write_u16(_VERSION)
    writer.write_u8(kind)
    writer.write_u8(UInt8(0))
    writer.write_u32(UInt32(dimension))
    writer.write_u64(generation)
    writer.write_u64(sequence)
    writer.write_u32(source_checksum)
    writer.write_u32(UInt32(payload_bytes))
    return writer.take_bytes()


def encode_cache(artifact: CacheArtifact) raises -> List[UInt8]:
    var header = _encode_cache_header(artifact)
    var bytes = List[UInt8](capacity=_FIXED_BYTES + len(artifact.payload))
    bytes.extend(Span(header))
    bytes.extend(Span(artifact.payload))
    var checksum = crc32_range(bytes, 0, len(bytes))
    for shift in range(0, 32, 8):
        bytes.append(UInt8(checksum >> UInt32(shift)))
    return bytes^


def decode_cache_bytes(var bytes: List[UInt8]) raises -> CacheArtifact:
    if len(bytes) < _FIXED_BYTES:
        raise Error("derived index cache is truncated")
    var stored_offset = len(bytes) - 4
    var stored_reader = BorrowedBinaryReader(Span(bytes)[stored_offset:])
    var stored_checksum = stored_reader.read_u32()
    if stored_checksum != crc32_range(bytes, 0, stored_offset):
        raise Error("derived index cache checksum mismatch")
    var header = _decode_cache_header(
        Span(bytes)[:36], len(bytes) - _FIXED_BYTES
    )
    var reader = BinaryReader(bytes^)
    _ = reader.read_bytes(36)
    return CacheArtifact(
        header[0],
        header[1],
        header[2],
        header[3],
        header[4],
        reader.read_bytes(header[5]),
    )


def _decode_cache_header(
    bytes: Span[UInt8, _],
    payload_bytes: Int,
) raises -> Tuple[UInt8, Int, UInt64, UInt64, UInt32, Int]:
    var reader = BorrowedBinaryReader(bytes)
    if (
        reader.read_u8() != UInt8(0x41)
        or reader.read_u8() != UInt8(0x4B)
        or reader.read_u8() != UInt8(0x49)
        or reader.read_u8() != UInt8(0x43)
    ):
        raise Error("invalid derived index cache magic")
    var version = reader.read_u16()
    if version != _VERSION:
        raise Error("unsupported derived index cache version")
    var kind = reader.read_u8()
    if reader.read_u8() != UInt8(0):
        raise Error("derived index cache reserved byte must be zero")
    var dimension_u32 = reader.read_u32()
    if dimension_u32 > UInt32(Int.MAX):
        raise Error("derived index cache dimension is too large")
    var dimension = Int(dimension_u32)
    var generation = reader.read_u64()
    var sequence = reader.read_u64()
    var source_checksum = reader.read_u32()
    var payload_length_u32 = reader.read_u32()
    if payload_length_u32 > UInt32(_MAX_PAYLOAD_BYTES):
        raise Error("derived index cache payload is too large")
    var payload_length = Int(payload_length_u32)
    if payload_bytes != payload_length:
        raise Error("derived index cache payload length mismatch")
    _validate_header(kind, dimension, payload_length)
    return (
        kind,
        dimension,
        generation,
        sequence,
        source_checksum,
        payload_length,
    )


def publish_cache(
    directory: String, name: String, artifact: CacheArtifact
) raises:
    _validate_cache_name(name)
    var final_path = directory + "/" + name
    var temporary_path = final_path + ".tmp"
    # Validate before opening the temporary path. The payload already owns its
    # bytes; borrow it for CRC and write instead of building another envelope.
    var header = _encode_cache_header(artifact)
    var register = crc32_update(CRC32_INITIAL, Span(header))
    var checksum = ~crc32_update(register, Span(artifact.payload))
    var footer = BinaryWriter()
    footer.write_u32(checksum)
    with open(temporary_path, "w") as file:
        file.write_all(header)
        file.write_all(artifact.payload)
        file.write_all(footer.take_bytes())
        sync_file(file)
    atomic_replace(temporary_path, final_path)
    sync_directory(directory)


@fieldwise_init
struct MappedCacheArtifact(Movable):
    """Own an immutable cache inode while its bounded payload is decoded."""

    var version: UInt16
    var kind: UInt8
    var dimension: Int
    var generation: UInt64
    var sequence: UInt64
    var source_checksum: UInt32
    var payload_length: Int
    var _mapping: MappedFile

    def payload_reader(self) raises -> MappedBinaryReader[origin_of(self._mapping)]:
        return MappedBinaryReader(
            Pointer(to=self._mapping), 36, self.payload_length
        )


def load_cache_artifact(path: String) -> Optional[MappedCacheArtifact]:
    """Bound and validate one optional derived artifact before using its key."""
    if not path_exists(path):
        return None
    try:
        # Cache publishers replace the inode atomically. Keep the old inode
        # mapped until its consumer has finished decoding the bounded payload.
        var mapping = MappedFile.open_readonly(path)
        var size = mapping.byte_length()
        if size < _FIXED_BYTES or size > _MAX_PAYLOAD_BYTES + _FIXED_BYTES:
            return None
        var checksum = mapping.load_scalars[DType.uint32, 1](size - 4)
        if checksum != mapping.checksum(0, UInt64(size - 4)):
            return None
        var bytes = mapping.copy_scalars[DType.uint8](0, 36)
        var header = _decode_cache_header(Span(bytes), size - _FIXED_BYTES)
        return Optional(
            MappedCacheArtifact(
                UInt16(1),
                header[0],
                header[1],
                header[2],
                header[3],
                header[4],
                header[5],
                mapping^,
            )
        )
    except:
        return None


def load_matching_cache_artifact(
    path: String,
    expected_kind: UInt8,
    expected_dimension: Int,
    expected_generation: UInt64,
    expected_sequence: UInt64,
    expected_source_checksum: UInt32,
) -> Optional[MappedCacheArtifact]:
    """Match a cache key before decoding; invalid artifacts are safe misses."""
    var loaded = load_cache_artifact(path)
    if not loaded:
        return None
    var artifact = loaded.take()
    if (
        artifact.kind != expected_kind
        or artifact.dimension != expected_dimension
        or artifact.generation != expected_generation
        or artifact.sequence != expected_sequence
        or artifact.source_checksum != expected_source_checksum
    ):
        return None
    return Optional(artifact^)


def authoritative_index_checksum(memtable: MemTable) raises -> UInt32:
    """Fingerprint unchanged bytes with at most one row/payload encoded at once.
    """
    var writer = BinaryWriter()
    writer.write_u32(UInt32(memtable.dimension))
    writer.write_u32(UInt32(memtable.slot_count()))
    var register = writer.update_crc32_and_clear(CRC32_INITIAL)
    for ordinal in range(memtable.slot_count()):
        ref entry = memtable.entry_ref_at(ordinal)
        writer.write_i64(Int64(entry.id))
        writer.write_u64(entry.sequence)
        writer.write_u8(UInt8(1) if entry.tombstone else UInt8(0))
        writer.write_u8(UInt8(0))
        writer.write_u16(UInt16(0))
        register = writer.update_crc32_and_clear(register)
        if entry.has_dense():
            var values = entry._dense_reader()
            comptime if is_little_endian():
                register = values._update_native_crc32(register)
            else:
                for index in range(len(values)):
                    writer.write_f32(values[index])
                register = writer.update_crc32_and_clear(register)
        var fields = encode_payload(entry.fields())
        writer.write_u32(UInt32(len(fields)))
        register = writer.update_crc32_and_clear(register)
        register = crc32_update(register, Span(fields))
    return ~register


def _validate_header(kind: UInt8, dimension: Int, payload_length: Int) raises:
    if (
        kind != CACHE_HNSW_KIND
        and kind != CACHE_METADATA_KIND
        and kind != CACHE_HNSW_OVERLAY_KIND
    ):
        raise Error("unknown derived index cache kind")
    if dimension <= 0:
        raise Error("derived index cache dimension must be positive")
    if payload_length < 0 or payload_length > _MAX_PAYLOAD_BYTES:
        raise Error("derived index cache payload is too large")


def _validate_cache_name(name: String) raises:
    if name.byte_length() == 0:
        raise Error("derived index cache name cannot be empty")
    for byte in name.bytes():
        if byte == UInt8(0) or byte == UInt8(0x2F):
            raise Error("derived index cache name is invalid")
