from akasha.storage.file_leases import ImmutableFileLease
from akasha.storage.generation_pins import GenerationPinRegistry, _record_file_cleanup_error
from akasha.storage.mapped_file import MappedFile
from std.memory import ArcPointer


struct MappedVectorFile(Movable):
    """Share through ArcPointer; only the last owner unmaps and releases its lease.

    Construction occurs under the source publication/writer exclusion. The
    file is immutable and this owner exposes no early-close operation.
    """

    var _mapping: MappedFile
    var _lease: ImmutableFileLease
    var _pins: ArcPointer[GenerationPinRegistry]

    def __init__(out self, pins: ArcPointer[GenerationPinRegistry], name: String) raises:
        var lease = ImmutableFileLease(pins[]._directory, pins[]._dimension, name)
        # Duplicate the leased descriptor rather than resolving a path again.
        var mapping = MappedFile._from_file(lease.file)
        self._mapping = mapping^
        self._lease = lease^
        self._pins = pins.copy()

    def _checked_bytes(self, offset: Int, count: Int) raises -> Span[UInt8, origin_of(self)]:
        var length = self._mapping.byte_length()
        if offset < 0 or offset > length or count < 0 or count > length - offset:
            raise Error("immutable mapped byte range is out of bounds")
        if count == 0:
            return Span[UInt8, origin_of(self)]()
        return Span(
            unsafe_ptr=self._mapping._base.value().unsafe_offset(offset).unsafe_origin_cast[origin_of(self)](),
            length=count,
        )

    def __deinit__(deinit self):
        self._mapping.close()
        try:
            self._lease.reclaim()
        except error:
            # Destruction cannot raise. Existing explicit retirement can retry
            # once the last lease is gone; retain the diagnostic on its registry.
            _record_file_cleanup_error(self._pins, String(error))
