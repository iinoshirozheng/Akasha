from akasha.document.point_state import (
    PointMutation,
    PointState,
    apply_point_mutation,
)
from akasha.document.vector_schema import FieldCatalog
from akasha.storage.filesystem import append_file_sync
from akasha.storage.memtable import MemTable, MemTableEntry, NumericOwnerReplacement
from akasha.storage.point_wal import (
    PointWalBatch,
    encode_point_batch,
    MAX_POINT_BATCH_MUTATIONS,
)
from std.collections import Dict
from std.memory import ArcPointer


@fieldwise_init
struct PointCommit(TrivialRegisterPassable):
    var first_sequence: UInt64
    var last_sequence: UInt64
    var mutation_count: Int


@fieldwise_init
struct PointCompactionOwners(Movable):
    var points: List[NumericOwnerReplacement]
    var projection: List[NumericOwnerReplacement]


struct PointTable(Movable):
    """Latest complete point states behind a collection's writer exclusion.

    Preparation touches only mutated IDs and retains independent field owners.
    All raising validation and WAL encoding precede append/fsync. Publication
    uses only non-raising moves. An uncertain append poisons subsequent writes
    until the enclosing collection is reopened and its WAL is preflighted.
    """

    var _catalog: ArcPointer[FieldCatalog]
    var _points: List[PointState]
    var _ordinals: Dict[Int, Int]
    var _last_sequence: UInt64
    var _checkpoint_sequence: UInt64
    var _live_count: Int
    var _write_failed: Bool

    def __init__(
        out self,
        var catalog: ArcPointer[FieldCatalog],
        checkpoint_sequence: UInt64,
        var points: List[PointState] = List[PointState](),
    ) raises:
        catalog[].validate()
        if (
            catalog[].format_version != 2
            or checkpoint_sequence < catalog[].legacy_cutover_sequence
        ):
            raise Error(
                "point authority requires a catalog and valid checkpoint"
            )
        var ordinals = Dict[Int, Int]()
        var live_count = 0
        for ordinal in range(len(points)):
            ref point = points[ordinal]
            point.validate(catalog[])
            if point.sequence > checkpoint_sequence or point.id in ordinals:
                raise Error("invalid checkpoint point sequence or duplicate ID")
            ordinals[point.id] = ordinal
            if not point.tombstone:
                live_count += 1
        self._catalog = catalog^
        self._points = points^
        self._ordinals = ordinals^
        self._last_sequence = checkpoint_sequence
        self._checkpoint_sequence = checkpoint_sequence
        self._live_count = live_count
        self._write_failed = False

    def _take_points(mut self) -> List[PointState]:
        """Detach file-owning fields while keeping the shared table allocation stable."""
        var points = self._points^
        self._points = List[PointState]()
        self._ordinals.clear()
        self._live_count = 0
        return points^

    def last_sequence(self) -> UInt64:
        return self._last_sequence

    def live_count(self) -> Int:
        return self._live_count

    def slot_count(self) -> Int:
        return len(self._points)

    def entry_view(self) -> Span[PointState, origin_of(self._points)]:
        return Span(self._points)

    def read_projection(self) raises -> MemTable:
        """Capture shared field descriptors in stable point-slot order."""
        var table = MemTable(self._catalog[].field_at(0).dimension)
        for index in range(len(self._points)):
            table.put(MemTableEntry.from_point(self._points[index]))
        table.last_sequence = self._last_sequence
        return table^

    def entry(
        self, id: Int
    ) raises -> ref[origin_of(self._points[0])] PointState:
        """Borrow the accepted state, including a tombstone, for publication."""
        var ordinal = self._ordinals.get(id, -1)
        if ordinal < 0:
            raise Error("accepted point is absent")
        return self._points[ordinal]

    def get(self, id: Int) -> Optional[PointState]:
        var ordinal = self._ordinals.get(id, -1)
        if ordinal < 0 or self._points[ordinal].tombstone:
            return Optional[PointState]()
        return Optional(self._points[ordinal].copy())

    def live_points(self) raises -> List[PointState]:
        """Capture ID-ordered descriptors for a complete-state base segment."""
        var ids = List[Int](capacity=self._live_count)
        for ordinal in range(len(self._points)):
            if not self._points[ordinal].tombstone:
                ids.append(self._points[ordinal].id)
        sort(Span(ids))
        var points = List[PointState](capacity=len(ids))
        for id in ids:
            points.append(self._points[self._ordinals[id]].copy())
        return points^

    def append_batch(
        mut self, wal_path: String, mutations: List[PointMutation]
    ) raises -> PointCommit:
        if self._write_failed:
            raise Error(
                "point writer requires recovery after failed WAL append"
            )
        if len(mutations) == 0 or len(mutations) > MAX_POINT_BATCH_MUTATIONS:
            raise Error("point batch count exceeds bounds")
        if UInt64(len(mutations)) > UInt64.MAX - self._last_sequence:
            raise Error("point sequence exhausted")
        var first = self._last_sequence + 1
        var last = self._last_sequence + UInt64(len(mutations))
        var states = self._prepare(first, mutations)
        var bytes = encode_point_batch(first, mutations, self._catalog[])
        self._points.reserve(len(self._points) + len(states))
        self._write_failed = True
        append_file_sync(wal_path, bytes)
        self._publish(states^, last)
        self._write_failed = False
        return PointCommit(first, last, len(mutations))

    def points_after(self, sequence: UInt64) raises -> List[PointState]:
        """Capture complete changed states, including tombstones, by point ID.
        """
        var ids = List[Int]()
        for ordinal in range(len(self._points)):
            if self._points[ordinal].sequence > sequence:
                ids.append(self._points[ordinal].id)
        sort(Span(ids))
        var points = List[PointState](capacity=len(ids))
        for id in ids:
            points.append(self._points[self._ordinals[id]].copy())
        return points^

    def replay(mut self, batch: PointWalBatch) raises:
        """Replay one complete, decoded envelope after full-source preflight.

        A checkpoint covers whole batches. A retained WAL prefix may be ignored,
        but a batch crossing the checkpoint or repeating newer state is corrupt.
        """
        if self._write_failed:
            raise Error("failed writer cannot be reused for recovery")
        var last = batch.last_sequence()
        if last <= self._checkpoint_sequence:
            return
        var states = self._prepare(batch.first_sequence, batch.mutations, batch.format_version)
        self._publish(states^, last)

    def _prepare(
        self, first: UInt64, mutations: List[PointMutation], mutation_format: Int = 5
    ) raises -> List[PointState]:
        if (
            len(mutations) == 0
            or len(mutations) > MAX_POINT_BATCH_MUTATIONS
            or first <= self._last_sequence
            or UInt64(len(mutations) - 1) > UInt64.MAX - first
        ):
            raise Error("invalid point batch sequence or count")
        var states = List[PointState]()
        var staged = Dict[Int, Int]()
        for index in range(len(mutations)):
            ref mutation = mutations[index]
            var staged_ordinal = staged.get(mutation.id, -1)
            var previous = Optional[PointState]()
            if staged_ordinal >= 0:
                previous = Optional(states[staged_ordinal].copy())
            else:
                var ordinal = self._ordinals.get(mutation.id, -1)
                if ordinal >= 0:
                    previous = Optional(self._points[ordinal].copy())
            var next = apply_point_mutation(
                previous, mutation, first + UInt64(index), self._catalog[], mutation_format
            )
            if staged_ordinal >= 0:
                states[staged_ordinal] = next^
            else:
                staged[mutation.id] = len(states)
                states.append(next^)
        return states^

    def _stage_checkpoint_owners(self, points: List[PointState]) raises -> List[PointState]:
        """Validate a persisted replacement before publishing any new owner.

        Checkpoints change numeric storage, not logical field versions, payload
        or sparse/binary ownership. Previously acquired point copies stay valid.
        """
        var staged = List[PointState](capacity=len(points))
        for point in points:
            point.validate(self._catalog[])
            ref current = self.entry(point.id)
            if (
                current.sequence != point.sequence
                or current.document_sequence != point.document_sequence
                or current.tombstone != point.tombstone
                or current.field_count() != point.field_count()
            ):
                raise Error("checkpoint owner replacement differs from current state")
            var next = current.copy()
            for ordinal in range(point.field_count()):
                ref field = point.field_at(ordinal)
                if field.id != current.field_at(ordinal).id:
                    raise Error("checkpoint owner replacement field mismatch")
                if field.value().kind() == 0 or field.value().kind() == 2:
                    next._fields[ordinal] = field.copy()
            staged.append(next^)
        return staged^

    def _publish_checkpoint_owners(mut self, points: List[PointState], sequence: UInt64):
        self._publish(points.copy(), sequence)
        self._checkpoint_sequence = sequence

    def _stage_compaction_owners(
        self, points: List[PointState], cutoff: UInt64, projection: MemTable
    ) raises -> PointCompactionOwners:
        """Validate both authorities before any disk or field publication.

        Newer complete point versions retain their owners. Unchanged versions
        exchange only numeric fields; all sequence counters and slots stay put.
        The caller excludes writes until publication and retains previous owners
        until outside writer, where their last file lease may reclaim a path.
        """
        var owners = List[NumericOwnerReplacement]()
        var read_owners = List[NumericOwnerReplacement]()
        # The mapped segment decoder validated each complete point before
        # writer acquisition. Only live identity/version checks belong here.
        for point in points:
            var slot = self._ordinals.get(point.id, -1)
            if slot < 0:
                raise Error("compaction point is absent from live authority")
            ref current = self._points[slot]
            if current.sequence > cutoff:
                continue
            var read_slot = projection.ordinal_for(point.id)
            if read_slot < 0:
                raise Error("compaction point is absent from read projection")
            ref row = projection.entry_ref_at(read_slot)
            if (
                point.sequence > cutoff
                or current.sequence != point.sequence
                or current.document_sequence != point.document_sequence
                or current.tombstone != point.tombstone
                or current.field_count() != point.field_count()
                or row.sequence != current.sequence
                or row.document_sequence != current.document_sequence
                or row.tombstone != current.tombstone
                or len(row._vectors) != current.field_count()
            ):
                raise Error("compaction owner replacement differs from current point")
            for field in range(point.field_count()):
                ref stored = point.field_at(field)
                ref previous = current.field_at(field)
                if (
                    stored.id != previous.id
                    or stored.value().kind() != previous.value().kind()
                    or stored.value().scalar() != previous.value().scalar()
                    or stored.value().content_bytes() != previous.value().content_bytes()
                    or row.vector_at(field).id != previous.id
                    or row.vector_at(field).address() != previous.address()
                ):
                    raise Error("compaction numeric field or projection mismatch")
                if stored.value().kind() == 0 or stored.value().kind() == 2:
                    owners.append(NumericOwnerReplacement(slot, field, stored.copy(), previous.copy()))
                    read_owners.append(NumericOwnerReplacement(read_slot, field, stored.copy(), row.vector_at(field).copy()))
        return PointCompactionOwners(owners^, read_owners^)

    def _stage_migrated_compaction_owners(
        self, entries: List[MemTableEntry], cutoff: UInt64, projection: MemTable
    ) raises -> PointCompactionOwners:
        """Exchange the legacy prefix after catalog cutover, before typed flush.

        Migration anchors point versions at cutover while retaining each legacy
        document version. Validate that version, not the old dense row sequence.
        Later typed mutations keep their complete current owners.
        """
        var owners = List[NumericOwnerReplacement]()
        var read_owners = List[NumericOwnerReplacement]()
        for index in range(len(entries)):
            ref entry = entries[index]
            var slot = self._ordinals.get(entry.id, -1)
            if slot < 0:
                raise Error("migrated compaction point is missing")
            ref current = self._points[slot]
            if current.sequence > cutoff:
                continue
            var read_slot = projection.ordinal_for(entry.id)
            if read_slot < 0:
                raise Error("migrated compaction projection is missing")
            ref row = projection.entry_ref_at(read_slot)
            if (
                current.sequence != self._catalog[].legacy_cutover_sequence
                or current.document_sequence != entry.document_sequence
                or current.tombstone != entry.tombstone
                or row.sequence != current.sequence
                or row.document_sequence != current.document_sequence
                or row.tombstone != current.tombstone
                or row.has_dense() != entry.has_dense()
                or row.dense_bytes() != entry.dense_bytes()
            ):
                raise Error("migrated compaction point version mismatch")
            if not entry.has_dense():
                continue
            var field = row.field_ordinal(0)
            if (
                field >= current.field_count()
                or current.field_at(field).id != 0
                or row.vector_at(field).address() != current.field_at(field).address()
            ):
                raise Error("migrated compaction projection owner mismatch")
            ref replacement = entry.vector_at(entry.field_ordinal(0))
            owners.append(NumericOwnerReplacement(
                slot, field, replacement.copy(), current.field_at(field).copy()
            ))
            read_owners.append(NumericOwnerReplacement(
                read_slot, field, replacement.copy(), row.vector_at(field).copy()
            ))
        return PointCompactionOwners(owners^, read_owners^)

    def _publish_compaction_owners(mut self, owners: List[NumericOwnerReplacement]):
        for index in range(len(owners)):
            ref owner = owners[index]
            self._points[owner.point_ordinal]._fields[owner.field_ordinal] = owner.replacement.copy()

    def _publish(mut self, var states: List[PointState], last: UInt64):
        for var point in states^:
            var ordinal = self._ordinals.get(point.id, -1)
            if ordinal < 0:
                if not point.tombstone:
                    self._live_count += 1
                self._ordinals[point.id] = len(self._points)
                self._points.append(point^)
            else:
                if self._points[ordinal].tombstone != point.tombstone:
                    self._live_count += -1 if point.tombstone else 1
                self._points[ordinal] = point^
        self._last_sequence = last
