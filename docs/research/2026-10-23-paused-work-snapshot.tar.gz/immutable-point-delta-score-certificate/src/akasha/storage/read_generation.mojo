"""Immutable read owners, separate from mutable collection and snapshot handles.

A published root is a chain of immutable runs, oldest first: one base, sealed
deltas and at most one frozen head copy. From the eighth sealed run a merge of
the run prefix into a new base is due; writers wait at sixteen. Runs share dense, payload
and sparse field owners with the collection's MemTable. A row is visible only
when it is live in its run and no newer run holds any state (including a
tombstone) for its ID. Base and sealed runs carry metadata and sparse indexes
over their own slots; the small frozen head is evaluated directly.
"""

from akasha.document.vector_schema import FieldCatalog
from akasha.common.config import CollectionConfig
from akasha.compute.gpu.context import GpuSnapshotState
from akasha.document.record import clone_fields
from akasha.index.artifact_state import ArtifactState, PqArtifacts
from akasha.index.field_ivf import FieldIvfArtifacts
from akasha.index.field_artifacts import FieldArtifacts
from akasha.index.field_hnsw import FieldHnswIndex
from akasha.index.field_sparse import FieldSparseIndex
from akasha.index.bitmap import Bitmap
from akasha.index.metadata import MetadataIndex
from akasha.index.quantization import Sq8Index
from akasha.index.sparse import SparseElement, SparseIndex, sparse_score_is_eligible
from akasha.query.evaluator import matches_all, matches_expression
from akasha.query.filter_ast import FilterCondition, FilterExpression
from akasha.query.index_evaluator import evaluate_all, evaluate_expression
from akasha.storage.generation_pins import GenerationPinRegistry
from akasha.storage.memtable import MemTable, MemTableEntry, NumericOwnerReplacement
from std.memory import ArcPointer
from std.time import sleep


comptime HEAD_MAX_POINTS = 1024
comptime HEAD_MAX_BYTES = 4 * 1024 * 1024
comptime MAX_SEALED_RUNS = 8
"""Sealed runs at which a merge of the run prefix is due."""
comptime SEALED_RUN_LIMIT = 2 * MAX_SEALED_RUNS
"""Sealed runs at which writers wait for the merge before the next write."""


struct RunIndex(Movable):
    """Derived indexes of one run: metadata by slot, sparse by live ID."""

    var metadata: MetadataIndex
    var sparse: SparseIndex

    def __init__(
        out self, var metadata: MetadataIndex, var sparse: SparseIndex
    ):
        self.metadata = metadata^
        self.sparse = sparse^


struct SparseHit(TrivialRegisterPassable):
    """A visible row's sparse dot product, located in its run."""

    var ordinal: Int
    var id: Int
    var score: Float32

    def __init__(out self, ordinal: Int, id: Int, score: Float32):
        self.ordinal = ordinal
        self.id = id
        self.score = score


struct ReadRun(Movable):
    """One immutable run; only construction mutates it.

    Field owners are shared; its descriptors belong to this run alone. A run
    without an index (the frozen head) is evaluated field by field.
    """

    var memtable: MemTable
    var index: Optional[ArcPointer[RunIndex]]

    def __init__(
        out self, var memtable: MemTable, var index: Optional[ArcPointer[RunIndex]]
    ):
        self.memtable = memtable^
        self.index = index^


struct ReadLayer(Copyable, Movable):
    """A run as seen by one root: sorted slots shadowed by newer runs."""

    var run: ArcPointer[ReadRun]
    # Shared by every root with the same sealed chain; replaced, never mutated.
    var sealed_hidden: ArcPointer[List[Int]]
    # Slots shadowed by this root's frozen head; bounded by the head size.
    var head_hidden: List[Int]

    def __init__(
        out self,
        var run: ArcPointer[ReadRun],
        var sealed_hidden: ArcPointer[List[Int]],
        var head_hidden: List[Int],
    ):
        self.run = run^
        self.sealed_hidden = sealed_hidden^
        self.head_hidden = head_hidden^

    def is_shadowed(self) -> Bool:
        return len(self.sealed_hidden[]) > 0 or len(self.head_hidden) > 0

    def is_visible(self, ordinal: Int) raises -> Bool:
        """Check one slot: live in its run and not shadowed by a newer run."""
        return (
            self.run[].memtable.is_live_at(ordinal)
            and not contains_sorted(self.sealed_hidden[], ordinal)
            and not contains_sorted(self.head_hidden, ordinal)
        )

    def visible(self, ordinals: List[Int]) raises -> List[Int]:
        """Drop tombstones and shadowed slots from ascending run slots."""
        var result = List[Int](capacity=len(ordinals))
        var sealed = 0
        var head = 0
        for ordinal in ordinals:
            if not self.run[].memtable.is_live_at(ordinal):
                continue
            while (
                sealed < len(self.sealed_hidden[])
                and self.sealed_hidden[][sealed] < ordinal
            ):
                sealed += 1
            while (
                head < len(self.head_hidden)
                and self.head_hidden[head] < ordinal
            ):
                head += 1
            if (
                sealed < len(self.sealed_hidden[])
                and self.sealed_hidden[][sealed] == ordinal
            ) or (
                head < len(self.head_hidden)
                and self.head_hidden[head] == ordinal
            ):
                continue
            result.append(ordinal)
        return result^


struct ReadGeneration(Movable):
    """One published view; its last strong owner releases its generation pin."""

    var config: CollectionConfig
    var generation: UInt64
    var sequence: UInt64
    var revision: UInt64
    var layers: List[ReadLayer]
    var visible_count: Int
    var dense_count: Int
    var catalog: Optional[ArcPointer[FieldCatalog]]
    # Device table and cache derived from this root; shared by every handle
    # and operation that owns the root, released with it.
    var device: ArcPointer[GpuSnapshotState]
    # Raw and cosine-normalized SQ8 artifacts derived from this root; shared by
    # operation that owns the root, built once and released with it.
    var sq8: ArcPointer[ArtifactState[Sq8Index]]
    var sq8_cosine: ArcPointer[ArtifactState[Sq8Index]]
    var pq: ArcPointer[PqArtifacts]
    var pq_cosine: ArcPointer[PqArtifacts]
    var field_hnsw: ArcPointer[FieldArtifacts[FieldHnswIndex]]
    var field_sparse: ArcPointer[FieldArtifacts[FieldSparseIndex]]
    var field_ivf: ArcPointer[FieldIvfArtifacts]
    var _pins: ArcPointer[GenerationPinRegistry]

    def __init__(
        out self,
        config: CollectionConfig,
        generation: UInt64,
        sequence: UInt64,
        revision: UInt64,
        var layers: List[ReadLayer],
        visible_count: Int,
        dense_count: Int,
        var pins: ArcPointer[GenerationPinRegistry],
        var catalog: Optional[ArcPointer[FieldCatalog]],
    ) raises:
        self.config = config.copy()
        self.catalog = catalog^
        self.generation = generation
        self.sequence = sequence
        self.revision = revision
        self.layers = layers^
        self.visible_count = visible_count
        self.dense_count = dense_count
        self.device = ArcPointer(GpuSnapshotState(generation, sequence))
        self.sq8 = ArcPointer(ArtifactState[Sq8Index]())
        self.sq8_cosine = ArcPointer(ArtifactState[Sq8Index]())
        self.pq = ArcPointer(PqArtifacts())
        self.pq_cosine = ArcPointer(PqArtifacts())
        self.field_hnsw = ArcPointer(FieldArtifacts[FieldHnswIndex]())
        self.field_sparse = ArcPointer(FieldArtifacts[FieldSparseIndex]())
        self.field_ivf = ArcPointer(FieldIvfArtifacts())
        self._pins = pins^
        self._pins[].pin(generation)

    def __deinit__(deinit self):
        self._pins[].unpin(self.generation)

    def layer_count(self) -> Int:
        return len(self.layers)

    def run(
        self, layer: Int
    ) -> ref[origin_of(self.layers[layer].run[], self)] ReadRun:
        """Borrow one run readonly; union with self blocks mutation."""
        return self.layers[layer].run[]

    def find(self, id: Int) raises -> Tuple[Int, Int]:
        """Return (layer, slot) of the newest live state, or (-1, -1)."""
        var layer = len(self.layers) - 1
        while layer >= 0:
            ref table = self.layers[layer].run[].memtable
            var ordinal = table.ordinal_for(id)
            if ordinal >= 0:
                if not table.is_live_at(ordinal):
                    return (-1, -1)
                return (layer, ordinal)
            layer -= 1
        return (-1, -1)

    def visible_ordinals(self, layer: Int) raises -> List[Int]:
        """Return ascending visible slots of one run."""
        ref item = self.layers[layer]
        if not item.is_shadowed():
            return item.run[].memtable.live_ordinals()
        return item.visible(item.run[].memtable.live_ordinals())

    def dense_ordinals(
        self, layer: Int, candidates: List[Int]
    ) raises -> List[Int]:
        """Keep only present default vectors from already-visible candidates."""
        var selected = List[Int](capacity=len(candidates))
        ref table = self.run(layer).memtable
        for ordinal in candidates:
            if table.entry_ref_at(ordinal).has_dense():
                selected.append(ordinal)
        return selected^

    def has_dense(self) -> Bool:
        """Whether at least one visible point has the default dense field."""
        return self.dense_count > 0

    def candidate_ordinals(
        self, layer: Int, candidates: Bitmap
    ) raises -> List[Int]:
        """Return visible slots of one run selected by its own metadata bitmap.
        """
        ref item = self.layers[layer]
        if candidates.size() != item.run[].memtable.slot_count():
            raise Error("candidate bitmap does not align with run slots")
        var selected = List[Int](capacity=candidates.count())
        for ordinal in candidates.set_ordinals():
            selected.append(ordinal)
        return item.visible(selected)

    def filtered_ordinals(
        self, layer: Int, expression: FilterExpression
    ) raises -> List[Int]:
        """Return ascending visible slots of one run matching a filter."""
        ref run = self.layers[layer].run[]
        if run.index:
            return self.candidate_ordinals(
                layer,
                evaluate_expression(run.index.value()[].metadata, expression),
            )
        var result = List[Int]()
        for ordinal in self.visible_ordinals(layer):
            if matches_expression(
                run.memtable.entry_ref_at(ordinal).fields(), expression
            ):
                result.append(ordinal)
        return result^

    def conditioned_ordinals(
        self, layer: Int, conditions: List[FilterCondition]
    ) raises -> List[Int]:
        """Return ascending visible slots of one run matching every condition.
        """
        ref run = self.layers[layer].run[]
        if run.index:
            return self.candidate_ordinals(
                layer, evaluate_all(run.index.value()[].metadata, conditions)
            )
        var result = List[Int]()
        for ordinal in self.visible_ordinals(layer):
            if matches_all(
                run.memtable.entry_ref_at(ordinal).fields(), conditions
            ):
                result.append(ordinal)
        return result^

    def sparse_hits(
        self, layer: Int, query: List[SparseElement]
    ) raises -> List[SparseHit]:
        """Score visible rows of one run sharing a term with a valid query.

        Indexed and direct scoring both sum in ascending query-term order, so
        a row scores bit-identically in any run.
        """
        ref item = self.layers[layer]
        ref table = item.run[].memtable
        var hits = List[SparseHit]()
        if item.run[].index:
            for scored in item.run[].index.value()[].sparse.scores(query):
                var ordinal = table.ordinal_for(scored.id)
                if ordinal >= 0 and item.is_visible(ordinal):
                    hits.append(SparseHit(ordinal, scored.id, scored.score))
            return hits^
        for ordinal in self.visible_ordinals(layer):
            ref entry = table.entry_ref_at(ordinal)
            if not entry.has_sparse():
                continue
            var score = _sparse_dot(query, entry.sparse())
            if score and sparse_score_is_eligible(score.value()):
                hits.append(SparseHit(ordinal, entry.id, score.value()))
        return hits^

    def id_ordered_locations(self) raises -> List[Tuple[Int, Int]]:
        """Return (layer, slot) of every visible row in ascending ID order."""
        var ids = List[Int](capacity=self.visible_count)
        for layer in range(len(self.layers)):
            for ordinal in self.visible_ordinals(layer):
                ids.append(self.layers[layer].run[].memtable.id_at(ordinal))
        sort(Span(ids))
        var locations = List[Tuple[Int, Int]](capacity=len(ids))
        for id in ids:
            locations.append(self.find(id))
        return locations^

    def dense_run(self) raises -> ArcPointer[ReadRun]:
        """Return one run holding exactly the visible rows, for device upload.

        An unshadowed single run is shared. Otherwise this builds a flat table
        of descriptors that share dense owners and omit payload.
        """
        if len(self.layers) == 1 and not self.layers[0].is_shadowed():
            ref source = self.layers[0].run[].memtable
            if source.dense_live_count() == source.live_count():
                return self.layers[0].run.copy()
        var table = MemTable(self.config.dimension)
        for layer in range(len(self.layers)):
            ref source = self.layers[layer].run[].memtable
            for ordinal in self.visible_ordinals(layer):
                if source.entry_ref_at(ordinal).has_dense():
                    table.put(source.entry_ref_at(ordinal).dense_descriptor())
        table.last_sequence = self.sequence
        return ArcPointer(ReadRun(table^, Optional[ArcPointer[RunIndex]]()))


struct ReadPublisherStats(Copyable, Movable):
    """Cumulative publisher work; field owners are audited by identity.

    Payload and sparse bytes count only copies into derived run indexes.
    """

    var base_builds: Int
    var rollovers: Int
    var consolidations: Int
    var head_freezes: Int
    var descriptor_copies: Int
    var payload_bytes: Int
    var sparse_bytes: Int

    def __init__(out self):
        self.base_builds = 0
        self.rollovers = 0
        self.consolidations = 0
        self.head_freezes = 0
        self.descriptor_copies = 0
        self.payload_bytes = 0
        self.sparse_bytes = 0


struct SealedMerge(Movable):
    """A captured run prefix and the base merged from it.

    Capture and publish run under the writer lock; `build` does not. Runs are
    immutable once sealed, so the build reads them while writers continue.
    """

    var runs: List[ArcPointer[ReadRun]]
    """The base and sealed runs at capture, oldest first."""
    var base: Optional[ArcPointer[ReadRun]]
    var stats: ReadPublisherStats
    var delay_for_test: Float64
    var fail_for_test: Bool

    def __init__(
        out self,
        var runs: List[ArcPointer[ReadRun]],
        delay_for_test: Float64,
        fail_for_test: Bool,
    ):
        self.runs = runs^
        self.base = Optional[ArcPointer[ReadRun]]()
        self.stats = ReadPublisherStats()
        self.delay_for_test = delay_for_test
        self.fail_for_test = fail_for_test

    def build(mut self) raises:
        """Fold the runs, newest state winning, into one indexed base."""
        if self.delay_for_test > 0:
            sleep(self.delay_for_test)
        if self.fail_for_test:
            raise Error("sealed run merge failed for test")
        var table = self.runs[0][].memtable.clone()
        self.stats.descriptor_copies += table.slot_count()
        for index in range(1, len(self.runs)):
            ref source = self.runs[index][].memtable
            for slot in range(source.slot_count()):
                table.put(source.entry_ref_at(slot).clone())
            self.stats.descriptor_copies += source.slot_count()
        self.base = Optional(ArcPointer(_indexed_run(table^, self.stats)))


@fieldwise_init
struct CheckpointReadOwners(Movable):
    """Prepared descriptor replacements; index inputs and slots are unchanged."""

    var layers: List[ReadLayer]
    var head: Optional[MemTable]
    var descriptor_copies: Int


struct ReadOwnerPreparation(Movable):
    """Captured immutable runs, built from validated output without writer.

    Keep this owner through final publication and release it outside writer,
    including when the captured chain is stale or preparation fails.
    """

    var runs: List[ArcPointer[ReadRun]]
    var legacy_cutover: Optional[UInt64]
    var replacements: List[ArcPointer[ReadRun]]
    var descriptor_copies: Int
    var ready: Bool

    def __init__(out self, var runs: List[ArcPointer[ReadRun]], legacy_cutover: Optional[UInt64]):
        self.runs = runs^
        self.legacy_cutover = legacy_cutover
        self.replacements = List[ArcPointer[ReadRun]]()
        self.descriptor_copies = 0
        self.ready = False

    def build(mut self, entries: List[MemTableEntry]) raises:
        if self.ready or len(self.replacements) != 0:
            raise Error("read owner preparation already built")
        for run in self.runs:
            var table: Optional[MemTable]
            if self.legacy_cutover:
                var projected = _legacy_compaction_read_entries(run[].memtable, entries, self.legacy_cutover.value())
                table = _checkpoint_read_table(run[].memtable, projected)
            else:
                table = _checkpoint_read_table(run[].memtable, entries)
            if table:
                self.descriptor_copies += table.value().slot_count()
                self.replacements.append(ArcPointer(ReadRun(table.take(), run[].index.copy())))
            else:
                self.replacements.append(run)
        self.ready = True


@fieldwise_init
struct DetachedReadRuns(Movable):
    """Old publisher owners retained until the caller leaves its writer lock."""

    var root: Optional[ArcPointer[ReadGeneration]]
    var layers: List[ReadLayer]
    var head: Optional[MemTable]
    var frozen_head: Optional[ArcPointer[ReadRun]]


struct ReadGenerationCache(Movable):
    """Collection-local publisher, accessed only under the collection writer lock.

    It owns the base and sealed runs, the bounded mutable head and the cached
    root. Each committed write is recorded into the head as a point state;
    capture freezes a copy of only the head's descriptors. Existing read
    handles keep old roots alive.
    """

    var root: Optional[ArcPointer[ReadGeneration]]
    var generation: UInt64
    """Generation of the last published manifest; 0 before the first."""
    var revision: UInt64
    var stats: ReadPublisherStats
    var _layers: List[ReadLayer]
    var _head: Optional[MemTable]
    var _head_bytes: Int
    var _frozen_head: Optional[ArcPointer[ReadRun]]
    var _sequence: UInt64
    var merge_delay_for_test: Float64
    var merge_failure_for_test: Bool

    def __init__(out self):
        self.root = Optional[ArcPointer[ReadGeneration]]()
        self.generation = 0
        self.revision = 0
        self.stats = ReadPublisherStats()
        self._layers = List[ReadLayer]()
        self._head = Optional[MemTable]()
        self._head_bytes = 0
        self._frozen_head = Optional[ArcPointer[ReadRun]]()
        self._sequence = 0
        self.merge_delay_for_test = 0
        self.merge_failure_for_test = False

    def invalidate(mut self):
        """Drop the cached root after a publication; runs stay valid."""
        self.root = Optional[ArcPointer[ReadGeneration]]()

    def publish(mut self, generation: UInt64):
        """Record a durable manifest publication and drop the cached root."""
        self.generation = generation
        self.invalidate()

    def reset(mut self):
        """Drop all derived state; the next capture builds a new base."""
        self.invalidate()
        self._layers = List[ReadLayer]()
        self._head = Optional[MemTable]()
        self._head_bytes = 0
        self._frozen_head = Optional[ArcPointer[ReadRun]]()

    def stage_checkpoint_owners(self, entries: List[MemTableEntry]) raises -> CheckpointReadOwners:
        """Prepare same-version dense replacements before manifest commit.

        Runs already held by readers stay immutable. Payload/sparse owners,
        slots and shadow masks are unchanged, so their indexes remain valid.
        """
        var layers = List[ReadLayer](capacity=len(self._layers))
        var copies = 0
        for layer in self._layers:
            var next = layer.copy()
            var table = _checkpoint_read_table(layer.run[].memtable, entries)
            if table:
                copies += table.value().slot_count()
                next.run = ArcPointer(ReadRun(table.take(), layer.run[].index.copy()))
            layers.append(next^)
        var head = Optional[MemTable]()
        if self._head:
            head = _checkpoint_read_table(self._head.value(), entries)
            if head:
                copies += head.value().slot_count()
        return CheckpointReadOwners(layers^, head^, copies)

    def capture_checkpoint_owners(self, legacy_cutover: Optional[UInt64]) -> ReadOwnerPreparation:
        """Capture only shared immutable run owners under writer."""
        var runs = List[ArcPointer[ReadRun]](capacity=len(self._layers))
        for layer in self._layers:
            runs.append(layer.run)
        return ReadOwnerPreparation(runs^, legacy_cutover)

    def checkpoint_runs_match(self, prepared: ReadOwnerPreparation) -> Bool:
        if not prepared.ready or len(prepared.runs) != len(self._layers):
            return False
        for index in range(len(self._layers)):
            if not (self._layers[index].run is prepared.runs[index]):
                return False
        return True

    def stage_prepared_checkpoint_owners(
        self, prepared: ReadOwnerPreparation, projection: MemTable,
        owners: List[NumericOwnerReplacement],
    ) raises -> CheckpointReadOwners:
        """Use built immutable runs and stage only the current bounded head.

        Writes after capture can change the head and shadow masks. Retain those
        current masks rather than publishing a captured view of visibility.
        """
        if not self.checkpoint_runs_match(prepared):
            raise Error("prepared checkpoint read chain changed")
        var layers = List[ReadLayer](capacity=len(self._layers))
        for index in range(len(self._layers)):
            var layer = self._layers[index].copy()
            layer.run = prepared.replacements[index]
            layers.append(layer^)
        var head = Optional[MemTable]()
        var copies = prepared.descriptor_copies
        if self._head:
            var entries = projection._project_compaction_head(owners, self._head.value())
            head = _checkpoint_read_table(self._head.value(), entries)
            if head:
                copies += head.value().slot_count()
        return CheckpointReadOwners(layers^, head^, copies)

    def publish_checkpoint_owners(mut self, var owners: CheckpointReadOwners) -> DetachedReadRuns:
        """Exchange validated descriptors; return old owners for unlocked release."""
        var previous = DetachedReadRuns(self.root^, self._layers^, None, None)
        self.root = Optional[ArcPointer[ReadGeneration]]()
        self._layers = owners.layers^
        owners.layers = List[ReadLayer]()
        if owners.head:
            previous.head = self._head^
            self._head = Optional(owners.head.take())
            previous.frozen_head = self._frozen_head^
            self._frozen_head = Optional[ArcPointer[ReadRun]]()
        self.stats.descriptor_copies += owners.descriptor_copies
        return previous^

    def detach(mut self) -> DetachedReadRuns:
        var detached = DetachedReadRuns(
            self.root^, self._layers^, self._head^, self._frozen_head^
        )
        self.root = Optional[ArcPointer[ReadGeneration]]()
        self._layers = List[ReadLayer]()
        self._head = Optional[MemTable]()
        self._head_bytes = 0
        self._frozen_head = Optional[ArcPointer[ReadRun]]()
        return detached^

    def sealed_count(self) -> Int:
        return max(0, len(self._layers) - 1)

    def head_count(self) -> Int:
        return self._head.value().slot_count() if self._head else 0

    def record(mut self, memtable: MemTable, ids: List[Int], sequence: UInt64):
        """Record committed point states for IDs, after WAL and MemTable apply.

        `sequence` is the collection's accepted sequence after this write.

        Rollover happens here; merging the runs is the caller's job once
        `merge_due`. A failure after the commit cannot reject the write, so it
        drops derived state instead.
        """
        self.invalidate()
        if len(self._layers) == 0:
            return
        try:
            for id in ids:
                self._record_one(memtable, id)
            self._sequence = sequence
        except:
            self.reset()

    def merge_due(self) -> Bool:
        return self.sealed_count() >= MAX_SEALED_RUNS

    def capture_merge(self) -> SealedMerge:
        """Capture the base and every sealed run; the head stays mutable."""
        var runs = List[ArcPointer[ReadRun]](capacity=len(self._layers))
        for layer in self._layers:
            runs.append(layer.run)
        return SealedMerge(
            runs^, self.merge_delay_for_test, self.merge_failure_for_test
        )

    def publish_merge(mut self, var merge: SealedMerge) raises -> Bool:
        """Replace the merged prefix; later runs and the head are kept.

        False when the capture is stale: the publisher reset or rebuilt its
        base after the capture. Roots already published keep their chains.
        """
        var merged = len(merge.runs)
        if merged > len(self._layers) or not merge.base:
            return False
        for index in range(merged):
            if not (self._layers[index].run is merge.runs[index]):
                return False
        var base = merge.base.take()
        var hidden = List[Int]()
        for layer in range(merged, len(self._layers)):
            hidden.extend(
                _hidden_ordinals(base[].memtable, self._layers[layer].run[])
            )
        var layers = List[ReadLayer](capacity=len(self._layers) - merged + 1)
        layers.append(
            ReadLayer(
                base^, ArcPointer(_union(List[Int](), hidden^)), List[Int]()
            )
        )
        for layer in range(merged, len(self._layers)):
            layers.append(self._layers[layer].copy())
        self.invalidate()
        self._layers = layers^
        self.stats.descriptor_copies += merge.stats.descriptor_copies
        self.stats.payload_bytes += merge.stats.payload_bytes
        self.stats.sparse_bytes += merge.stats.sparse_bytes
        self.stats.consolidations += 1
        return True

    def merge_sealed_runs(mut self) raises:
        """Capture, build and publish in one step under the caller's lock."""
        var merge = self.capture_merge()
        merge.build()
        _ = self.publish_merge(merge^)

    def acquire(
        mut self,
        config: CollectionConfig,
        generation: UInt64,
        sequence: UInt64,
        memtable: MemTable,
        pins: ArcPointer[GenerationPinRegistry],
        var catalog: Optional[ArcPointer[FieldCatalog]] = None,
    ) raises -> ArcPointer[ReadGeneration]:
        if self.root:
            ref current = self.root.value()[]
            if (
                current.generation == generation
                and current.sequence == sequence
                and current.config.fingerprint() == config.fingerprint()
                and (Bool(current.catalog) == Bool(catalog))
                and (not catalog or current.catalog.value() is catalog.value())
            ):
                return self.root.value()
        if self.revision == UInt64.MAX:
            raise Error("read view revision exhausted")
        config.validate()
        if memtable.dimension != config.dimension:
            raise Error("snapshot dimension mismatch")
        if memtable.last_sequence > sequence:
            raise Error("snapshot sequence precedes memtable")
        if len(self._layers) == 0:
            self._build_base(memtable, sequence)
        elif self._sequence != sequence:
            raise Error("read publisher missed a committed write")
        var layers = List[ReadLayer](capacity=len(self._layers) + 1)
        for layer in self._layers:
            layers.append(layer.copy())
        if self.head_count() > 0:
            if not self._frozen_head:
                # Descriptors only; the head is evaluated without indexes.
                var table = self._head.value().clone()
                self.stats.descriptor_copies += table.slot_count()
                self._frozen_head = Optional(
                    ArcPointer(ReadRun(table^, Optional[ArcPointer[RunIndex]]()))
                )
                self.stats.head_freezes += 1
            var frozen = self._frozen_head.value()
            ref head = frozen[].memtable
            for layer in range(len(layers)):
                ref table = layers[layer].run[].memtable
                for slot in range(head.slot_count()):
                    var ordinal = table.ordinal_for(head.id_at(slot))
                    if ordinal >= 0:
                        layers[layer].head_hidden.append(ordinal)
                sort(Span(layers[layer].head_hidden))
            layers.append(
                ReadLayer(frozen^, ArcPointer(List[Int]()), List[Int]())
            )
        # The layered view resolves to exactly the writer's committed state.
        var visible = memtable.live_count()
        var root = ArcPointer(
            ReadGeneration(
                config,
                generation,
                sequence,
                self.revision + 1,
                layers^,
                visible,
                memtable.dense_live_count(),
                pins,
                catalog^,
            )
        )
        self.root = Optional(root)
        self.revision += 1
        return root^

    def _build_base(mut self, memtable: MemTable, sequence: UInt64) raises:
        var table = memtable.clone()
        self.stats.descriptor_copies += table.slot_count()
        var run = _indexed_run(table^, self.stats)
        self._layers = List[ReadLayer]()
        self._layers.append(
            ReadLayer(ArcPointer(run^), ArcPointer(List[Int]()), List[Int]())
        )
        self._head = Optional(MemTable(memtable.dimension))
        self._head_bytes = 0
        self._frozen_head = Optional[ArcPointer[ReadRun]]()
        self._sequence = sequence
        self.stats.base_builds += 1

    def _record_one(mut self, memtable: MemTable, id: Int) raises:
        var ordinal = memtable.ordinal_for(id)
        if ordinal < 0:
            raise Error("recorded ID is absent from the writer table")
        ref entry = memtable.entry_ref_at(ordinal)
        var incoming = _field_bytes(entry)
        var replaced = 0
        var existing = self._head.value().ordinal_for(id)
        if existing >= 0:
            replaced = _field_bytes(self._head.value().entry_ref_at(existing))
        var others = self.head_count() - (1 if existing >= 0 else 0)
        # A record that would overflow a non-empty head starts a new one, so a
        # legal oversized record gets its own run instead of a rejection.
        if (
            others > 0
            and self._head_bytes - replaced + incoming > HEAD_MAX_BYTES
        ):
            self._seal()
            replaced = 0
        # The frozen copy belongs to published roots; the next capture needs
        # a new one. The mutable head is never shared.
        self._frozen_head = Optional[ArcPointer[ReadRun]]()
        self._head.value().put(entry.clone())
        self._head_bytes += incoming - replaced
        self.stats.descriptor_copies += 1
        if (
            self.head_count() >= HEAD_MAX_POINTS
            or self._head_bytes >= HEAD_MAX_BYTES
        ):
            self._seal()

    def _seal(mut self) raises:
        """Move the head into a sealed run; only its indexes are built."""
        var table = self._head.take()
        self._head = Optional(MemTable(table.dimension))
        self._head_bytes = 0
        self._frozen_head = Optional[ArcPointer[ReadRun]]()
        var run = ArcPointer(_indexed_run(table^, self.stats))
        for layer in range(len(self._layers)):
            var added = _hidden_ordinals(
                self._layers[layer].run[].memtable, run[]
            )
            if len(added) == 0:
                continue
            # Replace the shared list; roots already published keep the old one.
            self._layers[layer].sealed_hidden = ArcPointer(
                _union(self._layers[layer].sealed_hidden[], added^)
            )
        self._layers.append(
            ReadLayer(run^, ArcPointer(List[Int]()), List[Int]())
        )
        self.stats.rollovers += 1


def _indexed_run(
    var table: MemTable, mut stats: ReadPublisherStats
) raises -> ReadRun:
    """Index one run's slots; field owners stay shared, not copied."""
    var metadata = MetadataIndex()
    var sparse = SparseIndex()
    metadata.begin_bulk()
    for ordinal in range(table.slot_count()):
        ref entry = table.entry_ref_at(ordinal)
        if entry.tombstone:
            metadata.delete(entry.id)
            continue
        stats.payload_bytes += entry.payload_bytes()
        var fields = clone_fields(entry.fields())
        metadata.upsert(entry.id, fields^)
        if entry.has_sparse() and len(entry.sparse()) > 0:
            stats.sparse_bytes += entry.sparse_bytes()
            sparse.upsert(entry.id, entry.sparse())
    metadata.finish_bulk()
    if metadata.slot_count() != table.slot_count():
        raise Error("snapshot metadata slot alignment failed")
    return ReadRun(table^, Optional(ArcPointer(RunIndex(metadata^, sparse^))))


def _legacy_compaction_read_entries(
    source: MemTable, entries: List[MemTableEntry], cutover: UInt64
) raises -> List[MemTableEntry]:
    """Project legacy dense owners onto matching immutable cutover versions.

    Legacy files have document versions, while migrated points are anchored at
    catalog cutover. Keep each run's sparse/payload owners and ignore later typed
    versions, just as the live authority does during final publication.
    """
    var projected = List[MemTableEntry]()
    for index in range(len(entries)):
        ref entry = entries[index]
        var slot = source.ordinal_for(entry.id)
        if slot < 0:
            continue
        ref current = source.entry_ref_at(slot)
        if current.sequence != cutover:
            continue
        if (
            current.document_sequence != entry.document_sequence
            or current.tombstone != entry.tombstone
            or current.has_dense() != entry.has_dense()
            or current.dense_bytes() != entry.dense_bytes()
        ):
            raise Error("legacy compaction read owner version mismatch")
        if not entry.has_dense():
            continue
        var next = current.clone()
        next._vectors[current.field_ordinal(0)] = entry.vector_at(entry.field_ordinal(0)).copy()
        projected.append(next^)
    return projected^


def _checkpoint_read_table(
    source: MemTable, entries: List[MemTableEntry]
) raises -> Optional[MemTable]:
    """Replace matching numeric versions while preserving slots and index inputs."""
    var table = Optional[MemTable]()
    for index in range(len(entries)):
        ref entry = entries[index]
        var ordinal = source.ordinal_for(entry.id)
        if ordinal < 0:
            continue
        ref current = source.entry_ref_at(ordinal)
        if current.sequence != entry.sequence:
            continue
        if (
            current.document_sequence != entry.document_sequence
            or current.tombstone != entry.tombstone
            or len(current._vectors) != len(entry._vectors)
        ):
            raise Error("checkpoint read owner version mismatch")
        var numeric = False
        for field in range(len(entry._vectors)):
            ref stored = entry._vectors[field]
            ref old = current._vectors[field]
            if (
                stored.id != old.id
                or stored.value().kind() != old.value().kind()
                or stored.value().scalar() != old.value().scalar()
                or stored.value().content_bytes() != old.value().content_bytes()
            ):
                raise Error("checkpoint read field mismatch")
            numeric = numeric or stored.value().kind() == 0 or stored.value().kind() == 2
        if not numeric:
            continue
        if not table:
            table = Optional(source.clone())
        for field in range(len(entry._vectors)):
            ref stored = entry._vectors[field]
            if stored.value().kind() == 0 or stored.value().kind() == 2:
                table.value()._entries[ordinal]._vectors[field] = stored.copy()
    return table^


def _hidden_ordinals(older: MemTable, newer: ReadRun) raises -> List[Int]:
    """Ordinals of `older` whose IDs have a state in the newer run."""
    ref table = newer.memtable
    var hidden = List[Int]()
    for slot in range(table.slot_count()):
        var ordinal = older.ordinal_for(table.id_at(slot))
        if ordinal >= 0:
            hidden.append(ordinal)
    return hidden^


def _union(existing: List[Int], var added: List[Int]) -> List[Int]:
    """Sorted, duplicate-free union of two ordinal lists."""
    added.extend(existing.copy())
    sort(Span(added))
    var unique = List[Int](capacity=len(added))
    for ordinal in added:
        if len(unique) == 0 or unique[len(unique) - 1] != ordinal:
            unique.append(ordinal)
    return unique^


def _field_bytes(entry: MemTableEntry) -> Int:
    return entry.content_bytes()


def _sparse_dot(
    query: List[SparseElement], elements: List[SparseElement]
) -> Optional[Float32]:
    """Merge two ascending term lists; None when no term is shared."""
    var score = Optional[Float32]()
    var position = 0
    for query_element in query:
        while (
            position < len(elements)
            and elements[position].term_id < query_element.term_id
        ):
            position += 1
        if position == len(elements):
            break
        if elements[position].term_id != query_element.term_id:
            continue
        var contribution = query_element.weight * elements[position].weight
        if score:
            score = Optional(score.value() + contribution)
        else:
            score = Optional(contribution)
    return score


def contains_sorted(values: List[Int], value: Int) -> Bool:
    var low = 0
    var high = len(values)
    while low < high:
        var middle = (low + high) // 2
        if values[middle] < value:
            low = middle + 1
        else:
            high = middle
    return low < len(values) and values[low] == value
