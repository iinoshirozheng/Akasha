from akasha.index.hnsw_core import HnswValidationStats, validate_bidirectional_links
from std.time import perf_counter_ns
from akasha.common.config import CollectionConfig, MetricKind, ScalarKind
from akasha.compute.quantization import (
    decode_bf16,
    decode_f16,
    encode_bf16,
    encode_f16,
    encode_symmetric_i8,
)
from akasha.index.hnsw import HnswIndex
from akasha.index.hnsw_entries import entries_from_legacy, encode_entries, decode_entries
from akasha.index.hnsw_view import HnswGraphView
from akasha.storage.checksum import (
    BinaryReader,
    BinaryReaderSource,
    BinaryWriter,
    crc32_range,
)
from akasha.storage.filesystem import read_file_bytes_bounded, sync_file
from akasha.storage.byte_sink import ByteSink, OwnedByteSink, FileByteSink, CheckedByteSink, drain_bytes, write_checksum
from akasha.storage.mapped_file import MappedFile
from akasha.storage.mapped_reader import MappedBinaryReader
from std.collections import Dict
from std.math import isfinite
from std.memory import bitcast
from std.sys.info import is_64bit, is_little_endian


struct HnswOpenStats(Copyable, Movable):
    var mapping_ns: Int
    var checksum_ns: Int
    var layout_ns: Int
    var validation_ns: Int
    var validation: HnswValidationStats

    def __init__(out self):
        self.mapping_ns = 0
        self.checksum_ns = 0
        self.layout_ns = 0
        self.validation_ns = 0
        self.validation = HnswValidationStats()


comptime HNSW_SNAPSHOT_VERSION = UInt16(1)
comptime HNSW_SNAPSHOT_V2_VERSION = UInt16(2)
comptime HNSW_SNAPSHOT_V3_VERSION = UInt16(3)
comptime HNSW_SNAPSHOT_V3_HEADER_BYTES = 192
comptime HNSW_SNAPSHOT_HEADER_BYTES = 160
comptime HNSW_SNAPSHOT_V2_HEADER_BYTES = 192
comptime HNSW_SNAPSHOT_NODE_BYTES = 40
comptime _CHECKSUM_BYTES = 4
comptime _MAX_SNAPSHOT_BYTES = 512 * 1024 * 1024
comptime _MAX_DECODE_ALLOCATION_BYTES = UInt64(512 * 1024 * 1024)
comptime _MAX_ALLOCATION_RATIO = UInt64(32)
comptime _MIN_ALLOCATION_BUDGET = UInt64(4_096)
comptime _SLOT_PEAK_BYTES = UInt64(128)
comptime _CURRENT_MAP_PEAK_BYTES = UInt64(192)
comptime _LEVEL_VALIDATION_PEAK_BYTES = UInt64(104)
comptime _EDGE_VALIDATION_PEAK_BYTES = UInt64(108)
comptime _MAX_SLOTS = 10_000_000
comptime _CURRENT_FLAG = UInt8(1)
comptime _DELETED_FLAG = UInt8(2)
comptime _REPLACED_FLAG = UInt8(4)
comptime _ENTRY_NONE = UInt64.MAX


struct HnswSnapshotInfo(Movable):
    """Metadata for one fully written and validated HNSW sidecar."""

    var version: UInt16
    var sequence: UInt64
    var config_fingerprint: UInt64
    var checksum: UInt32
    var slot_count: UInt64
    var live_point_count: UInt64
    var directed_edge_count: UInt64
    var byte_length: UInt64

    def __init__(
        out self,
        version: UInt16,
        sequence: UInt64,
        config_fingerprint: UInt64,
        checksum: UInt32,
        slot_count: UInt64,
        live_point_count: UInt64,
        directed_edge_count: UInt64,
        byte_length: UInt64,
    ):
        self.version = version
        self.sequence = sequence
        self.config_fingerprint = config_fingerprint
        self.checksum = checksum
        self.slot_count = slot_count
        self.live_point_count = live_point_count
        self.directed_edge_count = directed_edge_count
        self.byte_length = byte_length


struct HnswSnapshotEligibility(Movable):
    """Typed result of checking whether a graph has a sidecar representation."""

    var eligible: Bool
    var graph_usable: Bool
    var encoded_bytes: UInt64
    var reason: String

    def __init__(
        out self,
        eligible: Bool,
        graph_usable: Bool,
        encoded_bytes: UInt64,
        reason: String,
    ):
        self.eligible = eligible
        self.graph_usable = graph_usable
        self.encoded_bytes = encoded_bytes
        self.reason = String(copy=reason)


struct HnswMappedSnapshotLoad(Movable):
    """Typed mapped-sidecar compatibility result without string matching."""

    var status: Int
    var view: HnswGraphView

    def __init__(out self, status: Int, var view: HnswGraphView):
        self.status = status
        self.view = view^

    def hit(self) -> Bool:
        return self.status == 1

    def stale(self) -> Bool:
        return self.status == 0

    def mapping_failed(self) -> Bool:
        return self.status == 2

    def take_view(mut self) raises -> HnswGraphView:
        if not self.hit():
            raise Error("mapped HNSW load has no compatible view")
        var replacement = HnswGraphView()
        var result = self.view^
        self.view = replacement^
        return result^


struct _DecodedNodes(Movable):
    var ids: List[Int]
    var levels: List[Int]
    var flags: List[UInt8]
    var edge_counts: List[Int]
    var level_count: Int
    var directed_edge_count: Int
    var live_count: Int

    def __init__(out self, capacity: Int):
        self.ids = List[Int](capacity=capacity)
        self.levels = List[Int](capacity=capacity)
        self.flags = List[UInt8](capacity=capacity)
        self.edge_counts = List[Int](capacity=capacity)
        self.level_count = 0
        self.directed_edge_count = 0
        self.live_count = 0


struct HnswSnapshotEncoder[origin: ImmOrigin](Movable):
    """Validated borrowed graph plus small layout and entry buffers.

    The borrow prevents mutation between preflight and output. Validation and
    entries still have graph-dependent memory costs; encoded vector/edge tapes
    are never materialized by the file path.
    """

    var _index: Pointer[HnswIndex, Self.origin]
    var _header: List[UInt8]
    var _entries: List[UInt8]
    var byte_length: UInt64

    def __init__(out self, ref[Self.origin] index: HnswIndex, sequence: UInt64) raises:
        _require_snapshot_config(index.config)
        index.validate_structure()
        _validate_snapshot_graph_vectors(index)

        var slots = index.graph.slot_count()
        if slots > _MAX_SLOTS:
            raise Error("HNSW snapshot slot count exceeds implementation limit")
        var level_cells = UInt64(0)
        var directed_edges = UInt64(0)
        var allocated_neighbor_cells = UInt64(0)
        var live_points = UInt64(0)
        for slot_index in range(slots):
            var slot = UInt32(slot_index)
            level_cells = _checked_add_u64(
                level_cells, UInt64(index.graph.level(slot)) + UInt64(1)
            )
            allocated_neighbor_cells = _checked_add_u64(
                allocated_neighbor_cells,
                UInt64(index.graph.allocated_neighbor_slot_count(slot)),
            )
            if index.graph.is_current(slot):
                live_points += UInt64(1)
            for level in range(index.graph.level(slot) + 1):
                directed_edges = _checked_add_u64(
                    directed_edges,
                    UInt64(index.graph.neighbor_count(slot, level)),
                )

        var node_length = _checked_mul_u64(
            UInt64(slots), UInt64(HNSW_SNAPSHOT_NODE_BYTES)
        )
        var vector_scalars = _checked_mul_u64(
            UInt64(slots), UInt64(index.config.dimension)
        )
        var version = _snapshot_version(index.config.scalar_kind)
        var header_bytes = _snapshot_header_bytes(version)
        var vector_width = _snapshot_vector_width(index.config.scalar_kind)
        var scale_width = _snapshot_scale_width(
            index.config.ann_metric, index.config.scalar_kind
        )
        var vector_length = _checked_mul_u64(vector_scalars, UInt64(vector_width))
        var scale_length = _checked_mul_u64(UInt64(slots), UInt64(scale_width))
        var count_length = _checked_mul_u64(level_cells, UInt64(4))
        var edge_length = _checked_mul_u64(directed_edges, UInt64(4))
        var node_offset = UInt64(header_bytes)
        var vector_offset = _align8(_checked_add_u64(node_offset, node_length))
        var scale_offset = _align8(_checked_add_u64(vector_offset, vector_length))
        var count_offset = _align8(_checked_add_u64(scale_offset, scale_length))
        var edge_offset = _align8(_checked_add_u64(count_offset, count_length))
        var entries = encode_entries(index.entries)
        var entry_offset = _align8(_checked_add_u64(edge_offset, edge_length))
        var entry_length = UInt64(len(entries))
        var body_length = _checked_add_u64(entry_offset, entry_length)
        var file_length = _checked_add_u64(body_length, UInt64(_CHECKSUM_BYTES))
        _require_supported_file_length(file_length)
        _validate_decode_allocation(
            file_length,
            UInt64(slots),
            UInt64(index.config.dimension),
            level_cells,
            directed_edges,
            allocated_neighbor_cells,
        )

        var writer = BinaryWriter()
        _write_magic(writer)
        writer.write_u16(version)
        writer.write_u16(UInt16(0))
        writer.write_u32(UInt32(header_bytes))
        writer.write_u32(UInt32(0))
        writer.write_u64(index.config.fingerprint())
        writer.write_u64(sequence)
        writer.write_u32(UInt32(index.config.dimension))
        writer.write_u8(index.config.ann_metric.tag())
        writer.write_u8(index.config.scalar_kind.tag())
        writer.write_u16(UInt16(index.config.m))
        writer.write_u16(UInt16(index.config.m0))
        writer.write_u16(UInt16(index.config.max_level))
        writer.write_u32(UInt32(0))
        writer.write_u64(UInt64(slots))
        writer.write_u64(live_points)
        writer.write_u64(directed_edges)
        if Bool(index.entry_slot):
            writer.write_u64(UInt64(index.entry_slot.value()))
        else:
            writer.write_u64(_ENTRY_NONE)
        writer.write_i64(Int64(index.entry_level))
        writer.write_u64(node_offset)
        writer.write_u64(node_length)
        writer.write_u64(vector_offset)
        writer.write_u64(vector_length)
        writer.write_u64(count_offset)
        writer.write_u64(count_length)
        writer.write_u64(edge_offset)
        writer.write_u64(edge_length)
        if version == HNSW_SNAPSHOT_VERSION:
            writer.write_u64(UInt64(0))
        else:
            writer.write_u8(UInt8(vector_width))
            writer.write_u8(UInt8(scale_width))
            _write_zeros(writer, 6)
            writer.write_u64(scale_offset)
            writer.write_u64(scale_length)
            writer.write_u64(entry_offset)
            writer.write_u64(entry_length)
        self._index = Pointer(to=index)
        self._header = writer.take_bytes()
        self._entries = entries^
        self.byte_length = file_length

    def write_to(self, mut sink: Some[ByteSink]) raises -> UInt32:
        ref index = self._index[]
        var slots = index.graph.slot_count()
        var checked = CheckedByteSink(sink)
        checked.write(Span(self._header))
        var writer = BinaryWriter()
        var count_base = UInt64(0)
        var edge_base = UInt64(0)
        for slot_index in range(slots):
            var slot = UInt32(slot_index)
            var node_edge_count = UInt64(0)
            for level in range(index.graph.level(slot) + 1):
                node_edge_count = _checked_add_u64(
                    node_edge_count,
                    UInt64(index.graph.neighbor_count(slot, level)),
                )
            writer.write_i64(Int64(index.graph.id_at(slot)))
            writer.write_u16(UInt16(index.graph.level(slot)))
            writer.write_u8(_slot_flag(index, slot))
            writer.write_u8(UInt8(0))
            writer.write_u32(UInt32(0))
            writer.write_u64(count_base)
            writer.write_u64(edge_base)
            writer.write_u64(node_edge_count)
            count_base = _checked_add_u64(
                count_base, UInt64(index.graph.level(slot)) + UInt64(1)
            )
            edge_base = _checked_add_u64(edge_base, node_edge_count)
            _drain_snapshot_chunk(writer, checked)

        drain_bytes(writer, checked)
        _pad_snapshot_section(checked)
        if index.config.scalar_kind == ScalarKind.f32():
            comptime if is_little_endian():
                # Validation proves the entire native tape. Borrow its bytes for
                # synchronous CRC and output; no pointer escapes the graph borrow.
                ref values = index.graph.vector_scalars
                checked.write(Span(unsafe_ptr=values.unsafe_ptr().unsafe_bitcast[UInt8](), length=len(values) * 4))
            else:
                for value in index.graph.vector_scalars:
                    writer.write_f32(value)
                    _drain_snapshot_chunk(writer, checked)
        else:
            for slot_index in range(slots):
                var slot = UInt32(slot_index)
                var scale = _graph_i8_scale(index, slot)
                for component in range(index.config.dimension):
                    var value = index.graph.vector_value(slot, component)
                    if index.config.scalar_kind == ScalarKind.bf16():
                        writer.write_u16(encode_bf16(value))
                    elif index.config.scalar_kind == ScalarKind.f16():
                        writer.write_u16(encode_f16(value))
                    else:
                        writer.write_u8(
                            bitcast[DType.uint8](encode_symmetric_i8(value, scale))
                        )
                    _drain_snapshot_chunk(writer, checked)

        drain_bytes(writer, checked)
        _pad_snapshot_section(checked)
        if _snapshot_scale_width(index.config.ann_metric, index.config.scalar_kind) == 4:
            for slot_index in range(slots):
                writer.write_f32(_graph_i8_scale(index, UInt32(slot_index)))
                _drain_snapshot_chunk(writer, checked)

        drain_bytes(writer, checked)
        _pad_snapshot_section(checked)
        for slot_index in range(slots):
            var slot = UInt32(slot_index)
            for level in range(index.graph.level(slot) + 1):
                writer.write_u32(UInt32(index.graph.neighbor_count(slot, level)))
                _drain_snapshot_chunk(writer, checked)

        drain_bytes(writer, checked)
        _pad_snapshot_section(checked)
        for slot_index in range(slots):
            var slot = UInt32(slot_index)
            for level in range(index.graph.level(slot) + 1):
                for edge_index in range(index.graph.neighbor_count(slot, level)):
                    writer.write_u32(
                        index.graph.neighbor_at(slot, level, edge_index)
                    )
                    _drain_snapshot_chunk(writer, checked)

        drain_bytes(writer, checked)
        _pad_snapshot_section(checked)
        checked.write(Span(self._entries))
        if checked.byte_length != self.byte_length - UInt64(_CHECKSUM_BYTES):
            raise Error("HNSW snapshot encoder size mismatch")
        var checksum = ~checked.register
        write_checksum(sink, checksum)
        return checksum


def _drain_snapshot_chunk(mut writer: BinaryWriter, mut sink: Some[ByteSink]) raises:
    if writer.byte_length() >= 64 * 1024:
        drain_bytes(writer, sink)


def _pad_snapshot_section(mut sink: CheckedByteSink[_, _]) raises:
    var padding = Int(_align8(sink.byte_length) - sink.byte_length)
    if padding:
        var zeros = List[UInt8](length=padding, fill=0)
        sink.write(Span(zeros))


def encode_hnsw_snapshot(index: HnswIndex, sequence: UInt64) raises -> List[UInt8]:
    """Encode the same v3 byte stream into an exactly reserved owned buffer."""
    var encoder = HnswSnapshotEncoder(index, sequence)
    var sink = OwnedByteSink(Int(encoder.byte_length))
    _ = encoder.write_to(sink)
    return sink.take_bytes()


def hnsw_snapshot_max_bytes() -> UInt64:
    """Return the durable sidecar codec's maximum representable byte length."""
    return UInt64(_MAX_SNAPSHOT_BYTES)


def hnsw_snapshot_eligibility(
    index: HnswIndex, maximum_bytes: UInt64
) raises -> HnswSnapshotEligibility:
    """Preflight the selected sidecar version without encoding its payload."""
    if not is_64bit():
        return HnswSnapshotEligibility(False, False, 0, "unsupported_target")
    try:
        index.config.validate()
        index.validate_structure()
        _validate_snapshot_graph_vectors(index)
    except:
        return HnswSnapshotEligibility(False, False, 0, "invalid_graph")
    try:
        var slots = index.graph.slot_count()
        if slots > _MAX_SLOTS:
            return HnswSnapshotEligibility(False, True, 0, "slot_limit")
        var level_cells = UInt64(0)
        var directed_edges = UInt64(0)
        var allocated_neighbor_cells = UInt64(0)
        for slot_index in range(slots):
            var slot = UInt32(slot_index)
            level_cells = _checked_add_u64(
                level_cells, UInt64(index.graph.level(slot)) + UInt64(1)
            )
            allocated_neighbor_cells = _checked_add_u64(
                allocated_neighbor_cells,
                UInt64(index.graph.allocated_neighbor_slot_count(slot)),
            )
            for level in range(index.graph.level(slot) + 1):
                directed_edges = _checked_add_u64(
                    directed_edges,
                    UInt64(index.graph.neighbor_count(slot, level)),
                )
        var node_length = _checked_mul_u64(
            UInt64(slots), UInt64(HNSW_SNAPSHOT_NODE_BYTES)
        )
        var version = _snapshot_version(index.config.scalar_kind)
        var header_bytes = _snapshot_header_bytes(version)
        var vector_width = _snapshot_vector_width(index.config.scalar_kind)
        var scale_width = _snapshot_scale_width(
            index.config.ann_metric, index.config.scalar_kind
        )
        var vector_length = _checked_mul_u64(
            _checked_mul_u64(UInt64(slots), UInt64(index.config.dimension)),
            UInt64(vector_width),
        )
        var scale_length = _checked_mul_u64(UInt64(slots), UInt64(scale_width))
        var count_length = _checked_mul_u64(level_cells, UInt64(4))
        var edge_length = _checked_mul_u64(directed_edges, UInt64(4))
        var vector_offset = _align8(
            _checked_add_u64(UInt64(header_bytes), node_length)
        )
        var scale_offset = _align8(
            _checked_add_u64(vector_offset, vector_length)
        )
        var count_offset = _align8(_checked_add_u64(scale_offset, scale_length))
        var edge_offset = _align8(_checked_add_u64(count_offset, count_length))
        var entry_offset = _align8(_checked_add_u64(edge_offset, edge_length))
        var entry_length = _checked_add_u64(UInt64(16), _checked_mul_u64(
            UInt64(len(index.entries.primary) + len(index.entries.extra)), UInt64(8)))
        var file_length = _checked_add_u64(
            _checked_add_u64(entry_offset, entry_length), UInt64(_CHECKSUM_BYTES)
        )
        if (
            file_length > UInt64(_MAX_SNAPSHOT_BYTES)
            or file_length > UInt64(Int.MAX)
            or file_length > maximum_bytes
        ):
            return HnswSnapshotEligibility(
                False, True, file_length, "size_limit"
            )
        try:
            _validate_decode_allocation(
                file_length,
                UInt64(slots),
                UInt64(index.config.dimension),
                level_cells,
                directed_edges,
                allocated_neighbor_cells,
            )
        except:
            return HnswSnapshotEligibility(
                False, True, file_length, "allocation_limit"
            )
        return HnswSnapshotEligibility(True, True, file_length, "")
    except:
        return HnswSnapshotEligibility(False, True, 0, "codec_limit")


def decode_hnsw_snapshot_owned(
    var bytes: List[UInt8],
    config: CollectionConfig,
    sequence: UInt64,
) raises -> HnswIndex:
    """Fully validate and materialize one owned v1, v2 or v3 HNSW snapshot."""
    _require_snapshot_config(config)
    if len(bytes) < 8 + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if len(bytes) > _MAX_SNAPSHOT_BYTES:
        raise Error("HNSW snapshot exceeds implementation size limit")
    var checksum_offset = len(bytes) - _CHECKSUM_BYTES
    var stored_checksum = _read_u32_at(bytes, checksum_offset)
    if crc32_range(bytes, 0, checksum_offset) != stored_checksum:
        raise Error("HNSW snapshot checksum mismatch")

    var encoded_size = len(bytes)
    var reader = BinaryReader(bytes^)
    return _decode_hnsw_snapshot_reader(reader, encoded_size, config, sequence)


def decode_hnsw_snapshot_mapped(
    mapping: MappedFile, offset: Int, length: Int,
    config: CollectionConfig, sequence: UInt64,
) raises -> HnswIndex:
    """Materialize independent graph storage from a checked mapped range."""
    _require_snapshot_config(config)
    var reader = MappedBinaryReader(Pointer(to=mapping), offset, length)
    if length < 8 + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if length > _MAX_SNAPSHOT_BYTES:
        raise Error("HNSW snapshot exceeds implementation size limit")
    var checksum_offset = length - _CHECKSUM_BYTES
    var stored_checksum = mapping.load_scalars[DType.uint32, 1](
        offset + checksum_offset
    )
    if mapping.checksum(UInt64(offset), UInt64(checksum_offset)) != stored_checksum:
        raise Error("HNSW snapshot checksum mismatch")
    return _decode_hnsw_snapshot_reader(reader, length, config, sequence)


def _decode_hnsw_snapshot_reader[Reader: BinaryReaderSource](
    mut reader: Reader, encoded_size: Int,
    config: CollectionConfig, sequence: UInt64,
) raises -> HnswIndex:
    _read_magic(reader)
    var version = reader.read_u16()
    var header_bytes = _snapshot_header_bytes(version)
    if encoded_size < header_bytes + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if version == HNSW_SNAPSHOT_VERSION:
        _require_v1_config(config)
    elif version == HNSW_SNAPSHOT_V2_VERSION and config.scalar_kind == ScalarKind.f32():
        raise Error("HNSW snapshot v2 requires a compact scalar kind")
    if reader.read_u16() != UInt16(0):
        raise Error("unsupported HNSW snapshot flags")
    if reader.read_u32() != UInt32(header_bytes):
        raise Error("unsupported HNSW snapshot header size")
    if reader.read_u32() != UInt32(0):
        raise Error("nonzero HNSW snapshot reserved header bytes")
    if reader.read_u64() != config.fingerprint():
        raise Error("HNSW snapshot configuration fingerprint mismatch")
    if reader.read_u64() != sequence:
        raise Error("HNSW snapshot sequence mismatch")
    if reader.read_u32() != UInt32(config.dimension):
        raise Error("HNSW snapshot dimension mismatch")
    if reader.read_u8() != config.ann_metric.tag():
        raise Error("HNSW snapshot metric mismatch")
    if reader.read_u8() != config.scalar_kind.tag():
        raise Error("HNSW snapshot scalar kind mismatch")
    if (
        reader.read_u16() != UInt16(config.m)
        or reader.read_u16() != UInt16(config.m0)
        or reader.read_u16() != UInt16(config.max_level)
    ):
        raise Error("HNSW snapshot graph configuration mismatch")
    if reader.read_u32() != UInt32(0):
        raise Error("nonzero HNSW snapshot reserved config bytes")

    var slot_count_u64 = reader.read_u64()
    var live_count_u64 = reader.read_u64()
    var directed_edges_u64 = reader.read_u64()
    var entry_slot_u64 = reader.read_u64()
    var entry_level_i64 = reader.read_i64()
    var node_offset = reader.read_u64()
    var node_length = reader.read_u64()
    var vector_offset = reader.read_u64()
    var vector_length = reader.read_u64()
    var count_offset = reader.read_u64()
    var count_length = reader.read_u64()
    var edge_offset = reader.read_u64()
    var edge_length = reader.read_u64()
    var vector_width = 4
    var scale_width = 0
    var scale_offset = count_offset
    var scale_length = UInt64(0)
    var entry_offset = UInt64(0)
    var entry_length = UInt64(0)
    if version == HNSW_SNAPSHOT_VERSION:
        if reader.read_u64() != UInt64(0):
            raise Error("nonzero HNSW snapshot reserved extension bytes")
    else:
        vector_width = Int(reader.read_u8())
        scale_width = Int(reader.read_u8())
        for _ in range(6):
            if reader.read_u8() != UInt8(0):
                raise Error("nonzero HNSW snapshot reserved extension bytes")
        scale_offset = reader.read_u64()
        scale_length = reader.read_u64()
        entry_offset = reader.read_u64()
        entry_length = reader.read_u64()
        if version < HNSW_SNAPSHOT_V3_VERSION and (entry_offset != 0 or entry_length != 0):
            raise Error("nonzero HNSW snapshot reserved extension bytes")
        if vector_width != _snapshot_vector_width(config.scalar_kind):
            raise Error("HNSW snapshot scalar width mismatch")
        if scale_width != _snapshot_scale_width(
            config.ann_metric, config.scalar_kind
        ):
            raise Error("HNSW snapshot scale width mismatch")
    if reader.position() != header_bytes:
        raise Error("HNSW snapshot header decoder size mismatch")

    var slots = _bounded_count(slot_count_u64, _MAX_SLOTS, "slot")
    if live_count_u64 > slot_count_u64:
        raise Error("HNSW snapshot live count exceeds slot count")
    var live_count = _bounded_count(live_count_u64, slots, "live point")
    var directed_edges = _bounded_count(
        directed_edges_u64, Int.MAX, "directed edge"
    )
    if count_length % UInt64(4) != UInt64(0):
        raise Error("HNSW snapshot count section length is invalid")
    var level_count = _bounded_count(
        count_length // UInt64(4), Int.MAX, "level count"
    )
    # This lower-bound peak check deliberately precedes all attacker-sized
    # node lists and dictionaries. It assumes every slot may be current because
    # the encoded live count is not trusted until the node scan completes.
    _validate_hnsw_snapshot_header_allocation(
        UInt64(encoded_size),
        slot_count_u64,
        UInt64(config.dimension),
        UInt64(level_count),
        directed_edges_u64,
        UInt64(config.m0),
    )
    if version == HNSW_SNAPSHOT_V3_VERSION and entry_offset == 0:
        raise Error("HNSW v3 snapshot is missing entry section")
    _validate_section_layout(
        UInt64(encoded_size),
        slot_count_u64,
        UInt64(config.dimension),
        directed_edges_u64,
        node_offset,
        node_length,
        vector_offset,
        vector_length,
        count_offset,
        count_length,
        edge_offset,
        edge_length,
        header_bytes,
        vector_width,
        scale_offset,
        scale_length,
        scale_width,
        entry_offset,
        entry_length,
    )

    var nodes = _DecodedNodes(slots)
    var allocated_neighbor_cells = UInt64(0)
    var seen_current_ids = Dict[Int, Bool]()
    for _ in range(slots):
        var id = Int(reader.read_i64())
        var level = Int(reader.read_u16())
        var flag = reader.read_u8()
        if reader.read_u8() != UInt8(0) or reader.read_u32() != UInt32(0):
            raise Error("nonzero HNSW snapshot node reserved bytes")
        if level < 0 or level > config.max_level:
            raise Error("HNSW snapshot node level is invalid")
        allocated_neighbor_cells = _checked_add_u64(
            allocated_neighbor_cells,
            _checked_add_u64(
                UInt64(config.m0),
                _checked_mul_u64(UInt64(level), UInt64(config.m)),
            ),
        )
        if (
            flag != _CURRENT_FLAG
            and flag != _DELETED_FLAG
            and flag != _REPLACED_FLAG
        ):
            raise Error("HNSW snapshot node lifecycle flags are invalid")
        var count_base = reader.read_u64()
        var edge_base = reader.read_u64()
        var node_edges_u64 = reader.read_u64()
        if count_base != UInt64(nodes.level_count):
            raise Error("HNSW snapshot node count offsets are not packed")
        if edge_base != UInt64(nodes.directed_edge_count):
            raise Error("HNSW snapshot node edge offsets are not packed")
        if node_edges_u64 > directed_edges_u64 - UInt64(
            nodes.directed_edge_count
        ):
            raise Error("HNSW snapshot node edge range exceeds section")
        var node_edges = _bounded_count(
            node_edges_u64, directed_edges, "node edge"
        )
        if level + 1 > level_count - nodes.level_count:
            raise Error("HNSW snapshot node count range exceeds section")
        nodes.level_count += level + 1
        nodes.directed_edge_count += node_edges
        if flag == _CURRENT_FLAG:
            if id in seen_current_ids:
                raise Error("HNSW snapshot current public IDs must be unique")
            seen_current_ids[id] = True
            nodes.live_count += 1
        nodes.ids.append(id)
        nodes.levels.append(level)
        nodes.flags.append(flag)
        nodes.edge_counts.append(node_edges)
    if nodes.level_count != level_count:
        raise Error("HNSW snapshot level count does not match nodes")
    if nodes.directed_edge_count != directed_edges:
        raise Error("HNSW snapshot edge count does not match nodes")
    if nodes.live_count != live_count:
        raise Error("HNSW snapshot live count does not match node flags")
    _validate_decode_allocation(
        UInt64(encoded_size),
        slot_count_u64,
        UInt64(config.dimension),
        UInt64(level_count),
        directed_edges_u64,
        allocated_neighbor_cells,
    )

    var index = HnswIndex(config)
    _read_zero_padding(reader, Int(vector_offset - (node_offset + node_length)))
    var scalar_count = _bounded_count(
        _checked_mul_u64(slot_count_u64, UInt64(config.dimension)),
        Int.MAX,
        "vector scalar",
    )
    # Decode each validated row into its final graph tape. A complete promoted
    # F32 tape would duplicate F32 storage and inflate compact scalar snapshots.
    if config.scalar_kind == ScalarKind.f32():
        index.graph.vector_scalars.reserve(scalar_count)
    else:
        index.graph.vector_bytes.reserve(Int(vector_length))
        if scale_width == 4:
            index.graph.vector_scales.reserve(slots)
    var vector_codes = List[Int8](
        capacity=(
            slots * config.dimension if config.scalar_kind
            == ScalarKind.i8() else 0
        )
    )
    for slot_index in range(slots):
        var prepared = List[Float32]()
        if config.scalar_kind == ScalarKind.f32():
            prepared = reader.read_f32s(config.dimension)
        else:
            prepared.reserve(config.dimension)
            for _ in range(config.dimension):
                if config.scalar_kind == ScalarKind.bf16():
                    prepared.append(decode_bf16(reader.read_u16()))
                elif config.scalar_kind == ScalarKind.f16():
                    prepared.append(decode_f16(reader.read_u16()))
                else:
                    vector_codes.append(bitcast[DType.int8](reader.read_u8()))
        if config.scalar_kind != ScalarKind.i8():
            index.metric.validate_prepared_vector(prepared)
            if version < HNSW_SNAPSHOT_V3_VERSION:
                index.metric.validate_legacy_cosine_prepared(prepared)
            _restore_owned_snapshot_slot(index, nodes, slot_index, prepared^)

    _read_zero_padding(
        reader, Int(scale_offset - (vector_offset + vector_length))
    )
    var vector_scales = List[Float32](
        capacity=(slots if scale_width == 4 else 0)
    )
    if scale_width == 4:
        for _ in range(slots):
            var scale = bitcast[DType.float32](reader.read_u32())
            if not isfinite(scale) or scale < 0.0:
                raise Error("HNSW snapshot I8 scale is invalid")
            vector_scales.append(scale)
    if config.scalar_kind == ScalarKind.i8():
        var code_index = 0
        for slot_index in range(slots):
            var prepared = List[Float32](capacity=config.dimension + 1)
            for _ in range(config.dimension):
                var code = vector_codes[code_index]
                code_index += 1
                prepared.append(Float32(code))
            var scale = Float32(1.0 / 127.0)
            if scale_width == 4:
                scale = vector_scales[slot_index]
            prepared.append(scale)
            index.metric.validate_prepared_vector(prepared)
            if version < HNSW_SNAPSHOT_V3_VERSION:
                index.metric.validate_legacy_cosine_prepared(prepared)
            _restore_owned_snapshot_slot(index, nodes, slot_index, prepared^)

    _read_zero_padding(
        reader, Int(count_offset - (scale_offset + scale_length))
    )
    var level_edge_counts = List[Int](capacity=level_count)
    var total_edges_from_counts = 0
    var count_index = 0
    for slot_index in range(slots):
        var node_sum = 0
        for level in range(nodes.levels[slot_index] + 1):
            var count_u32 = reader.read_u32()
            var capacity = config.m if level > 0 else config.m0
            if version < HNSW_SNAPSHOT_V3_VERSION and UInt64(count_u32) > UInt64(capacity):
                raise Error("HNSW snapshot neighbor count exceeds capacity")
            var count = Int(count_u32)
            if count >= slots:
                raise Error("HNSW snapshot neighbor count exceeds graph slots")
            if count > capacity:
                allocated_neighbor_cells = _checked_add_u64(allocated_neighbor_cells, UInt64(count - capacity))
            if count > directed_edges - total_edges_from_counts:
                raise Error("HNSW snapshot neighbor counts exceed edge section")
            node_sum += count
            total_edges_from_counts += count
            level_edge_counts.append(count)
            count_index += 1
        if node_sum != nodes.edge_counts[slot_index]:
            raise Error("HNSW snapshot node edge count is inconsistent")
    if count_index != level_count or total_edges_from_counts != directed_edges:
        raise Error("HNSW snapshot neighbor counts are inconsistent")

    _read_zero_padding(reader, Int(edge_offset - (count_offset + count_length)))
    var edge_slots = List[UInt32](capacity=directed_edges)
    var edge_index = 0
    var level_index = 0
    for source_index in range(slots):
        for level in range(nodes.levels[source_index] + 1):
            var seen_neighbors = Dict[Int, Bool]()
            var count = level_edge_counts[level_index]
            level_index += 1
            for _ in range(count):
                var neighbor = reader.read_u32()
                if UInt64(neighbor) >= slot_count_u64:
                    raise Error("HNSW snapshot neighbor ordinal is invalid")
                if Int(neighbor) == source_index:
                    raise Error("HNSW snapshot self edges are not allowed")
                if nodes.levels[Int(neighbor)] < level:
                    raise Error("HNSW snapshot edge target lacks graph level")
                var key = Int(neighbor)
                if key in seen_neighbors:
                    raise Error("HNSW snapshot neighbor list has a duplicate")
                seen_neighbors[key] = True
                edge_slots.append(neighbor)
                edge_index += 1
    if edge_index != directed_edges:
        raise Error("HNSW snapshot edge section length is inconsistent")
    var entry_bytes = List[UInt8]()
    if version == HNSW_SNAPSHOT_V3_VERSION:
        _read_zero_padding(reader, Int(entry_offset - (edge_offset + edge_length)))
        entry_bytes = reader.read_bytes(Int(entry_length))
    _ = reader.read_u32()
    if reader.remaining() != 0:
        raise Error("HNSW snapshot has trailing bytes")

    var entry_level = Int(entry_level_i64)
    if slots == 0:
        if (
            entry_slot_u64 != _ENTRY_NONE
            or entry_level != -1
            or live_count != 0
        ):
            raise Error("empty HNSW snapshot entry point is invalid")
    elif (
        entry_slot_u64 >= slot_count_u64
        or entry_level < 0
        or entry_level != nodes.levels[Int(entry_slot_u64)]
    ):
        raise Error("HNSW snapshot entry point is invalid")

    _validate_decode_allocation(UInt64(encoded_size), slot_count_u64,
        UInt64(config.dimension), UInt64(level_count), directed_edges_u64,
        allocated_neighbor_cells)
    index.graph.replace_all_links(level_edge_counts, edge_slots)

    if slots > 0:
        index.entry_slot = Optional(UInt32(entry_slot_u64))
        index.entry_level = entry_level
    index.build_stats.slot_count = slots
    index.build_stats.inactive_slots = slots - nodes.live_count
    index.build_stats.maximum_level = entry_level
    index.build_stats.directed_edges = directed_edges
    index.build_stats.serialized_bytes = encoded_size
    if version == HNSW_SNAPSHOT_V3_VERSION:
        index.entries = decode_entries(entry_bytes^, index.graph)
    else:
        index.entries = entries_from_legacy(index.graph, index.entry_slot)
    index.validate_structure()
    if version < HNSW_SNAPSHOT_V3_VERSION:
        validate_bidirectional_links(index.graph)
    return index^


def _restore_owned_snapshot_slot(
    mut index: HnswIndex,
    nodes: _DecodedNodes,
    slot_index: Int,
    var vector: List[Float32],
) raises:
    var slot = index.graph.append(
        nodes.ids[slot_index], vector^, nodes.levels[slot_index]
    )
    if Int(slot) != slot_index:
        raise Error("HNSW snapshot slot materialization is inconsistent")
    if nodes.flags[slot_index] == _DELETED_FLAG:
        if not index.graph.mark_deleted(nodes.ids[slot_index]):
            raise Error("HNSW snapshot deleted slot is inconsistent")
    elif nodes.flags[slot_index] == _REPLACED_FLAG:
        _ = index.graph.mark_replaced(nodes.ids[slot_index])


def write_hnsw_snapshot(
    path: String, index: HnswIndex, sequence: UInt64
) raises -> HnswSnapshotInfo:
    """Synchronously write one sidecar and return its manifest metadata."""
    # Complete validation before opening/truncating a sidecar pathname.
    var encoder = HnswSnapshotEncoder(index, sequence)
    var checksum: UInt32
    with open(path, "w") as file:
        var sink = FileByteSink(file)
        checksum = encoder.write_to(sink)
        sync_file(file)
    return HnswSnapshotInfo(
        _snapshot_version(index.config.scalar_kind),
        sequence,
        index.config.fingerprint(),
        checksum,
        UInt64(index.graph.slot_count()),
        UInt64(index.graph.slot_count() - index.inactive_count()),
        _count_directed_edges(index),
        encoder.byte_length,
    )


def read_hnsw_snapshot_owned(
    path: String, config: CollectionConfig, sequence: UInt64
) raises -> HnswIndex:
    """Read and fully validate one sidecar into independent owned storage."""
    return decode_hnsw_snapshot_owned(
        read_file_bytes_bounded(path, _MAX_SNAPSHOT_BYTES), config, sequence
    )


def open_hnsw_snapshot_view(
    path: String, config: CollectionConfig, sequence: UInt64
) raises -> HnswGraphView:
    """Map, completely validate, and return one immutable graph view."""
    var stats = HnswOpenStats()
    return open_hnsw_snapshot_view_with_stats(path, config, sequence, stats)


def open_hnsw_snapshot_view_with_stats(
    path: String,
    config: CollectionConfig,
    sequence: UInt64,
    mut stats: HnswOpenStats,
) raises -> HnswGraphView:
    _require_snapshot_config(config)
    stats = HnswOpenStats()
    var started = perf_counter_ns()
    var mapping = MappedFile.open_readonly(path)
    stats.mapping_ns = perf_counter_ns() - started
    return _open_hnsw_snapshot_view_from_mapping(
        mapping^, config, sequence, False, stats
    )


def try_open_compatible_hnsw_snapshot_view(
    path: String,
    config: CollectionConfig,
    sequence: UInt64,
    manifest_checksum: UInt32,
    manifest_live_point_count: UInt64,
) raises -> HnswMappedSnapshotLoad:
    """Map once, classify stale metadata, then validate that same mapping.

    Only acquisition failures produce ``mapping_failed``. Once a mapped file
    has the manifest's checksum identity, checksum or layout corruption raises
    and must never be mistaken for a recoverable stale acceleration artifact.
    """
    _require_snapshot_config(config)
    var mapping: MappedFile
    try:
        mapping = MappedFile.open_readonly(path)
    except:
        return HnswMappedSnapshotLoad(2, HnswGraphView())
    var encoded_size = mapping.byte_length()
    if encoded_size < _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if encoded_size > _MAX_SNAPSHOT_BYTES:
        raise Error("HNSW snapshot exceeds implementation size limit")
    var checksum_offset = encoded_size - _CHECKSUM_BYTES
    var stored_checksum = _mapped_u32(mapping, checksum_offset)
    if stored_checksum != manifest_checksum:
        return HnswMappedSnapshotLoad(0, HnswGraphView())
    if encoded_size < 8 + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if mapping.checksum(0, UInt64(checksum_offset)) != stored_checksum:
        raise Error("HNSW snapshot checksum mismatch")
    if not _mapped_hnsw_snapshot_identity_matches(
        mapping, config, sequence, manifest_live_point_count
    ):
        return HnswMappedSnapshotLoad(0, HnswGraphView())
    var stats = HnswOpenStats()
    var view = _open_hnsw_snapshot_view_from_mapping(
        mapping^, config, sequence, True, stats
    )
    return HnswMappedSnapshotLoad(1, view^)


def _open_hnsw_snapshot_view_from_mapping(
    var mapping: MappedFile,
    config: CollectionConfig,
    sequence: UInt64,
    checksum_already_validated: Bool,
    mut stats: HnswOpenStats,
) raises -> HnswGraphView:
    var encoded_size = mapping.byte_length()
    if encoded_size < 8 + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if encoded_size > _MAX_SNAPSHOT_BYTES:
        raise Error("HNSW snapshot exceeds implementation size limit")

    var started = perf_counter_ns()
    var checksum_offset = encoded_size - _CHECKSUM_BYTES
    var stored_checksum = _mapped_u32(mapping, checksum_offset)
    if not checksum_already_validated:
        if mapping.checksum(0, UInt64(checksum_offset)) != stored_checksum:
            raise Error("HNSW snapshot checksum mismatch")

    stats.checksum_ns = perf_counter_ns() - started
    started = perf_counter_ns()

    if (
        mapping.byte_at(0) != UInt8(0x41)
        or mapping.byte_at(1) != UInt8(0x4B)
        or mapping.byte_at(2) != UInt8(0x48)
        or mapping.byte_at(3) != UInt8(0x47)
    ):
        raise Error("invalid HNSW snapshot magic")
    var version = _mapped_u16(mapping, 4)
    var header_bytes = _snapshot_header_bytes(version)
    if encoded_size < header_bytes + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if version == HNSW_SNAPSHOT_VERSION:
        _require_v1_config(config)
    elif version == HNSW_SNAPSHOT_V2_VERSION and config.scalar_kind == ScalarKind.f32():
        raise Error("HNSW snapshot v2 requires a compact scalar kind")
    if _mapped_u16(mapping, 6) != UInt16(0):
        raise Error("unsupported HNSW snapshot flags")
    if _mapped_u32(mapping, 8) != UInt32(header_bytes):
        raise Error("unsupported HNSW snapshot header size")
    if _mapped_u32(mapping, 12) != UInt32(0):
        raise Error("nonzero HNSW snapshot reserved header bytes")
    if _mapped_u64(mapping, 16) != config.fingerprint():
        raise Error("HNSW snapshot configuration fingerprint mismatch")
    if _mapped_u64(mapping, 24) != sequence:
        raise Error("HNSW snapshot sequence mismatch")
    if _mapped_u32(mapping, 32) != UInt32(config.dimension):
        raise Error("HNSW snapshot dimension mismatch")
    if mapping.byte_at(36) != config.ann_metric.tag():
        raise Error("HNSW snapshot metric mismatch")
    if mapping.byte_at(37) != config.scalar_kind.tag():
        raise Error("HNSW snapshot scalar kind mismatch")
    if (
        _mapped_u16(mapping, 38) != UInt16(config.m)
        or _mapped_u16(mapping, 40) != UInt16(config.m0)
        or _mapped_u16(mapping, 42) != UInt16(config.max_level)
    ):
        raise Error("HNSW snapshot graph configuration mismatch")
    if _mapped_u32(mapping, 44) != UInt32(0):
        raise Error("nonzero HNSW snapshot reserved config bytes")
    var slot_count_u64 = _mapped_u64(mapping, 48)
    var live_count_u64 = _mapped_u64(mapping, 56)
    var directed_edges_u64 = _mapped_u64(mapping, 64)
    var entry_slot_u64 = _mapped_u64(mapping, 72)
    var entry_level = Int(bitcast[DType.int64](_mapped_u64(mapping, 80)))
    var node_offset = _mapped_u64(mapping, 88)
    var node_length = _mapped_u64(mapping, 96)
    var vector_offset = _mapped_u64(mapping, 104)
    var vector_length = _mapped_u64(mapping, 112)
    var count_offset = _mapped_u64(mapping, 120)
    var count_length = _mapped_u64(mapping, 128)
    var edge_offset = _mapped_u64(mapping, 136)
    var edge_length = _mapped_u64(mapping, 144)
    var vector_width = 4
    var scale_width = 0
    var scale_offset = count_offset
    var scale_length = UInt64(0)
    var entry_offset = UInt64(0)
    var entry_length = UInt64(0)
    if version == HNSW_SNAPSHOT_VERSION:
        if _mapped_u64(mapping, 152) != UInt64(0):
            raise Error("nonzero HNSW snapshot reserved extension bytes")
    else:
        vector_width = Int(mapping.byte_at(152))
        scale_width = Int(mapping.byte_at(153))
        for offset in range(154, 160):
            if mapping.byte_at(offset) != UInt8(0):
                raise Error("nonzero HNSW snapshot reserved extension bytes")
        scale_offset = _mapped_u64(mapping, 160)
        scale_length = _mapped_u64(mapping, 168)
        entry_offset = _mapped_u64(mapping, 176)
        entry_length = _mapped_u64(mapping, 184)
        if version < HNSW_SNAPSHOT_V3_VERSION and (entry_offset != 0 or entry_length != 0):
            raise Error("nonzero HNSW snapshot reserved extension bytes")
        if vector_width != _snapshot_vector_width(config.scalar_kind):
            raise Error("HNSW snapshot scalar width mismatch")
        if scale_width != _snapshot_scale_width(
            config.ann_metric, config.scalar_kind
        ):
            raise Error("HNSW snapshot scale width mismatch")

    var slots = _bounded_count(slot_count_u64, _MAX_SLOTS, "slot")
    if live_count_u64 > slot_count_u64:
        raise Error("HNSW snapshot live count exceeds slot count")
    var live_points = _bounded_count(live_count_u64, slots, "live point")
    var directed_edges = _bounded_count(
        directed_edges_u64, Int.MAX, "directed edge"
    )
    if count_length % UInt64(4) != UInt64(0):
        raise Error("HNSW snapshot count section length is invalid")
    var level_count = _bounded_count(
        count_length // UInt64(4), Int.MAX, "level count"
    )
    _validate_hnsw_snapshot_header_allocation(
        UInt64(encoded_size),
        slot_count_u64,
        UInt64(config.dimension),
        UInt64(level_count),
        directed_edges_u64,
        UInt64(config.m0),
    )
    if version == HNSW_SNAPSHOT_V3_VERSION and entry_offset == 0:
        raise Error("HNSW v3 snapshot is missing entry section")
    _validate_section_layout(
        UInt64(encoded_size),
        slot_count_u64,
        UInt64(config.dimension),
        directed_edges_u64,
        node_offset,
        node_length,
        vector_offset,
        vector_length,
        count_offset,
        count_length,
        edge_offset,
        edge_length,
        header_bytes,
        vector_width,
        scale_offset,
        scale_length,
        scale_width,
        entry_offset,
        entry_length,
    )
    _validate_mapped_zero_padding(
        mapping, node_offset + node_length, vector_offset
    )
    _validate_mapped_zero_padding(
        mapping, vector_offset + vector_length, scale_offset
    )
    _validate_mapped_zero_padding(
        mapping, scale_offset + scale_length, count_offset
    )
    _validate_mapped_zero_padding(
        mapping, count_offset + count_length, edge_offset
    )

    var optional_entry = Optional[UInt32]()
    if slots == 0:
        if entry_slot_u64 != _ENTRY_NONE or entry_level != -1:
            raise Error("empty HNSW snapshot entry point is invalid")
    else:
        if entry_slot_u64 >= slot_count_u64:
            raise Error("HNSW snapshot entry point is invalid")
        optional_entry = Optional(UInt32(entry_slot_u64))

    var view = HnswGraphView._from_validated_mapping(
        mapping^,
        config,
        slots,
        live_points,
        level_count,
        directed_edges,
        optional_entry,
        entry_level,
        Int(node_offset),
        Int(vector_offset),
        vector_width,
        Int(scale_offset),
        scale_width,
        Int(count_offset),
        Int(edge_offset),
        version < HNSW_SNAPSHOT_V3_VERSION,
    )
    stats.layout_ns = perf_counter_ns() - started
    started = perf_counter_ns()
    if version == HNSW_SNAPSHOT_V3_VERSION:
        view.validate_entry_padding(Int(edge_offset + edge_length), Int(entry_offset))
        view.load_entries(Int(entry_offset), Int(entry_length))
    else:
        view.entries = entries_from_legacy(view, optional_entry)
    view.validate_structure_with_stats(stats.validation)
    stats.validation_ns = perf_counter_ns() - started
    return view^


def try_read_compatible_hnsw_snapshot_owned(
    path: String,
    config: CollectionConfig,
    sequence: UInt64,
    manifest_checksum: UInt32,
    manifest_live_point_count: UInt64,
) raises -> Optional[HnswIndex]:
    """Return an owned compatible sidecar or `None` for stale metadata.

    The manifest checksum is compared with the bounded trailer first. Only a
    file matching that committed identity receives CRC and layout validation.
    """
    var bytes = read_file_bytes_bounded(path, _MAX_SNAPSHOT_BYTES)
    if len(bytes) < _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    var checksum_offset = len(bytes) - _CHECKSUM_BYTES
    var stored_checksum = _read_u32_at(bytes, checksum_offset)
    if stored_checksum != manifest_checksum:
        return Optional[HnswIndex]()
    if crc32_range(bytes, 0, checksum_offset) != stored_checksum:
        raise Error("HNSW snapshot checksum mismatch")
    _require_snapshot_config(config)
    if len(bytes) < 8 + _CHECKSUM_BYTES:
        raise Error("HNSW snapshot is truncated")
    if not hnsw_snapshot_identity_matches(
        bytes, config, sequence, manifest_live_point_count
    ):
        return Optional[HnswIndex]()

    var decoded = decode_hnsw_snapshot_owned(bytes^, config, sequence)
    return Optional(decoded^)


def hnsw_snapshot_identity_matches(
    bytes: List[UInt8],
    config: CollectionConfig,
    sequence: UInt64,
    live_point_count: UInt64,
) -> Bool:
    """Compare only fixed identity fields without copying the snapshot."""
    if len(bytes) < HNSW_SNAPSHOT_HEADER_BYTES + _CHECKSUM_BYTES:
        return False
    return (
        _read_u16_at(bytes, 4) == HNSW_SNAPSHOT_V3_VERSION
        and _read_u64_at(bytes, 16) == config.fingerprint()
        and _read_u64_at(bytes, 24) == sequence
        and _read_u32_at(bytes, 32) == UInt32(config.dimension)
        and bytes[36] == config.ann_metric.tag()
        and bytes[37] == config.scalar_kind.tag()
        and _read_u16_at(bytes, 38) == UInt16(config.m)
        and _read_u16_at(bytes, 40) == UInt16(config.m0)
        and _read_u16_at(bytes, 42) == UInt16(config.max_level)
        and _read_u64_at(bytes, 56) == live_point_count
    )


def _mapped_hnsw_snapshot_identity_matches(
    mapping: MappedFile,
    config: CollectionConfig,
    sequence: UInt64,
    live_point_count: UInt64,
) raises -> Bool:
    """Compare fixed identity fields directly in one acquired mapping."""
    if mapping.byte_length() < HNSW_SNAPSHOT_HEADER_BYTES + _CHECKSUM_BYTES:
        return False
    return (
        _mapped_u16(mapping, 4) == HNSW_SNAPSHOT_V3_VERSION
        and _mapped_u64(mapping, 16) == config.fingerprint()
        and _mapped_u64(mapping, 24) == sequence
        and _mapped_u32(mapping, 32) == UInt32(config.dimension)
        and mapping.byte_at(36) == config.ann_metric.tag()
        and mapping.byte_at(37) == config.scalar_kind.tag()
        and _mapped_u16(mapping, 38) == UInt16(config.m)
        and _mapped_u16(mapping, 40) == UInt16(config.m0)
        and _mapped_u16(mapping, 42) == UInt16(config.max_level)
        and _mapped_u64(mapping, 56) == live_point_count
    )


def _slot_flag(index: HnswIndex, slot: UInt32) raises -> UInt8:
    if index.graph.is_current(slot):
        return _CURRENT_FLAG
    if index.graph.is_deleted(slot):
        return _DELETED_FLAG
    if index.graph.is_replaced(slot):
        return _REPLACED_FLAG
    raise Error("HNSW snapshot slot lifecycle flags are inconsistent")


def _require_v1_config(config: CollectionConfig) raises:
    config.validate()
    if not is_64bit():
        raise Error("HNSW snapshot v1 requires a 64-bit Int target")
    if config.scalar_kind != ScalarKind.f32():
        raise Error("HNSW snapshot v1 requires scalar kind f32")


def _require_snapshot_config(config: CollectionConfig) raises:
    config.validate()
    if not is_64bit():
        raise Error("HNSW snapshots require a 64-bit Int target")


def _snapshot_version(scalar: ScalarKind) raises -> UInt16:
    if not scalar.is_valid():
        raise Error("unsupported HNSW snapshot scalar kind")
    return HNSW_SNAPSHOT_V3_VERSION


def _snapshot_header_bytes(version: UInt16) raises -> Int:
    if version == HNSW_SNAPSHOT_VERSION:
        return HNSW_SNAPSHOT_HEADER_BYTES
    if version == HNSW_SNAPSHOT_V2_VERSION:
        return HNSW_SNAPSHOT_V2_HEADER_BYTES
    if version == HNSW_SNAPSHOT_V3_VERSION:
        return HNSW_SNAPSHOT_V3_HEADER_BYTES
    raise Error("unsupported HNSW snapshot version")


def _snapshot_vector_width(scalar: ScalarKind) raises -> Int:
    if scalar == ScalarKind.f32():
        return 4
    if scalar == ScalarKind.bf16() or scalar == ScalarKind.f16():
        return 2
    if scalar == ScalarKind.i8():
        return 1
    raise Error("unsupported HNSW snapshot scalar kind")


def _snapshot_scale_width(metric: MetricKind, scalar: ScalarKind) -> Int:
    if scalar == ScalarKind.i8() and metric == MetricKind.dot():
        return 4
    return 0


def _graph_i8_scale(index: HnswIndex, slot: UInt32) raises -> Float32:
    if index.config.scalar_kind != ScalarKind.i8():
        return Float32(0.0)
    if index.config.ann_metric == MetricKind.cosine():
        return Float32(1.0 / 127.0)
    return index.graph.vector_scales[Int(slot)]


def _copy_graph_vector(index: HnswIndex, slot: UInt32) raises -> List[Float32]:
    var values = List[Float32](capacity=index.config.dimension)
    for component in range(index.config.dimension):
        values.append(index.graph.vector_value(slot, component))
    return values^


def _validate_snapshot_graph_vectors(index: HnswIndex) raises:
    """Apply the codec's prepared-vector contract without encoding bytes."""
    for slot_index in range(index.graph.slot_count()):
        var prepared: List[Float32]
        if index.config.scalar_kind == ScalarKind.i8():
            prepared = List[Float32](capacity=index.config.dimension + 1)
            var base = slot_index * index.config.dimension
            for component in range(index.config.dimension):
                prepared.append(
                    Float32(
                        bitcast[DType.int8](
                            index.graph.vector_bytes[base + component]
                        )
                    )
                )
            prepared.append(_graph_i8_scale(index, UInt32(slot_index)))
        else:
            prepared = _copy_graph_vector(index, UInt32(slot_index))
        index.metric.validate_prepared_vector(prepared)


def _count_directed_edges(index: HnswIndex) raises -> UInt64:
    var result = UInt64(0)
    for slot_index in range(index.graph.slot_count()):
        var slot = UInt32(slot_index)
        for level in range(index.graph.level(slot) + 1):
            result = _checked_add_u64(
                result, UInt64(index.graph.neighbor_count(slot, level))
            )
    return result


def _checked_add_u64(lhs: UInt64, rhs: UInt64) raises -> UInt64:
    if rhs > UInt64.MAX - lhs:
        raise Error("HNSW snapshot offset arithmetic overflows")
    return lhs + rhs


def _checked_mul_u64(lhs: UInt64, rhs: UInt64) raises -> UInt64:
    if lhs != UInt64(0) and rhs > UInt64.MAX // lhs:
        raise Error("HNSW snapshot length arithmetic overflows")
    return lhs * rhs


def _align8(value: UInt64) raises -> UInt64:
    var remainder = value % UInt64(8)
    if remainder == UInt64(0):
        return value
    return _checked_add_u64(value, UInt64(8) - remainder)


def _require_supported_file_length(length: UInt64) raises:
    if length > UInt64(_MAX_SNAPSHOT_BYTES) or length > UInt64(Int.MAX):
        raise Error("HNSW snapshot exceeds implementation size limit")


def _validate_decode_allocation(
    serialized_bytes: UInt64,
    slot_count: UInt64,
    dimension: UInt64,
    level_count: UInt64,
    directed_edges: UInt64,
    allocated_neighbor_cells: UInt64,
) raises:
    """Bound the conservative peak after exact node capacities are known."""
    _validate_decode_peak(
        serialized_bytes,
        slot_count,
        dimension,
        level_count,
        directed_edges,
        allocated_neighbor_cells,
    )


def _validate_hnsw_snapshot_header_allocation(
    serialized_bytes: UInt64,
    slot_count: UInt64,
    dimension: UInt64,
    level_count: UInt64,
    directed_edges: UInt64,
    m0: UInt64,
) raises:
    """Reject hostile header capacities before staging lists or maps exist."""
    var minimum_neighbor_cells = _checked_mul_u64(slot_count, m0)
    _validate_decode_peak(
        serialized_bytes,
        slot_count,
        dimension,
        level_count,
        directed_edges,
        minimum_neighbor_cells,
    )


def _validate_decode_peak(
    serialized_bytes: UInt64,
    slot_count: UInt64,
    dimension: UInt64,
    level_count: UInt64,
    directed_edges: UInt64,
    allocated_neighbor_cells: UInt64,
) raises:
    """Conservatively bound decode, materialization, and validation peak.

    Mojo 1.0 does not expose stable `List` or `Dict` allocation overhead. The
    documented per-entry constants therefore intentionally exceed payload
    widths and include both staging and final graph columns. Current-ID maps
    assume every untrusted slot is current. Level and edge constants include
    the bidirectional validator's dictionaries and reverse-edge tape.
    """
    var vector_cells = _checked_mul_u64(slot_count, dimension)
    var estimated = serialized_bytes
    estimated = _checked_add_u64(
        estimated, _checked_mul_u64(vector_cells, UInt64(8))
    )
    estimated = _checked_add_u64(
        estimated, _checked_mul_u64(dimension, UInt64(4))
    )
    estimated = _checked_add_u64(
        estimated,
        _checked_mul_u64(level_count, _LEVEL_VALIDATION_PEAK_BYTES),
    )
    estimated = _checked_add_u64(
        estimated,
        _checked_mul_u64(directed_edges, _EDGE_VALIDATION_PEAK_BYTES),
    )
    estimated = _checked_add_u64(
        estimated, _checked_mul_u64(allocated_neighbor_cells, UInt64(4))
    )
    estimated = _checked_add_u64(
        estimated, _checked_mul_u64(slot_count, _SLOT_PEAK_BYTES)
    )
    estimated = _checked_add_u64(
        estimated,
        _checked_mul_u64(slot_count, _CURRENT_MAP_PEAK_BYTES),
    )
    var amplification_budget = _MIN_ALLOCATION_BUDGET
    if serialized_bytes <= UInt64.MAX // _MAX_ALLOCATION_RATIO:
        var scaled = serialized_bytes * _MAX_ALLOCATION_RATIO
        if scaled > amplification_budget:
            amplification_budget = scaled
    if (
        estimated > amplification_budget
        or estimated > _MAX_DECODE_ALLOCATION_BYTES
    ):
        raise Error("HNSW snapshot decoded allocation exceeds safe limit")


def _bounded_count(value: UInt64, maximum: Int, label: String) raises -> Int:
    if value > UInt64(maximum) or value > UInt64(Int.MAX):
        raise Error(String("HNSW snapshot ", label, " count is too large"))
    return Int(value)


def _validate_section_layout(
    file_length: UInt64,
    slot_count: UInt64,
    dimension: UInt64,
    directed_edges: UInt64,
    node_offset: UInt64,
    node_length: UInt64,
    vector_offset: UInt64,
    vector_length: UInt64,
    count_offset: UInt64,
    count_length: UInt64,
    edge_offset: UInt64,
    edge_length: UInt64,
    header_bytes: Int = HNSW_SNAPSHOT_HEADER_BYTES,
    vector_width: Int = 4,
    scale_offset: UInt64 = UInt64(0),
    scale_length: UInt64 = UInt64(0),
    scale_width: Int = 0,
    entry_offset: UInt64 = UInt64(0),
    entry_length: UInt64 = UInt64(0),
) raises:
    var expected_node_length = _checked_mul_u64(
        slot_count, UInt64(HNSW_SNAPSHOT_NODE_BYTES)
    )
    var expected_vector_length = _checked_mul_u64(
        _checked_mul_u64(slot_count, dimension), UInt64(vector_width)
    )
    var expected_scale_length = _checked_mul_u64(
        slot_count, UInt64(scale_width)
    )
    var expected_scale_offset = _align8(
        _checked_add_u64(vector_offset, vector_length)
    )
    var actual_scale_offset = scale_offset
    if scale_offset == UInt64(0):
        actual_scale_offset = expected_scale_offset
    var expected_edge_length = _checked_mul_u64(directed_edges, UInt64(4))
    if (
        node_offset != UInt64(header_bytes)
        or node_length != expected_node_length
        or vector_offset != _align8(_checked_add_u64(node_offset, node_length))
        or vector_length != expected_vector_length
        or actual_scale_offset != expected_scale_offset
        or scale_length != expected_scale_length
        or count_offset
        != _align8(_checked_add_u64(actual_scale_offset, scale_length))
        or edge_offset != _align8(_checked_add_u64(count_offset, count_length))
        or edge_length != expected_edge_length
    ):
        raise Error("HNSW snapshot section layout is invalid")
    var body_end = _checked_add_u64(edge_offset, edge_length)
    if entry_offset != 0:
        if entry_offset != _align8(body_end) or entry_length < 16 or entry_length > _checked_add_u64(UInt64(16), _checked_mul_u64(slot_count, UInt64(8))):
            raise Error("HNSW entry section layout is invalid")
        body_end = _checked_add_u64(entry_offset, entry_length)
    elif entry_length != 0:
        raise Error("HNSW entry section layout is invalid")
    if _checked_add_u64(body_end, UInt64(_CHECKSUM_BYTES)) != file_length:
        raise Error("HNSW snapshot section range exceeds file")


def _write_magic(mut writer: BinaryWriter):
    writer.write_u8(UInt8(0x41))  # A
    writer.write_u8(UInt8(0x4B))  # K
    writer.write_u8(UInt8(0x48))  # H
    writer.write_u8(UInt8(0x47))  # G


def _read_magic[Reader: BinaryReaderSource](mut reader: Reader) raises:
    if (
        reader.read_u8() != UInt8(0x41)
        or reader.read_u8() != UInt8(0x4B)
        or reader.read_u8() != UInt8(0x48)
        or reader.read_u8() != UInt8(0x47)
    ):
        raise Error("invalid HNSW snapshot magic")


def _write_zeros(mut writer: BinaryWriter, count: Int):
    for _ in range(count):
        writer.write_u8(UInt8(0))


def _read_zero_padding[Reader: BinaryReaderSource](mut reader: Reader, count: Int) raises:
    for _ in range(count):
        if reader.read_u8() != UInt8(0):
            raise Error("nonzero HNSW snapshot alignment padding")


def _read_u32_at(bytes: List[UInt8], offset: Int) -> UInt32:
    return (
        UInt32(bytes[offset])
        | (UInt32(bytes[offset + 1]) << UInt32(8))
        | (UInt32(bytes[offset + 2]) << UInt32(16))
        | (UInt32(bytes[offset + 3]) << UInt32(24))
    )


def _read_u16_at(bytes: List[UInt8], offset: Int) -> UInt16:
    return UInt16(bytes[offset]) | (UInt16(bytes[offset + 1]) << UInt16(8))


def _read_u64_at(bytes: List[UInt8], offset: Int) -> UInt64:
    return (
        UInt64(bytes[offset])
        | (UInt64(bytes[offset + 1]) << UInt64(8))
        | (UInt64(bytes[offset + 2]) << UInt64(16))
        | (UInt64(bytes[offset + 3]) << UInt64(24))
        | (UInt64(bytes[offset + 4]) << UInt64(32))
        | (UInt64(bytes[offset + 5]) << UInt64(40))
        | (UInt64(bytes[offset + 6]) << UInt64(48))
        | (UInt64(bytes[offset + 7]) << UInt64(56))
    )


def _mapped_u16(mapping: MappedFile, offset: Int) raises -> UInt16:
    return UInt16(mapping.byte_at(offset)) | (
        UInt16(mapping.byte_at(offset + 1)) << UInt16(8)
    )


def _mapped_u32(mapping: MappedFile, offset: Int) raises -> UInt32:
    var value = UInt32(0)
    for index in range(4):
        value |= UInt32(mapping.byte_at(offset + index)) << UInt32(index * 8)
    return value


def _mapped_u64(mapping: MappedFile, offset: Int) raises -> UInt64:
    var value = UInt64(0)
    for index in range(8):
        value |= UInt64(mapping.byte_at(offset + index)) << UInt64(index * 8)
    return value


def _validate_mapped_zero_padding(
    mapping: MappedFile, start: UInt64, end: UInt64
) raises:
    if start > end or end > UInt64(mapping.byte_length()):
        raise Error("HNSW snapshot alignment padding range is invalid")
    for offset in range(Int(start), Int(end)):
        if mapping.byte_at(offset) != UInt8(0):
            raise Error("nonzero HNSW snapshot alignment padding")
