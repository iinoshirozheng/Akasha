"""Qdrant's ordinary filtered HNSW search, before performance adaptations.

Adapted from Qdrant (Apache-2.0), commit
21db2f3ff95d50de3a2b88a741312c056fd1762d, graph_layers.rs,
entry_points.rs, point_scorer.rs and search_context.rs. See the adjacent
qdrant_search_reference.md for provenance, scope and integration requirements.

This reference uses Akasha's checked graph access, metrics and deterministic
distance/ID/slot ties. It is not the production search or a speed benchmark.
Rejection counters count checks, which can repeat; distance counters count
actual calls. They deliberately do not claim production counter equivalence.
"""

from akasha.compute.metric import MetricDispatcher
from akasha.index.hnsw_core import HnswResultAdmission
from akasha.index.hnsw_heap import HnswHeapItem, _is_better
from akasha.index.hnsw_scratch import HnswSearchScratch
from akasha.index.hnsw_stats import HnswSearchStats
from akasha.index.hnsw_storage import HnswGraphAccess


def choose_entry[
    GraphType: HnswGraphAccess, AdmissionType: HnswResultAdmission
](
    graph: GraphType,
    primary: List[UInt32],
    extra: List[UInt32],
    allowed: AdmissionType,
) raises -> Optional[UInt32]:
    """First eligible primary, otherwise highest eligible extra entry."""
    for slot in primary:
        if graph.is_current(slot) and allowed._allows_item(
            slot, graph.id_at(slot)
        ):
            return Optional(slot)
    var best = Optional[UInt32]()
    var best_level = -1
    for slot in extra:
        if graph.is_current(slot) and allowed._allows_item(
            slot, graph.id_at(slot)
        ):
            var level = graph.level(slot)
            if level >= best_level:
                best = Optional(slot)
                best_level = level
    return best^


def score_points[
    GraphType: HnswGraphAccess, AdmissionType: HnswResultAdmission
](
    graph: GraphType,
    dispatcher: MetricDispatcher,
    prepared: List[Float32],
    points: List[UInt32],
    limit: Int,
    allowed: AdmissionType,
    mut stats: HnswSearchStats,
) raises -> List[HnswHeapItem]:
    """Filter the whole batch, then cap, then score (FilteredScorer order)."""
    var retained = List[UInt32]()
    for slot in points:
        if not graph.is_current(slot):
            stats.inactive_rejections += 1
        elif not allowed._allows_item(slot, graph.id_at(slot)):
            stats.filtered_rejections += 1
        else:
            retained.append(slot)
    var count = len(retained)
    if limit > 0 and count > limit:
        count = limit
    var result = List[HnswHeapItem](capacity=count)
    for i in range(count):
        var slot = retained[i]
        var distance = graph.distance_to_slot(dispatcher, prepared, slot)
        stats.distance_evaluations += 1
        result.append(HnswHeapItem(slot, graph.id_at(slot), distance))
    return result^


def _process_candidate(
    item: HnswHeapItem, ef: Int, mut scratch: HnswSearchScratch
) raises:
    # Qdrant enqueues only points admitted into the bounded nearest queue.
    if len(scratch.results) < ef or _is_better(
        item, scratch.results.peek_worst()
    ):
        scratch.results.offer(item, ef)
        scratch.candidates.push(item)


def search_level[
    GraphType: HnswGraphAccess, AdmissionType: HnswResultAdmission
](
    graph: GraphType,
    dispatcher: MetricDispatcher,
    prepared: List[Float32],
    entry: HnswHeapItem,
    level: Int,
    ef: Int,
    allowed: AdmissionType,
    mut scratch: HnswSearchScratch,
    mut stats: HnswSearchStats,
) raises -> List[HnswHeapItem]:
    if ef <= 0 or level < 0:
        raise Error(
            "reference search requires positive ef and nonnegative level"
        )
    allowed.validate(graph.slot_count())
    scratch.begin(graph.slot_count(), ef)
    _ = scratch.visit(entry.slot)
    _process_candidate(entry, ef, scratch)
    stats.base_visited += 1
    var limit = graph.graph_m0() if level == 0 else graph.graph_m()
    while not scratch.candidates.is_empty():
        var candidate = scratch.candidates.pop()
        if candidate.distance > scratch.results.peek_worst().distance:
            break
        var points = List[UInt32]()
        var edges = graph.neighbor_range(candidate.slot, level)
        for i in range(edges[1]):
            var neighbor = graph.neighbor_at_offset(edges[0] + i)
            if graph.level(neighbor) < level:
                raise Error("reference edge targets a node below its level")
            # Qdrant marks scored nodes, not rejected or truncated neighbors.
            if scratch.visited_epochs[Int(neighbor)] != scratch.epoch:
                points.append(neighbor)
        var scored = score_points(
            graph, dispatcher, prepared, points, limit, allowed, stats
        )
        for item in scored:
            _process_candidate(item, ef, scratch)
            _ = scratch.visit(item.slot)
            stats.base_visited += 1
    return scratch.results.take_sorted_best()


def search[
    GraphType: HnswGraphAccess, AdmissionType: HnswResultAdmission
](
    graph: GraphType,
    dispatcher: MetricDispatcher,
    prepared: List[Float32],
    primary: List[UInt32],
    extra: List[UInt32],
    k: Int,
    ef: Int,
    allowed: AdmissionType,
    mut scratch: HnswSearchScratch,
    mut stats: HnswSearchStats,
) raises -> List[HnswHeapItem]:
    """Eligible entry, filtered upper descent, filtered beam, final top-k."""
    if k < 0 or ef < 0:
        raise Error("reference k and ef cannot be negative")
    if k == 0:
        return List[HnswHeapItem]()
    graph.validate_search_ready()
    dispatcher.validate_prepared_vector(prepared)
    allowed.validate(graph.slot_count())
    var entry = choose_entry(graph, primary, extra, allowed)
    if not entry:
        return List[HnswHeapItem]()
    var current = entry.value()
    var current_item = HnswHeapItem(current, graph.id_at(current), 0.0)
    var highest = graph.level(current)
    for level in range(highest, 0, -1):
        current_item = HnswHeapItem(
            current,
            graph.id_at(current),
            graph.distance_to_slot(dispatcher, prepared, current),
        )
        stats.distance_evaluations += 1
        stats.upper_visited += 1
        while True:
            var points = List[UInt32]()
            var edges = graph.neighbor_range(current_item.slot, level)
            for i in range(edges[1]):
                var neighbor = graph.neighbor_at_offset(edges[0] + i)
                if graph.level(neighbor) < level:
                    raise Error("reference edge targets a node below its level")
                points.append(neighbor)
            var scored = score_points(
                graph,
                dispatcher,
                prepared,
                points,
                graph.graph_m(),
                allowed,
                stats,
            )
            stats.upper_visited += len(scored)
            var changed = False
            for item in scored:
                # Upstream upper descent moves only on strictly better score.
                if item.distance < current_item.distance:
                    current_item = item
                    changed = True
            if not changed:
                break
        current = current_item.slot
    if highest == 0:
        current_item = HnswHeapItem(
            current,
            graph.id_at(current),
            graph.distance_to_slot(dispatcher, prepared, current),
        )
        stats.distance_evaluations += 1
    var breadth = ef if ef >= k else k
    var results = search_level(
        graph,
        dispatcher,
        prepared,
        current_item,
        0,
        breadth,
        allowed,
        scratch,
        stats,
    )
    while len(results) > k:
        _ = results.pop()
    stats.retained_candidates = len(results)
    return results^
