"""Reverse-order full-driver real1536 screen of retained/first/slot variants."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
base=root.parent/'delta-admission-first/known-count/warm-matrix/real-1536'
kernels=dict(prior=root.parent/'immutable-point-score-certificate/python/akashadb/_kernel.so',
    first=root.parent/'immutable-point-delta-score-certificate/python/akashadb/_kernel.so',
    candidate=root/'python/akashadb/_kernel.so')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={k:sha(p) for k,p in kernels.items()}
assert hashes['prior']=='5ae85379b8948276ac2aba0e0fa1fd86447989c499562cc57fa1411b50c936fc'
assert hashes['first']=='374cdded5e86503c686ff0514d5818e42d4a3cd2f37e233fed73d2bb18ffac04'
assert hashes['candidate']==json.loads((root/'native-build.json').read_text())['kernel_sha256']
assert not json.loads(subprocess.check_output(['rtk','proxy','docker','inspect','akasha-linux-20261012']))[0]['State']['Running']
expected=json.loads((root/'inputs/full-warm/real-1536-0-akasha.json').read_text())
out=root/'warm-diagnostic';out.mkdir()
source=base/'trial-0-akasha/database'
files={str(p.relative_to(source)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(source.rglob('*')) if p.is_file()}
control=json.loads((root.parent/'immutable-point-local-matrix/identity.json').read_text())
assert files==control['source_database_files']['real-1536/0/akasha']
(out/'identity.json').write_text(json.dumps(dict(binaries=hashes,database=files,selection=[32,256,128,10],workload_npz_sha256=sha(base/'workload.npz'),scope='All48 ef/mode cells of original full warm driver, one frozen real1536 trial0 graph, two reverse orders. Diagnostic comparisons only; no new Qdrant or acceptance gate.'),indent=2)+'\n')
runs=[];pairs=[]
for repeat,order in enumerate([('prior','first','candidate'),('candidate','first','prior')]):
    reports={}
    for label in order:
        stem=f'{repeat}-{label}';directory=out/stem;directory.mkdir()
        shutil.copytree(source,directory/'database')
        job=dict(phase='warm',engine='akasha',corpus=str(base),database=str(directory/'database'),efs=[32,256,128,10],native_binary_sha256=hashes[label],kernel=str(kernels[label]),output=str(directory/'report.json'))
        jobpath=directory/'job.json';jobpath.write_text(json.dumps(job,indent=2)+'\n')
        cmd=['rtk','proxy',sys.executable,str(root/'warm_full_worker.py'),str(jobpath)]
        env=dict(os.environ,PYTHONPATH=str(kernels[label].parent.parent)+':.:'+str(root.parent/'qdrant-runtime/deps'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
        print('starting full-warm diagnostic',stem,flush=True)
        with (directory/'worker.log').open('w') as log:
            p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        runs.append(dict(repeat=repeat,label=label,order=order,command=cmd,exit_code=p.returncode))
        (out/'execution.json').write_text(json.dumps(runs,indent=2)+'\n')
        assert p.returncode==0,(directory/'worker.log').read_text()
        report=json.loads((directory/'report.json').read_text())
        assert report['native_binary_sha256']==hashes[label] and report['status']=='ok' and report['reopen_exact_oracle_match']
        assert report['exact_preflight']==expected['exact_preflight']
        for a,b in zip(report['warmups'],expected['warmups'],strict=True):
            assert all(a[k]==b[k] for k in ('mode','ef','ordinal','ids','scores_f32_hex','stats','recall','execution'))
        for cell,old in zip(report['measurements'],expected['measurements'],strict=True):
            assert cell['mode']==old['mode'] and cell['ef']==old['ef']
            for a,b in zip(cell['queries'],old['queries'],strict=True):
                assert all(a[k]==b[k] for k in ('ordinal','ids','scores_f32_hex','stats','recall','execution'))
        reports[label]=report
        print('verified full-warm diagnostic',stem,flush=True)
    row=dict(repeat=repeat,order=order,comparisons=[])
    for label in ('first','candidate'):
        for mode,ef in zip(('all','correlated','independent','selective'),(32,256,128,10)):
            a=next(x for x in reports['prior']['measurements'] if x['mode']==mode and x['ef']==ef)
            b=next(x for x in reports[label]['measurements'] if x['mode']==mode and x['ef']==ef)
            row['comparisons'].append(dict(label=label,mode=mode,ef=ef,qps_ratio=b['qps']/a['qps'],p95_ratio=b['p95_ns']/a['p95_ns']))
    pairs.append(row);(out/'pairs.json').write_text(json.dumps(pairs,indent=2)+'\n')
    print(json.dumps(row),flush=True)
