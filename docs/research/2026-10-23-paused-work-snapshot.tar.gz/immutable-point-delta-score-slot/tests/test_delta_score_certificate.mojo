from test_segmented_hnsw import _lookup
from test_score_certificate import _values, _path
from akasha.common.config import CollectionConfig, MetricKind, ScalarKind
from akasha.compute.topk import BoundedTopK
from akasha.document.point_state import PointField, PointState
from akasha.document.vector_value import VectorValue
from akasha.index.bitmap import Bitmap
from akasha.index.flat import authoritative_f32_score, SearchResult
from akasha.index.hnsw import HnswIndex
from akasha.index.hnsw_core import HnswEligibility
from akasha.index.segmented_hnsw import SegmentedHnsw
from akasha.storage.filesystem import write_file_sync, remove_file_if_exists, ensure_directory, path_exists
from akasha.storage.checksum import BinaryWriter
from akasha.storage.generation_pins import GenerationPinRegistry
from akasha.storage.manifest import Manifest, publish_manifest
from akasha.storage.mapped_vector_file import MappedVectorFile
from akasha.storage.hnsw_store import encode_hnsw_snapshot, open_hnsw_snapshot_view
from akasha.storage.memtable import MemTable, MemTableEntry, NumericOwnerReplacement
from std.math import nan
from std.memory import bitcast, ArcPointer
from std.testing import assert_equal, assert_true, assert_false, assert_raises, TestSuite

def _compare_exact(results: List[SearchResult], table: MemTable, query: List[Float32], metric: Int, k: Int, even_only: Bool = False) raises:
    var expected = BoundedTopK(k, smaller_is_better=metric == 1)
    for ordinal in range(table.slot_count()):
        ref entry = table.entry_ref_at(ordinal)
        if entry.tombstone or (even_only and entry.id % 2):
            continue
        expected.offer(entry.id, authoritative_f32_score(metric, query, entry._dense_reader()))
    var entries = expected.sorted_entries()
    assert_equal(len(results), len(entries))
    for index in range(len(results)):
        assert_equal(results[index].id, entries[index].id)
        assert_equal(bitcast[DType.uint32](results[index].score), bitcast[DType.uint32](entries[index].score))

def _check_hit_bits(results: List[SearchResult], table: MemTable, query: List[Float32], metric: Int) raises:
    var lookup = _lookup(table)
    for hit in results:
        ref entry = table.entry_ref_at(lookup.ordinal_for(hit.id))
        assert_equal(bitcast[DType.uint32](hit.score), bitcast[DType.uint32](authoritative_f32_score(metric, query, entry._dense_reader())))

def test_scored_delta_results_reuse_their_query_scores() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(1)
    for id in range(8):
        var values: List[Float32] = [Float32(id + 1)]
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var results = index.search([Float32(1)], 2, 2, table, _lookup(table))
    assert_equal(results[0].id, 7)
    assert_equal(results[1].id, 6)
    assert_equal(index.last_search_stats().distance_evaluations, 8)
    assert_equal(index._last_reused_graph_scores, 2)

def test_delta_scores_keep_bits_for_width_boundaries_and_odd_tails() raises:
    for metric in [MetricKind.dot(), MetricKind.l2()]:
        for dimension in [1, 3, 17, 63, 64, 65, 128, 1536]:
            var config = CollectionConfig.defaults(dimension)
            config.ann_metric = metric.copy()
            var index = SegmentedHnsw(config)
            var table = MemTable(dimension)
            for id in range(8):
                var values = _values(dimension, id)
                index.upsert(id, values)
                table.apply_upsert(id, UInt64(id + 1), values^)
            var lookup = _lookup(table)
            for q in range(3):
                var query = _values(dimension, 10 + q)
                for k in [2, 3]:
                    var results = index.search(query, k, k, table, lookup)
                    _compare_exact(results, table, query, Int(metric.tag()), k)
                    assert_equal(index._last_reused_graph_scores, 2)
                    assert_equal(index.last_search_stats().distance_evaluations, 8)
                    assert_equal(index.last_search_stats().reranked_candidates, k)

def test_filtered_scored_delta_and_unscored_admission_are_distinct() raises:
    var config = CollectionConfig.defaults(17)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(17)
    for id in range(8):
        var values = _values(17, id)
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var lookup = _lookup(table)
    var bitmap = Bitmap(8)
    for id in range(0, 8, 2):
        bitmap.set(id)
    var allowed = HnswEligibility(bitmap^, lookup)
    var query = _values(17, 12)
    var scored = index.search_allowed(query, 2, 2, 2, allowed, table, lookup)
    _compare_exact(scored, table, query, 0, 2, True)
    assert_equal(index._last_reused_graph_scores, 2)
    assert_equal(index.last_search_stats().distance_evaluations, 4)
    var admitted = index.search_allowed(query, 4, 16, 16, allowed, table, lookup)
    _compare_exact(admitted, table, query, 0, 4, True)
    assert_equal(index._last_reused_graph_scores, 0)
    assert_equal(index.last_search_stats().distance_evaluations, 0)
    var all = index.search(query, 8, 16, table, lookup)
    _compare_exact(all, table, query, 0, 8)
    assert_equal(index._last_reused_graph_scores, 0)
    assert_equal(index.last_search_stats().distance_evaluations, 0)

def test_delta_owner_replacement_same_sequence_and_slot_replacement() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(1)
    for id in range(8):
        var values: List[Float32] = [Float32(id + 1)]
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var lookup = _lookup(table)
    var query: List[Float32] = [Float32(1)]
    _ = index.search(query, 2, 2, table, lookup)
    var expired = index._sources._state[].delta_score_proofs[7].owner
    table.put(MemTableEntry(7, 8, False, [Float32(40)]))
    assert_false(expired.try_upgrade())
    for _ in range(2):
        _compare_exact(index.search(query, 2, 2, table, lookup), table, query, 0, 2)
        assert_equal(index._last_reused_graph_scores, 0)
    table.put(MemTableEntry(7, 8, False, [Float32(8)]))
    _compare_exact(index.search(query, 2, 2, table, lookup), table, query, 0, 2)
    assert_equal(index._last_reused_graph_scores, 2)
    index.upsert(7, [Float32(40)])
    table.put(MemTableEntry(7, 8, False, [Float32(40)]))
    _compare_exact(index.search(query, 2, 2, table, lookup), table, query, 0, 2)
    assert_equal(index._last_reused_graph_scores, 2)
    assert_equal(len(index._sources._state[].delta_score_proofs), 9)
    assert_true(index.delete(7))
    table.apply_delete(7, 9)
    lookup = _lookup(table)
    _compare_exact(index.search(query, 2, 2, table, lookup), table, query, 0, 2)
    assert_equal(index._last_reused_graph_scores, 2)
    index.upsert(7, [Float32(80)])
    table.apply_upsert(7, 10, [Float32(80)])
    lookup = _lookup(table)
    _compare_exact(index.search(query, 2, 2, table, lookup), table, query, 0, 2)
    assert_equal(index._last_reused_graph_scores, 2)
    assert_equal(len(index._sources._state[].delta_score_proofs), 10)

def test_delta_promotion_discards_slot_proofs_before_new_delta_generation() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(1)
    for id in range(8):
        var values: List[Float32] = [Float32(id + 1)]
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var lookup = _lookup(table)
    _ = index.search([Float32(1)], 2, 2, table, lookup)
    assert_equal(len(index._sources._state[].delta_score_proofs), 8)
    index.promote_delta_base()
    assert_equal(len(index._sources._state[].delta_score_proofs), 0)
    assert_equal(len(index._sources._state[].score_proofs), 0)
    _compare_exact(index.search([Float32(1)], 8, 16, table, lookup), table, [Float32(1)], 0, 8)
    assert_equal(index._last_reused_graph_scores, 8)
    index.upsert(7, [Float32(40)])
    table.put(MemTableEntry(7, 8, False, [Float32(40)]))
    _compare_exact(index.search([Float32(1)], 8, 16, table, lookup), table, [Float32(1)], 0, 8)
    assert_equal(index._last_reused_graph_scores, 6)
    assert_equal(len(index._sources._state[].delta_score_proofs), 0)

def test_owned_and_mapped_base_merge_with_scored_delta() raises:
    for mapped in [False, True]:
        var config = CollectionConfig.defaults(17)
        config.ann_metric = MetricKind.dot()
        var base = HnswIndex(config)
        var table = MemTable(17)
        for id in range(4):
            var values = _values(17, id)
            base.add(id, values)
            table.apply_upsert(id, UInt64(id + 1), values^)
        var path = _path(String("delta-merge-", mapped))
        var index = SegmentedHnsw(config)
        if mapped:
            write_file_sync(path, encode_hnsw_snapshot(base, UInt64(4)))
            index = SegmentedHnsw.from_mapped(open_hnsw_snapshot_view(path, config, UInt64(4)))
        else:
            index = SegmentedHnsw.from_owned(base^)
        for id in range(4, 16):
            var values = _values(17, id)
            index.upsert(id, values)
            table.apply_upsert(id, UInt64(id + 1), values^)
        var query = _values(17, 20)
        _compare_exact(index.search(query, 8, 8, table, _lookup(table)), table, query, 0, 8)
        assert_equal(index.last_search_stats().base_candidates, 4)
        assert_equal(index.last_search_stats().delta_candidates, 8)
        assert_equal(index._last_reused_graph_scores, 12)
        index.close()
        if mapped:
            remove_file_if_exists(path)

def test_delta_hnsw_path_carries_scores_without_small_scan() raises:
    var config = CollectionConfig.defaults(3)
    config.ann_metric = MetricKind.dot()
    config.m = 2
    config.m0 = 2
    var base = HnswIndex(config)
    var table = MemTable(3)
    for id in range(8):
        var values = _values(3, id)
        base.add(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var index = SegmentedHnsw.from_owned(base^)
    for id in range(8, 20):
        var values = _values(3, id)
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var query = _values(3, 25)
    var lookup = _lookup(table)
    var results = index.search(query, 2, 2, table, lookup)
    _check_hit_bits(results, table, query, 0)
    assert_equal(index.last_search_stats().storage_name, "segmented-f32")
    assert_equal(index._last_reused_graph_scores, 4)

def test_delta_cosine_and_compact_paths_never_issue_proofs() raises:
    for metric in [MetricKind.dot(), MetricKind.l2(), MetricKind.cosine()]:
        for scalar in [ScalarKind.f32(), ScalarKind.bf16(), ScalarKind.f16(), ScalarKind.i8()]:
            if scalar == ScalarKind.f32() and metric != MetricKind.cosine():
                continue
            if scalar == ScalarKind.i8() and metric == MetricKind.l2():
                continue
            var config = CollectionConfig.defaults(17)
            config.ann_metric = metric.copy()
            config.scalar_kind = scalar.copy()
            var index = SegmentedHnsw(config)
            var table = MemTable(17)
            for id in range(8):
                var values = _values(17, id)
                index.upsert(id, values)
                table.apply_upsert(id, UInt64(id + 1), values^)
            var query = _values(17, 12)
            var results = index.search(query, 2, 2, table, _lookup(table))
            _check_hit_bits(results, table, query, Int(metric.tag()))
            assert_equal(index._last_reused_graph_scores, 0)
            assert_equal(len(index._sources._state[].delta_score_proofs), 0)

def test_delta_equal_nonfinite_bytes_are_not_a_value_certificate() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    index.upsert(0, [Float32(1)])
    index._delta.graph.vector_scalars[0] = nan[DType.float32]()
    var table = MemTable(1)
    table.put(MemTableEntry(0, 1, False, [nan[DType.float32]()]))
    ref entry = table.entry_ref_at(0)
    assert_false(index._graph_value_matches(entry, entry._dense_reader(), 0))

def test_delta_reused_prefix_keeps_first_finite_error_and_partial_stats() raises:
    var config = CollectionConfig.defaults(3)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(3)
    for id in range(4):
        var values = _values(3, id)
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var query = _values(3, 12)
    var scores = List[Float32]()
    for id in range(4):
        scores.append(authoritative_f32_score(0, query, table.entry_ref_at(id)._dense_reader()))
    table.put(MemTableEntry(2, 3, False, [nan[DType.float32](), Float32(1), Float32(2)]))
    var lookup = _lookup(table)
    var bitmap = Bitmap(4)
    for id in range(4):
        bitmap.set(id)
    var allowed = HnswEligibility(bitmap^, lookup)
    for filtered in [False, True]:
        with assert_raises(contains="finite"):
            if filtered:
                _ = index._rerank_allowed_candidates(query, 4, [0, 1, 2, 3, 999], table, lookup, allowed, scores, [UInt32(0), UInt32(1), UInt32(2), UInt32(3)])
            else:
                _ = index._rerank_candidates(query, 4, [0, 1, 2, 3, 999], table, lookup, scores, [UInt32(0), UInt32(1), UInt32(2), UInt32(3)])
        assert_equal(index.last_rerank_ordinal_lookups(), 4)
        assert_equal(index._last_reused_graph_scores, 2)

def test_score_pairs_can_cross_base_and_delta_source_boundary() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var base = HnswIndex(config)
    var table = MemTable(1)
    for id in range(3):
        var values: List[Float32] = [Float32(id + 1)]
        base.add(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var index = SegmentedHnsw.from_owned(base^)
    for id in range(3, 15):
        var values: List[Float32] = [Float32(id + 1)]
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    var result = index.search([Float32(1)], 8, 8, table, _lookup(table))
    _compare_exact(result, table, [Float32(1)], 0, 8)
    assert_equal(index.last_search_stats().base_candidates, 3)
    assert_equal(index.last_search_stats().delta_candidates, 8)
    assert_equal(index._last_reused_graph_scores, 10)

def test_delta_certificates_do_not_retain_retired_mapped_values() raises:
    var path = _path("delta-retirement")
    ensure_directory(path)
    var writer = BinaryWriter()
    writer.write_u8(0xAA)
    var config = CollectionConfig.defaults(3)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    for id in range(8):
        var values = _values(3, id)
        writer.write_f32s(values)
        index.upsert(id, values)
    write_file_sync(path + "/vectors.bin", writer.take_bytes())
    publish_manifest(path, Manifest(3, 1, 0, "vectors.bin"))
    var pins = ArcPointer(GenerationPinRegistry(path, 3))
    var file = Optional(ArcPointer(MappedVectorFile(pins, "vectors.bin")))
    var table = MemTable(3)
    for id in range(8):
        var point = PointState.live(id, UInt64(id + 1), UInt64(id + 1),
            [PointField(0, VectorValue._legacy_mapped_dense(file.value(), 1 + id * 12, 3))], [])
        table.put(MemTableEntry.from_point(point))
    file = None
    assert_false(Bool(file))
    var lookup = _lookup(table)
    var query = _values(3, 12)
    var results = index.search(query, 4, 4, table, lookup)
    _compare_exact(results, table, query, 0, 4)
    assert_equal(index._last_reused_graph_scores, 4)
    var expired = index._sources._state[].delta_score_proofs[results[0].id].owner
    assert_true(expired.try_upgrade())
    write_file_sync(path + "/new.bin", [UInt8(1)])
    publish_manifest(path, Manifest(3, 2, 0, "new.bin"))
    var replacements = Optional(List[NumericOwnerReplacement]())
    for id in range(8):
        replacements.value().append(NumericOwnerReplacement(id, 0,
            PointField(0, VectorValue.dense[DType.float32](_values(3, id))),
            table.entry_ref_at(id)._vectors[0].copy()))
    table._publish_compaction_owners(replacements.value())
    assert_true(path_exists(path + "/vectors.bin"))
    assert_true(Bool(replacements))
    replacements = None
    assert_false(Bool(replacements))
    assert_false(expired.try_upgrade())
    assert_false(path_exists(path + "/vectors.bin"))
    _compare_exact(index.search(query, 4, 4, table, lookup), table, query, 0, 4)
    assert_equal(index._last_reused_graph_scores, 4)

def test_carried_slots_reject_wrong_id_replaced_slot_and_wrong_source() raises:
    var config = CollectionConfig.defaults(1)
    config.ann_metric = MetricKind.dot()
    var index = SegmentedHnsw(config)
    var table = MemTable(1)
    for id in range(4):
        var values: List[Float32] = [Float32(id + 1)]
        index.upsert(id, values)
        table.apply_upsert(id, UInt64(id + 1), values^)
    assert_false(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), -1))
    assert_false(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 1))
    assert_false(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), Int(UInt32.MAX)))
    assert_true(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 0))
    index.upsert(0, [Float32(40)])
    assert_false(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 0))
    assert_false(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 4))
    table.put(MemTableEntry(0, 1, False, [Float32(40)]))
    assert_true(index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 4))
    var base = HnswIndex(config)
    base.add(0, [Float32(40)])
    var base_index = SegmentedHnsw.from_owned(base^)
    assert_false(base_index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), 0))
    assert_true(base_index._graph_value_matches(table.entry_ref_at(0), table.entry_ref_at(0)._dense_reader(), -1))

def main() raises:
    TestSuite.discover_tests[__functions_in_module()]().run()
