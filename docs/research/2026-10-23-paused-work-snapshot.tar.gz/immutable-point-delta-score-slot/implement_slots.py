"""Carry physical delta slots with scores instead of looking IDs up again."""
import difflib
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'src/akasha/index/segmented_hnsw.mojo'
before=path.read_text();source=before
def replace(old,new,count=1):
    global source
    assert source.count(old)==count,(old[:100],source.count(old),count)
    source=source.replace(old,new)
replace('''    var scores: List[Float32]


@fieldwise_init''','''    var scores: List[Float32]
    # Scored delta rows form the suffix of scores. Slots are query-local proof
    # provenance; no ID lookup or borrowed vector address escapes traversal.
    var delta_slots: List[UInt32]


@fieldwise_init''')
replace('''            var scores = List[Float32]()
            for hit in hits:''','''            var scores = List[Float32]()
            var delta_slots = List[UInt32]()
            for hit in hits:''')
replace('''                    scores.append(hit.score)
            return _CollectedCandidates(ids^, scores^)''','''                    scores.append(hit.score)
                    var slot = self._delta.graph.current_slot(hit.id)
                    delta_slots.append(slot.value() if slot else UInt32.MAX)
            return _CollectedCandidates(ids^, scores^, delta_slots^)''')
replace('''        var results = List[Int]()
        var scores = List[Float32]()
''','''        var results = List[Int]()
        var scores = List[Float32]()
        var delta_slots = List[UInt32]()
''')
replace('''                    scores.append(self._delta.metric.public_score(candidate.distance))
''','''                    scores.append(self._delta.metric.public_score(candidate.distance))
                    delta_slots.append(candidate.slot)
''')
replace('        return _CollectedCandidates(results^, scores^)','        return _CollectedCandidates(results^, scores^, delta_slots^)')
replace('''        var merged = List[Int]()
        var scores = List[Float32]()
''','''        var merged = List[Int]()
        var scores = List[Float32]()
        var delta_slots = List[UInt32]()
''',2)
replace('''                            scores.append(delta_results.scores[result_index])
''','''                            scores.append(delta_results.scores[result_index])
                            delta_slots.append(delta_results.delta_slots[result_index])
''',4)
replace('        return _CollectedCandidates(merged^, scores^)','        return _CollectedCandidates(merged^, scores^, delta_slots^)',2)
source=source.replace('candidates.scores','candidates.scores, candidates.delta_slots')
replace('''        scores: List[Float32],
    ) raises -> List[SearchResult]:''','''        scores: List[Float32],
        delta_slots: List[UInt32],
    ) raises -> List[SearchResult]:''',2)
source=source.replace('_reusable_graph_pair(0, scores,','_reusable_graph_pair(0, scores, delta_slots,').replace('_reusable_graph_pair(prepared, scores,','_reusable_graph_pair(prepared, scores, delta_slots,')
replace('''        mut self, offset: Int, scores: List[Float32],
''','''        mut self, offset: Int, scores: List[Float32], delta_slots: List[UInt32],
''')
replace('''        if not self._graph_value_matches(first, first_row):
            return None
        if not self._graph_value_matches(second, second_row):
''','''        if len(delta_slots) > len(scores):
            return None
        var delta_start = len(scores) - len(delta_slots)
        var first_slot = Int(delta_slots[offset - delta_start]) if offset >= delta_start else -1
        var next_slot = Int(delta_slots[offset + 1 - delta_start]) if offset + 1 >= delta_start else -1
        if not self._graph_value_matches(first, first_row, first_slot):
            return None
        if not self._graph_value_matches(second, second_row, next_slot):
''')
replace('''    def _graph_value_matches(
        mut self, entry: MemTableEntry, row: _NumericReadView[DType.float32, _],
''','''    def _graph_value_matches(
        mut self, entry: MemTableEntry, row: _NumericReadView[DType.float32, _], delta_slot: Int,
''')
replace('''        if source == _DELTA_SOURCE:
            return self._delta_value_matches(entry, row)
        var slot = source - 1
''','''        if source == _DELTA_SOURCE:
            return self._delta_value_matches(entry, row, delta_slot)
        if delta_slot >= 0:
            return False
        var slot = source - 1
''')
replace('''    def _delta_value_matches(
        mut self, entry: MemTableEntry, row: _NumericReadView[DType.float32, _],
''','''    def _delta_value_matches(
        mut self, entry: MemTableEntry, row: _NumericReadView[DType.float32, _], slot: Int,
''')
replace('''        var current = self._delta.graph.current_slot(entry.id)
        var dimension = self.config.dimension
        if not current or dimension <= 0 or len(row) != dimension:
            return False
        var slot = Int(current.value())
''','''        var dimension = self.config.dimension
        if slot < 0 or slot >= self._delta.graph.slot_count() or dimension <= 0 or len(row) != dimension:
            return False
        if not self._delta.graph.is_current(UInt32(slot)) or self._delta.graph.ids[slot] != entry.id:
            return False
''')
path.write_text(source)
(root/'slot-provenance.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='first/src/akasha/index/segmented_hnsw.mojo',tofile='slot/src/akasha/index/segmented_hnsw.mojo')))
for name in ['test_score_certificate.mojo','test_delta_score_certificate.mojo','test_hnsw_rerank_batch.mojo']:
    p=root/'tests'/name;text=p.read_text()
    text=text.replace('entry, entry._dense_reader()))','entry, entry._dense_reader(), '+('0' if name.startswith('test_delta') else '-1')+'))')
    text=text.replace('allowed, graph_scores)','allowed, graph_scores, [])').replace('lookup, graph_scores)','lookup, graph_scores, [])')
    text=text.replace('allowed, scores)','allowed, scores, [UInt32(0), UInt32(1), UInt32(2), UInt32(3)])').replace('lookup, scores)','lookup, scores, [UInt32(0), UInt32(1), UInt32(2), UInt32(3)])')
    # Existing direct rerank tests deliberately provide no reusable graph score.
    text=text.replace('allowed, []','allowed, [], []').replace('lookup, []','lookup, [], []')
    p.write_text(text)
print('carried delta slot provenance; proof validates bounds, current flag and public ID')
